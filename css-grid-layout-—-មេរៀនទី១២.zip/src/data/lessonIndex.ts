import { LessonSection } from '../types';
import { SECTIONS_1_TO_5 } from './sections1to5';
import { SECTIONS_6_TO_10 } from './sections6to10';
import { SECTIONS_11_TO_15 } from './sections11to15';

export const ALL_LESSON_SECTIONS: LessonSection[] = [
  ...SECTIONS_1_TO_5,
  ...SECTIONS_6_TO_10,
  ...SECTIONS_11_TO_15
];
