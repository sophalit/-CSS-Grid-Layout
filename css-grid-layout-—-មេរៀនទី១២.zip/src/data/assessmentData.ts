export interface SummaryItem {
  property: string;
  appliedTo: 'Container' | 'Item' | 'Both';
  roleKm: string;
  example: string;
}

export interface QuizQuestion {
  id: number;
  type: 'comprehension' | 'prediction';
  question: string;
  codeSnippet?: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface AssignmentLevel {
  level: number;
  title: string;
  goal: string;
  requiredProperties: string[];
  steps: string[];
  deliverables: string;
}

export const SUMMARY_TABLE_DATA: SummaryItem[] = [
  {
    property: 'display: grid',
    appliedTo: 'Container',
    roleKm: 'បង្កើត Grid Formatting Context ប្រែក្លាយកូនផ្ទាល់ឱ្យទៅជា Grid Items',
    example: 'display: grid;'
  },
  {
    property: 'grid-template-columns',
    appliedTo: 'Container',
    roleKm: 'កំណត់ចំនួន និងទទឹងនៃជួរឈរ (Columns) ទាំងអស់ក្នុង Grid',
    example: 'grid-template-columns: 240px 1fr 1fr;'
  },
  {
    property: 'grid-template-rows',
    appliedTo: 'Container',
    roleKm: 'កំណត់ចំនួន និងកម្ពស់នៃជួរដេក (Rows) ជាក់លាក់ក្នុង Explicit Grid',
    example: 'grid-template-rows: 70px auto 50px;'
  },
  {
    property: 'gap / row-gap / column-gap',
    appliedTo: 'Container',
    roleKm: 'កំណត់ទំហំគម្លាតរវាងជួរដេក និងជួរឈរ (មិនប៉ះពាល់គែមក្រៅ Container)',
    example: 'gap: 16px 24px;'
  },
  {
    property: 'repeat()',
    appliedTo: 'Container',
    roleKm: 'អនុគមន៍កាត់បន្ថយកូដស្ទួនសម្រាប់បង្កើត Tracks ទំហំដូចគ្នា ឬជា Pattern',
    example: 'repeat(4, 1fr) ឬ repeat(auto-fit, minmax(200px, 1fr))'
  },
  {
    property: 'fr (Fractional Unit)',
    appliedTo: 'Container',
    roleKm: 'ឯកតាចែករំលែកទំហំទំនេរដែលនៅសល់ (Available Space) ដោយស្វ័យប្រវត្តិ',
    example: 'grid-template-columns: 1fr 2fr;'
  },
  {
    property: 'minmax()',
    appliedTo: 'Container',
    roleKm: 'កំណត់កម្រិតព្រំដែនទំហំតូចបំផុត (min) និងធំបំផុត (max) សម្រាប់ Track',
    example: 'minmax(220px, 1fr)'
  },
  {
    property: 'auto-fit / auto-fill',
    appliedTo: 'Container',
    roleKm: 'ពាក្យគន្លឹះគណនាចំនួន Columns ស្វ័យប្រវត្តิตាមអេក្រង់ (auto-fit collapse empty tracks)',
    example: 'repeat(auto-fit, minmax(200px, 1fr))'
  },
  {
    property: 'grid-column',
    appliedTo: 'Item',
    roleKm: 'កំណត់បន្ទាត់ចាប់ផ្តើម និងបញ្ចប់ ឬចំនួនជួរឈរដែល Item ត្រូវគ្របដណ្តប់ (Span)',
    example: 'grid-column: 1 / 3; ឬ grid-column: span 2; ឬ 1 / -1;'
  },
  {
    property: 'grid-row',
    appliedTo: 'Item',
    roleKm: 'កំណត់បន្ទាត់ចាប់ផ្តើម និងបញ្ចប់ ឬចំនួនជួរដេកដែល Item ត្រូវគ្របដណ្តប់ចុះក្រោម',
    example: 'grid-row: 1 / 3; ឬ grid-row: span 2;'
  },
  {
    property: 'grid-template-areas',
    appliedTo: 'Container',
    roleKm: 'កំណត់ឈ្មោះតំបន់ Layout ដោយប្រើ Strings ដូចគំនូសព្រាងពិតៗ',
    example: 'grid-template-areas: "header header" "sidebar main";'
  },
  {
    property: 'grid-area',
    appliedTo: 'Item',
    roleKm: 'ចង Item ទៅនឹងឈ្មោះតំបន់ដែលបានប្រកាសក្នុង grid-template-areas',
    example: 'grid-area: header;'
  }
];

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  // 10 Comprehension Questions
  {
    id: 1,
    type: 'comprehension',
    question: 'ហេតុអ្វីបានជា CSS Grid ត្រូវបានគេចាត់ទុកជា "Two-Dimensional (2D) Layout System"?',
    options: [
      'ដោយសារវាអាចដំណើរការបានទាំងលើទូរស័ព្ទ និងកុំព្យូទ័រ',
      'ដោយសារវាគ្រប់គ្រងការតម្រៀបធាតុទាំងលើជួរឈរ (Columns) និងជួរដេក (Rows) ក្នុងពេលដំណាលគ្នា',
      'ដោយសារវាគាំទ្រតែទទឹង និងកម្ពស់គិតជា px ប៉ុណ្ណោះ',
      'ដោយសារវាត្រូវការ Flexbox ជួយគាំទ្របន្ថែមទើបដំណើរការបាន'
    ],
    correctIndex: 1,
    explanation: 'CSS Grid គឺជា 2D Layout System ពីព្រោះវាអាចរៀបចំ និងតម្រឹម Elements ទាំងលើបន្ទាត់ផ្ដេក (Rows) និងបន្ទាត់បញ្ឈរ (Columns) ក្នុងពេលតែមួយ ខណៈ Flexbox គិតតែលើអ័ក្សមួយប៉ុណ្ណោះ (1D)។'
  },
  {
    id: 2,
    type: 'comprehension',
    question: 'តើធាតុប្រភេទណាខ្លះដែលក្លាយជា Grid Items ដោយស្វ័យប្រវត្តិ នៅពេល Container ប្រើ display: grid?',
    options: [
      'ធាតុទាំងអស់ដែលស្ថិតនៅខាងក្នុង Container មិនថា Nested ប៉ុន្មានកម្រិតក៏ដោយ',
      'មានតែកូនផ្ទាល់កម្រិតទី១ (Direct Child Elements) ក្នុង Normal Flow ប៉ុណ្ណោះ',
      'មានតែធាតុណាដែលដាក់ class="grid-item" ប៉ុណ្ណោះ',
      'មានតែធាតុ <div > និង <section> ប៉ុណ្ណោះ'
    ],
    correctIndex: 1,
    explanation: 'មានតែកូនបង្កើតផ្ទាល់កម្រិតទី១ (Direct Children) នៅក្នុង Normal Flow ប៉ុណ្ណោះដែលក្លាយជា Grid Items។ ចំណែក Nested Elements ខាងក្នុងកូនៗ មិនក្លាយជា Grid Items របស់ Container ខាងក្រៅឡើយ។'
  },
  {
    id: 3,
    type: 'comprehension',
    question: 'តើអ្វីកើតឡើងភ្លាមៗនៅពេលអ្នកសរសេរ display: grid តែមួយមុខ ដោយគ្មាន grid-template-columns?',
    options: [
      'Browser បង្កើត 3 ជួរឈរស្មើគ្នាដោយស្វ័យប្រវត្តិ',
      'Container នឹងមិនបង្ហាញអ្វីទាំងអស់ (បាត់ពីអេក្រង់)',
      'បង្កើត 1 ជួរឈរទោល (Single Column) ហើយកូនៗតម្រៀបចុះក្រោមដូច Block Elements ធម្មតា',
      'ធ្វើឱ្យ Elements ទាំងអស់ជាន់លើគ្នាត្រង់កណ្តាល'
    ],
    correctIndex: 2,
    explanation: 'display: grid បើកដំណើរការ Grid Context ប៉ុន្តែបើគ្មានការកំណត់ columns ទេ វានឹងបង្កើត 1 Column ទោល ហើយ Items ធ្លាក់ចុះក្រោមជាជួរដេក (Rows) តាមលំនាំដើម។'
  },
  {
    id: 4,
    type: 'comprehension',
    question: 'ប្រសិនបើ Grid មួយត្រូវបានកំណត់ grid-template-columns: 1fr 1fr 1fr; តើមាន Vertical Grid Lines ចំនួនប៉ុន្មាន?',
    options: [
      'មាន 3 Lines',
      'មាន 4 Lines',
      'មាន 2 Lines',
      'មាន 6 Lines'
    ],
    correctIndex: 1,
    explanation: 'រូបមន្តគ្រឹះគឺ៖ ចំនួន Grid Lines = ចំនួន Tracks + 1។ ដូចនេះ 3 Columns គឺមាន Vertical Grid Lines ចំនួន ៤ (Line 1 នៅឆ្វេងបំផុត, Line 2 ចន្លោះ Col 1-2, Line 3 ចន្លោះ Col 2-3, និង Line 4 នៅស្តាំបំផុត)។'
  },
  {
    id: 5,
    type: 'comprehension',
    question: 'ហេតុអ្វីបានជាការប្រើ grid-template-columns: 50% 50% រួមជាមួយ gap: 20px អាចបង្កជា Horizontal Scrollbar (Overflow)?',
    options: [
      'ព្រោះ Percentage មិនអាចប្រើក្នុង Grid បានទេ',
      'ព្រោះផលបូក 50% + 50% = 100% ទៅហើយ ពេលបូកបន្ថែម 20px ទៀត ធ្វើឱ្យទំហំសរុបធំជាង 100% នៃ Container',
      'ព្រោះ gap មិនគាំទ្រឯកតា px ទេ',
      'ព្រោះ Browser មិនស្គាល់ gap នៅលើ Percentage'
    ],
    correctIndex: 1,
    explanation: 'ការប្រើ % សរុប 100% មិនបានដកគម្លាត gap ចេញទេ ធ្វើឱ្យទទឹងសរុបស្មើ 100% + 20px បណ្តាលឱ្យធ្លាយ Overflow។ ដំណោះស្រាយត្រឹមត្រូវគឺប្រើ 1fr 1fr ព្រោះ fr នឹងដក gap មុនចែកទំហំ។'
  },
  {
    id: 6,
    type: 'comprehension',
    question: 'តើលេខបន្ទាត់ -1 នៅក្នុង grid-column: 1 / -1 មានអត្ថន័យដូចម្តេច?',
    options: [
      'វាមានកំហុស Syntax មិនអាចដំណើរការបានទេ',
      'វាសំដៅលើបន្ទាត់បញ្ឈរចុងក្រោយបង្អស់នៃ Explicit Grid',
      'វាដកជួរឈរមួយចេញពី Grid',
      'វាដាក់ Item ឱ្យនៅក្រៅ Grid មួយជួរ'
    ],
    correctIndex: 1,
    explanation: 'លេខអវិជ្ជមាន -1 សំដៅលើ Grid Line ចុងក្រោយបង្អស់នៃ Explicit Grid។ ដូចនេះ 1 / -1 មានន័យថាលាតសន្ធឹងចាប់ពីបន្ទាត់ទី១ រហូតដល់បន្ទាត់ចុងក្រោយគេ (ពេញទទឹង 100%)។'
  },
  {
    id: 7,
    type: 'comprehension',
    question: 'តើអនុគមន៍ repeat(3, 200px 1fr) នឹងបង្កើតជួរឈរសរុបប៉ុន្មាន?',
    options: [
      'បង្កើតបាន 3 Columns',
      'បង្កើតបាន 4 Columns',
      'បង្កើតបាន 6 Columns (លំនាំ 200px 1fr ចំនួន ៣ ដង)',
      'បង្កើតបាន 2 Columns'
    ],
    correctIndex: 2,
    explanation: 'repeat(3, 200px 1fr) យកលំនាំ (200px 1fr) ដែលមាន 2 Tracks ទៅគុណនឹង 3 ដង ស្មើនឹង 6 Columns សរុប (200px 1fr 200px 1fr 200px 1fr)។'
  },
  {
    id: 8,
    type: 'comprehension',
    question: 'តើអ្វីទៅជាភាពខុសគ្នាសំខាន់បំផុតរវាង auto-fit និង auto-fill នៅពេលដែល Container មានទំហំធំទូលាយ ប៉ុន្តែមាន Items តិច?',
    options: [
      'auto-fill រក្សាទុក Empty Tracks ចំហចោល ចំណែក auto-fit រំលាយ (Collapse) Empty Tracks ចោល ហើយអនុញ្ញាតឱ្យ Items ពង្រីកយកកន្លែង',
      'auto-fit ដំណើរការតែលើទូរស័ព្ទ រីឯ auto-fill ដំណើរការលើ Desktop',
      'auto-fit ត្រូវការ JavaScript ជំនួយ',
      'គ្មានភាពខុសគ្នាទេ ពួកវាដូចគ្នាបេះបិទគ្រប់កាលៈទេសៈ'
    ],
    correctIndex: 0,
    explanation: 'នៅពេល Items តិច auto-fill នឹងបង្កើតក្រឡាទទេ (Empty Tracks) រក្សាទុកនៅខាងស្តាំ រីឯ auto-fit នឹង Collapse ក្រឡាទទេចោល ហើយឱ្យ Items ដែលមានស្រាប់រីកធំពង្រីកពេញទទឹង Container ទាំងមូល។'
  },
  {
    id: 9,
    type: 'comprehension',
    question: 'នៅក្នុងអនុគមន៍ minmax(min, max) តើតម្លៃមួយណាដែលមិនត្រូវបានអនុញ្ញាតឱ្យប្រើប្រាស់ក្នុងផ្នែក min?',
    options: [
      'px (ដូចជា 200px)',
      'rem (ដូចជា 15rem)',
      'fr (ដូចជា 1fr)',
      '% (ដូចជា 20%)'
    ],
    correctIndex: 2,
    explanation: 'ឯកតា fr មិនអាចប្រើក្នុងតម្លៃ min នៃ minmax() បានទេ (ឧ. minmax(1fr, 300px) គឺខុស Invalid) ព្រោះ fr តំណាងឱ្យចំណែកទំហំទំនេរដែលអាចបត់បែន មិនអាចធ្វើជាកម្រិតអប្បបរមាថេរបានឡើយ។'
  },
  {
    id: 10,
    type: 'comprehension',
    question: 'តើការប្រើ min-width: 0; លើ Grid Item ជួយដោះស្រាយបញ្ហាអ្វីខ្លះ?',
    options: [
      'ជួយការពារកុំឱ្យបាត់កាតពីអេក្រង់',
      'ទប់ស្កាត់បញ្ហា Content ឬ URL វែងជ្រុលមិនឱ្យរុញ Track 1fr ឱ្យរីកធំធ្លាយខូច Layout (Text Overflow)',
      'ជួយឱ្យកាតមានរាងមូលស្អាត',
      'ជួយឱ្យរូបភាពច្បាស់ជាងមុន'
    ],
    correctIndex: 1,
    explanation: 'តាមលំនាំដើម Grid Items មាន min-width: auto; ដែលមិនព្រមរួញតូចជាងទំហំអត្ថបទខាងក្នុងឡើយ។ បើមានតំណភ្ជាប់វែង ឬ preformatted text វានឹងរុញ 1fr ឱ្យធ្លាយ។ ការកំណត់ min-width: 0; អនុញ្ញាតឱ្យ Item រួញតូចបានត្រឹមត្រូវ។'
  },

  // 5 Code Prediction Questions
  {
    id: 11,
    type: 'prediction',
    question: 'សង្កេតកូដខាងក្រោម៖ តើ Item ទី១ (.item-hero) នឹងគ្របដណ្តប់លើជួរឈរណាខ្លះ?',
    codeSnippet: `.container {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
}
.item-hero {
  grid-column: 2 / 5;
}`,
    options: [
      'គ្របលើ Column 2, 3, 4 (សរុប 3 Columns)',
      'គ្របលើ Column 1, 2, 3, 4, 5 (សរុប 5 Columns)',
      'គ្របលើ Column 2 និង 5 ប៉ុណ្ណោះ',
      'គ្របលើ Column 2 និង 3 (សរុប 2 Columns)'
    ],
    correctIndex: 0,
    explanation: 'grid-column: 2 / 5 ចាប់ផ្តើមពី Line 2 ដល់ Line 5។ ចន្លោះពី Line 2 ដល់ Line 5 គឺរួមបញ្ចូល Column 2, Column 3 និង Column 4 (5 - 2 = 3 Columns សរុប)។'
  },
  {
    id: 12,
    type: 'prediction',
    question: 'Container មានទទឹង 800px, gap: 0, និង CSS ដូចខាងក្រោម។ តើ Column ទី២ (1fr) និង Column ទី៣ (2fr) មានទទឹងប៉ុន្មាន px?',
    codeSnippet: `.container {
  width: 800px;
  display: grid;
  grid-template-columns: 200px 1fr 2fr;
}`,
    options: [
      '1fr = 200px និង 2fr = 400px',
      '1fr = 300px និង 2fr = 300px',
      '1fr = 150px និង 2fr = 300px',
      '1fr = 100px និង 2fr = 200px'
    ],
    correctIndex: 0,
    explanation: 'ទំហំទំនេរ = 800px - 200px (Fixed) = 600px។ ផលបូក fr = 1 + 2 = 3fr។ ដូចនេះ 1fr = 600px / 3 = 200px។ Column ទី២ (1fr) = 200px ហើយ Column ទី៣ (2fr) = 400px។'
  },
  {
    id: 13,
    type: 'prediction',
    question: 'តើមានកំហុសអ្វីនៅក្នុងការប្រកាស grid-template-areas ខាងក្រោមនេះ?',
    codeSnippet: `.dashboard {
  display: grid;
  grid-template-columns: 250px 1fr;
  grid-template-areas:
    "header header header"
    "sidebar main";
}`,
    options: [
      'មិនអាចប្រើពាក្យ "header" ពីរដងបានទេ',
      'ចំនួន Area Words ក្នុងជួរនីមួយៗមិនស្មើគ្នា (ជួរទី១ មាន 3 ពាក្យ ខណៈជួរទី២ មានតែ 2 ពាក្យ) ហើយមិនត្រូវគ្នានឹង grid-template-columns ដែលមានតែ 2 Columns',
      'ខ្វះសញ្ញាក្បៀស (comma) នៅចុងបន្ទាត់ string នីមួយៗ',
      'មិនអាចដាក់ sidebar នៅមុន main បានទេ'
    ],
    correctIndex: 1,
    explanation: 'នៅក្នុង grid-template-areas រាល់ string ត្រូវតែមានចំនួន Cell Words ស្មើគ្នាបេះបិទ និងត្រូវគ្នានឹងចំនួន Columns ដែលបានប្រកាសក្នុង grid-template-columns (2 Columns)។ ជួរទី១ មាន 3 ពាក្យ ធ្វើឱ្យ Grid ខូច Invalid ទាំងស្រុង។'
  },
  {
    id: 14,
    type: 'prediction',
    question: 'ប្រសិនបើអេក្រង់ទូរស័ព្ទមានទទឹង 360px ហើយ CSS សរសេរដូចខាងក្រោម តើ Layout នឹងបង្ហាញជាប៉ុន្មាន Columns?',
    codeSnippet: `.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  padding: 16px;
}`,
    options: [
      'បង្ហាញជា 2 Columns',
      'បង្ហាញជា 1 Column ដោយសារ 200px + 16px gap + 200px = 416px (លើសពី 360px)',
      'បង្ហាញជា 3 Columns',
      'មិនបង្ហាញ Columns ទេ'
    ],
    correctIndex: 1,
    explanation: 'ទទឹងខាងក្នុង = 360px - 32px (padding) = 328px។ ដើម្បីដាក់បាន 2 Columns ត្រូវការយ៉ាងតិច 200px + 16px (gap) + 200px = 416px។ ដោយសារ 328px < 416px នោះ auto-fit នឹងទម្លាក់មកត្រឹម 1 Column ដោយស្វ័យប្រវត្តិ ហើយពង្រីក 1fr ពេញទទឹង។'
  },
  {
    id: 15,
    type: 'prediction',
    question: 'តើប្លង់នឹងមានរូបរាងយ៉ាងណា នៅពេលកាតមួយមាន CSS ដូចខាងក្រោម ក្នុង Grid 3 Columns x 3 Rows?',
    codeSnippet: `.featured-box {
  grid-column: span 2;
  grid-row: span 2;
}`,
    options: [
      'កាតនោះនឹងរួញតូចមកត្រឹម 1 Cell',
      'កាតនោះនឹងគ្របដណ្តប់ 4 Cells ស្មើនឹងទំហំ 2 ជួរឈរ x 2 ជួរដេក',
      'កាតនោះនឹងធ្លាក់ទៅជួរចុងក្រោយបង្អស់នៃទំព័រ',
      'កាតនោះនឹងបាត់ចេញពីអេក្រង់'
    ],
    correctIndex: 1,
    explanation: 'grid-column: span 2 ធ្វើឱ្យវាលាតសន្ធឹង 2 Columns ផ្តេក ហើយ grid-row: span 2 ធ្វើឱ្យវាលាតសន្ធឹង 2 Rows បញ្ឈរ។ លទ្ធផលគឺបង្កើតបានជា Big Square Box ទំហំស្មើនឹង 4 Cells បញ្ចូលគ្នា។'
  }
];

export const PRACTICAL_ASSIGNMENTS: AssignmentLevel[] = [
  {
    level: 1,
    title: "កម្រិតទី១៖ Basic 3-Column Grid ជាមួយកាតនិស្សិត ៦ នាក់",
    goal: "បង្កើតក្រឡាចត្រង្គ 3 ជួរឈរទំហំស្មើគ្នា ដែលមានកាតនិស្សិតចំនួន ៦ ដោយប្រើ display: grid, grid-template-columns និង gap។",
    requiredProperties: [
      "display: grid",
      "grid-template-columns: repeat(3, 1fr) ឬ 1fr 1fr 1fr",
      "gap: 16px",
      "padding, background-color, border-radius"
    ],
    steps: [
      "ជំហានទី១៖ បង្កើត Container <div class=\"student-grid\"> នៅក្នុង HTML។",
      "ជំហានទី២៖ បង្កើតកាតនិស្សិត <article class=\"student-card\"> ចំនួន ៦ ដែលមានឈ្មោះ ជំនាញ និងរូបតំណាង (ទិន្នន័យគំរូ)។",
      "ជំហានទី៣៖ ក្នុង CSS កំណត់ display: grid និង grid-template-columns: repeat(3, 1fr) លើ Container។",
      "ជំហានទី៤៖ បន្ថែម gap: 16px និងរចនាពណ៌កាតឱ្យស្រស់ស្អាតងាយអាន។"
    ],
    deliverables: "ឯកសារ HTML/CSS ដែលបង្ហាញកាតនិស្សិត ៦ រៀបជា ២ ជួរដេក និង ៣ ជួរឈរត្រង់ជួរគ្នាល្អ។"
  },
  {
    level: 2,
    title: "កម្រិតទី២៖ Layout ដែលមាន Columns និង Rows ទំហំខុសគ្នា",
    goal: "បង្កើត Layout ទំព័រព័ត៌មានវិទ្យាដែលមាន Sidebar ទទឹង 250px ថេរ និង Main Content បត់បែនតាមអេក្រង់ (1fr) រួមជាមួយ Header និង Footer កម្ពស់ថេរ។",
    requiredProperties: [
      "grid-template-columns: 250px 1fr",
      "grid-template-rows: 70px auto 50px",
      "grid-column: 1 / -1 លើ Header និង Footer",
      "gap: 16px"
    ],
    steps: [
      "ជំហានទី១៖ រៀបចំ Semantic Elements: <header>, <aside>, <main>, <footer>។",
      "ជំហានទី២៖ កំណត់ Container ឱ្យមាន grid-template-columns: 250px 1fr និង rows សមស្រប។",
      "ជំហានទី៣៖ ដាក់ grid-column: 1 / -1 លើ Header និង Footer ដើម្បីឱ្យលាតសន្ធឹងកាត់ពេញទទឹង។",
      "ជំហានទី៤៖ ពិនិត្យមើលថាតើ Sidebar រក្សាទំហំ 250px ថេរដែរឬទេពេលពង្រីក Browser។"
    ],
    deliverables: "Layout ទំព័រពេញលេញដែលមាន Sidebar ឆ្វេង និង Content ស្តាំ ព្រមទាំង Header/Footer លាតពេញទទឹង។"
  },
  {
    level: 3,
    title: "កម្រិតទី៣៖ Featured Card ដែលប្រើ Column Span និង Row Span",
    goal: "បង្កើតទំព័រកាតព័ត៌មានសាកលវិទ្យាល័យ ដែលកាតទី១ ជា Featured Hero Card គ្របដណ្តប់ 2 Columns និង 2 Rows ខណៈកាតដទៃទៀតមានទំហំធម្មតា 1 Cell។",
    requiredProperties: [
      "grid-column: span 2 (ឬ 1 / 3)",
      "grid-row: span 2 (ឬ 1 / 3)",
      "display: grid ជាមួយ 3 Columns",
      "@media query ដើម្បី reset span លើទូរស័ព្ទដៃ"
    ],
    steps: [
      "ជំហានទី១៖ បង្កើត Grid Container ដែលមាន 3 Columns (repeat(3, 1fr))។",
      "ជំហានទី២៖ ជ្រើសរើសកាតដំបូងគេ ដាក់ class=\"featured-card\"។",
      "ជំហានទី៣៖ ក្នុង CSS ដាក់ grid-column: span 2; grid-row: span 2; លើកាតនោះ។",
      "ជំហានទី៤៖ បន្ថែម @media (max-width: 768px) ដោយកំណត់ grid-column: auto; grid-row: auto; ដើម្បីការពារការធ្លាយលើ Mobile។"
    ],
    deliverables: "ទំព័រដែលមានកាតធំលេចធ្លោ 2x2 លើ Desktop និងរៀបជួរដេកធម្មតាលើ Mobile។"
  },
  {
    level: 4,
    title: "កម្រិតទី៤៖ Responsive Gallery ជាមួយការប្រៀបធៀប auto-fit និង auto-fill",
    goal: "បង្កើតទំព័រប្រៀបធៀបដោយដាក់ Gallery ពីរនៅទន្ទឹមគ្នា៖ Gallery ទី១ ប្រើ auto-fit និង Gallery ទី២ ប្រើ auto-fill ជាមួយ minmax(200px, 1fr) និង aspect-ratio: 4/3។",
    requiredProperties: [
      "repeat(auto-fit, minmax(min(100%, 220px), 1fr))",
      "repeat(auto-fill, minmax(200px, 1fr))",
      "aspect-ratio: 4 / 3",
      "object-fit: cover"
    ],
    steps: [
      "ជំហានទី១៖ ដាក់រូបភាពគំរូតែ ២ សន្លឹកក្នុង Gallery ទី១ (auto-fill) និង ២ សន្លឹកក្នុង Gallery ទី២ (auto-fit)។",
      "ជំហានទី២៖ សង្កេតមើលចន្លោះទទេ Empty Tracks នៅក្នុង auto-fill និងការពង្រីកពេញនៅក្នុង auto-fit។",
      "ជំហានទី៣៖ បន្ថែមរូបភាពរហូតដល់ ៨ សន្លឹក រួចសង្កេតមើលថាតើលទ្ធផលក្លាយជាដូចគ្នាឬទេ ពេល Tracks ពេញ។",
      "ជំហានទី៤៖ បន្ថែម aspect-ratio: 4/3 និង object-fit: cover លើរូបភាពទាំងអស់។"
    ],
    deliverables: "ទំព័រពិសោធន៍ដែលបង្ហាញពីឥរិយាបថខុសគ្នារវាង auto-fit និង auto-fill យ៉ាងច្បាស់ក្រឡែត។"
  },
  {
    level: 5,
    title: "កម្រិតទី៥៖ Mini Project — Responsive Student Dashboard ពេញលេញ",
    goal: "កសាងប្រព័ន្ធគ្រប់គ្រងនិស្សិត (Student Dashboard) ពេញលេញកម្រិតវិជ្ជាជីវៈ ដោយប្រើប្រាស់ Semantic HTML5, CSS Grid (grid-template-areas), Nested Grids លើកាតស្ថិតិ ៤ និង Course List ព្រមទាំង Responsive លើអេក្រង់ 360px, 768px និង 1280px+។",
    requiredProperties: [
      "grid-template-areas",
      "grid-area",
      "Nested Grid លើ Stats Cards",
      "Mobile-first responsive architecture",
      "Accessibility (ARIA labels, alt text, color contrast)"
    ],
    steps: [
      "ជំហានទី១៖ បង្កើតរចនាសម្ព័ន្ធ HTML ដោយប្រើ <header>, <nav>, <main>, <section>, <article>, <footer>។",
      "ជំហានទី២៖ រៀបចំ Mobile First (1 Column) ជាមួយ grid-template-areas: 'header' 'sidebar' 'main' 'footer'។",
      "ជំហានទី៣៖ បន្ថែម @media (min-width: 992px) ដើម្បីរៀបជា 2 Columns ជាមួយ Sidebar 240px និង Main Content 1fr។",
      "ជំហានទី៤៖ បង្កើត Nested Grid សម្រាប់ Stats Cards ទាំង ៤ និង Course Section ដោយប្រើ auto-fit និង minmax()។",
      "ជំហានទី៥៖ ពិនិត្យតេស្តលើទំហំអេក្រង់ 360px, 768px, 1280px ធានាគ្មាន Overflow ផ្ដេកឡើយ។"
    ],
    deliverables: "ឯកសារ index.html និង css/style.css ពេញលេញដែលអាចបើកដំណើរការលើ Browser ណាក៏បានដោយគ្មាន Error។"
  }
];

export const GRADING_RUBRIC = [
  {
    category: "១. ភាពត្រឹមត្រូវនៃ Grid Layout (Grid Accuracy)",
    maxScore: 30,
    criteria: [
      "ប្រើប្រាស់ display: grid, grid-template-columns, grid-template-rows និង gap បានត្រឹមត្រូវតាមស្តង់ដារ (10 ពិន្ទុ)",
      "ប្រើប្រាស់ fr unit, repeat(), និង minmax() បានត្រឹមត្រូវដោយគ្មានការគណនាខុស (10 ពិន្ទុ)",
      "អនុវត្ត grid-column, grid-row, ឬ grid-template-areas បានត្រឹមត្រូវតាមបន្ទាត់ Grid Lines (10 ពិន្ទុ)"
    ]
  },
  {
    category: "២. ឥរិយាបថសម្របតាមអេក្រង់ (Responsive Behavior)",
    maxScore: 25,
    criteria: [
      "ដំណើរការរលូន និងមិនធ្លាយ Overflow ផ្តេកលើទំហំ 360px, 768px និង 1280px (10 ពិន្ទុ)",
      "ប្រើប្រាស់ auto-fit ឬ Media Queries ដើម្បីផ្លាស់ប្តូរចំនួន Columns លើ Mobile បានសមរម្យ (10 ពិន្ទុ)",
      "កែសម្រួល Span លើ Mobile បានត្រឹមត្រូវ មិនបង្កឱ្យខូចទ្រង់ទ្រាយក្រឡា (5 ពិន្ទុ)"
    ]
  },
  {
    category: "៣. រចនាសម្ព័ន្ធ HTML និង Accessibility (HTML & A11y)",
    maxScore: 15,
    criteria: [
      "ប្រើប្រាស់ Semantic HTML5 (header, nav, main, section, article, footer, figure) (6 ពិន្ទុ)",
      "មាន <!DOCTYPE html>, lang=\"km\", meta viewport និង UTF-8 ត្រឹមត្រូវ (4 ពិន្ទុ)",
      "រូបភាពមាន alt text ច្បាស់លាស់ និង DOM Order ត្រូវគ្នានឹងការអានតាមលំដាប់ (5 ពិន្ទុ)"
    ]
  },
  {
    category: "៤. ភាពងាយអាន និងការរៀបចំកូដ CSS (Code Quality)",
    maxScore: 15,
    criteria: [
      "ប្រើប្រាស់ box-sizing: border-box និង CSS Reset ត្រឹមត្រូវ (5 ពិន្ទុ)",
      "កូដមាន Indentation ស្អាត មាន Comment ពន្យល់ជាភាសាខ្មែរ ឬអង់គ្លេសច្បាស់លាស់ (5 ពិន្ទុ)",
      "មិនប្រើ Fixed Height ដែលធ្វើឱ្យកាត់ ឬធ្លាយអត្ថបទខ្មែរ (5 ពិន្ទុ)"
    ]
  },
  {
    category: "៥. សមត្ថភាពពន្យល់កូដ និងដោះស្រាយបញ្ហា (Problem Solving)",
    maxScore: 15,
    criteria: [
      "អាចពន្យល់ហេតុផលនៃការជ្រើសរើស Grid ធៀបនឹង Flexbox បានក្បោះក្បាយ (5 ពិន្ទុ)",
      "យល់ច្បាស់ពីភាពខុសគ្នារវាង auto-fit និង auto-fill (5 ពិន្ទុ)",
      "អាចដោះស្រាយកំហុស Overflow ពេលប្រើ Percentage ជាមួយ gap បាន (5 ពិន្ទុ)"
    ]
  }
];
