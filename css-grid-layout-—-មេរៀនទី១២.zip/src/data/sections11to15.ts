import { LessonSection } from '../types';

export const SECTIONS_11_TO_15: LessonSection[] = [
  {
    id: "sec-12-11",
    number: "12.11",
    title: "fr Unit (Fractional Unit)",
    englishTitle: "The fr Unit — Fraction of Available Space",
    definition: "fr (Fractional Unit) គឺជាឯកតារង្វាស់បត់បែនពិសេសបង្កើតឡើងសម្រាប់ CSS Grid ដោយឡែក។ 1fr មានន័យថា «ចំណែកមួយភាគនៃទំហំទំនេរដែលនៅសល់ (One fraction of available free space)» បន្ទាប់ពីបានដក Fixed Tracks និង Gaps ចេញរួចរាល់។",
    purposeAndWhenToUse: "ប្រើជំនួសឱ្យ Percentage (%) ក្នុងការបែងចែកជួរឈរ។ អត្ថប្រយោជន៍ដ៏អស្ចារ្យរបស់ fr គឺភាពវៃឆ្លាតក្នុងការគណនាដក gap និង px មុននឹងបែងចែកទំហំ ធានាថាមិនបង្កជា Overflow ដាច់ខាត។",
    syntax: `/* ចែកទំហំស្មើគ្នា ២ ភាគ (50% នៃ free space ម្នាក់) */
grid-template-columns: 1fr 1fr;

/* ចែកទំហំមិនស្មើគ្នា៖ Column ទី២ ធំជាង Column ទី១ ទ្វេដង (1 ភាគ និង 2 ភាគ = សរុប 3 ភាគ) */
grid-template-columns: 1fr 2fr;

/* Sidebar ថេរ 250px, Main Content យកទំហំដែលនៅសល់ទាំងអស់ */
grid-template-columns: 250px 1fr;

/* ដោះស្រាយបញ្ហា Content/Code វែងជ្រុលធ្វើឱ្យ fr ធ្លាយ៖ */
grid-template-columns: minmax(0, 1fr) 250px;
/* ឬដាក់ min-width: 0; លើ Grid Item */`,
    htmlExample: `<!-- ការប្រៀបធៀបរបៀបគណនា fr ជាមួយកាតព័ត៌មាននិស្សិត -->
<div class="fraction-container">
  <div class="col-fixed">Sidebar: 250px (ថេរ)</div>
  <div class="col-part1">Content A: 1fr (1 ភាគ)</div>
  <div class="col-part2">Content B: 2fr (2 ភាគ - ធំជាងទ្វេដង)</div>
</div>`,
    cssExample: `.fraction-container {
  display: grid;
  /* គណនា៖ ប្រសិនបើ Container ទទឹង 1000px, ដក 250px (ថេរ) និងដក (2 * 15px gap = 30px)
     ទំហំសល់ = 1000 - 250 - 30 = 720px។
     សរុបមាន 3fr (1fr + 2fr) => 1fr = 720px / 3 = 240px។
     ដូច្នេះ៖ Column 1 = 250px, Column 2 = 240px, Column 3 = 480px! */
  grid-template-columns: 250px 1fr 2fr;
  gap: 15px;
  background-color: #f8fafc;
  padding: 16px;
  border-radius: 8px;
}

.col-fixed {
  background-color: #e2e8f0;
  padding: 16px;
  border-radius: 6px;
  font-weight: 600;
}

.col-part1 {
  background-color: #bfdbfe;
  padding: 16px;
  border-radius: 6px;
  /* បង្ការ overflow ពេលមានកូដ ឬ URL វែង */
  min-width: 0;
}

.col-part2 {
  background-color: #93c5fd;
  padding: 16px;
  border-radius: 6px;
  min-width: 0;
}`,
    codeExplanation: [
      "រូបមន្តគណនាច្បាស់លាស់៖ Available Space = Container Width - (Fixed Widths + Gaps)។",
      "បន្ទាប់មកទើបយក Available Space ទៅចែកនឹងចំនួនផលបូកនៃ fr ទាំងអស់។",
      "ចំណាំបច្ចេកទេសកម្រិតខ្ពស់៖ តាមលំនាំដើម Grid Item មាន min-width: auto; ដែលមិនព្រមរួញតូចជាងទំហំអត្ថបទខាងក្នុងឡើយ។ ប្រសិនបើមាន Preformatted Code, URL វែង ឬរូបភាពធំ វាអាចរុញ fr ឱ្យរីកធំធ្លាយបាន។ ដំណោះស្រាយគឺបន្ថែម min-width: 0; លើ Item ឬប្រើ minmax(0, 1fr)។"
    ],
    expectedResult: {
      description: "ជួរឈរទី១ រក្សា 250px ថេរ, ជួរឈរទី២ យក ១ ភាគ, និងជួរឈរទី៣ យក ២ ភាគ (ធំជាងជួរឈរទី២ ពីរដង) យ៉ាងសមាមាត្រត្រឹមត្រូវឥតខ្ចោះ។",
      diagramText: `Container Width = 1000px (ឧទាហរណ៍)
+------------------+-----------------------+----------------------------------+
| Fixed (250px)    | 1fr (240px)           | 2fr (480px - ធំជាងទ្វេដង)        |
+------------------+-----------------------+----------------------------------+
[250px] + 15px gap + [240px] + 15px gap   + [480px] = 1000px ពេញលេញ!`
    },
    commonMistakes: [
      {
        mistake: "និស្សិតគិតថា 1fr មានទំហំស្មើ 100% ជានិច្ច។",
        solution: "1fr ស្មើ 100% បានលុះត្រាតែមានតែមួយ Track គត់។ បើមាន 1fr 1fr នោះ 1fr ស្មើ 50% នៃទំហំទំនេរ។ fr គឺជាសមាមាត្រ (Ratio) មិនមែនជាទំហំដាច់ខាតឡើយ។"
      },
      {
        mistake: "មានអត្ថបទ URL វែងខ្លាំង ធ្វើឱ្យ Column 1fr រីកធំធ្លាយចេញក្រៅ Layout។",
        solution: "ដាក់ min-width: 0; លើ Grid Item ឬសរសេរ minmax(0, 1fr) ក្នុង grid-template-columns។"
      }
    ],
    quickChallenge: {
      question: "ប្រសិនបើ Container មានទទឹង 900px, គ្មាន gap, ហើយ grid-template-columns: 300px 1fr 2fr; តើ Column 1fr មានទទឹងប៉ុន្មាន px?",
      task: "គណនាបង្ហាញជំហានដក និងចែក។",
      hint: "Available Space = 900 - 300 = 600px។ ផលបូក fr = 1 + 2 = 3fr។ ដូច្នេះ 1fr = 600 / 3 = 200px!"
    }
  },
  {
    id: "sec-12-12",
    number: "12.12",
    title: "minmax()",
    englishTitle: "Flexible Boundaries with minmax()",
    definition: "minmax() គឺជា CSS Function សម្រាប់កំណត់កម្រិតព្រំដែនទំហំពីរ៖ ទំហំតូចបំផុតដែលអនុញ្ញាត (Minimum) និងទំហំធំបំផុតដែលអនុញ្ញាត (Maximum) សម្រាប់ Grid Track មួយ។",
    purposeAndWhenToUse: "ប្រើសម្រាប់ការពារកុំឱ្យ Column រួញតូចពេកនៅលើអេក្រង់ទូរស័ព្ទ (ឧ. មិនឱ្យតូចជាង 200px) ហើយអាចពង្រីកធំរហូតដល់ទំហំទំនេរទាំងអស់ (1fr) នៅលើ Desktop។ សំខាន់ត្រូវយល់៖ repeat(3, minmax(200px, 1fr)) នៅតែបង្កើត 3 Columns ថេរដដែល (បើតូចជាង 600px វានឹង Overflow) ដូច្នេះដើម្បីឱ្យចំនួន Columns ប្រែប្រួលតាមអេក្រង់ស្វ័យប្រវត្តិ យើងត្រូវផ្សំវាជាមួយ auto-fit ឬ auto-fill!",
    syntax: `/* Syntax មូលដ្ឋាន: minmax(min, max) */
grid-template-columns: minmax(200px, 1fr) 1fr;

/* Sidebar: រួញតូចបំផុតត្រឹម 200px និងធំបំផុតត្រឹម 300px */
grid-template-columns: minmax(200px, 300px) 1fr;

/* ការប្រើរួមជាមួយ Auto Repeat ដើម្បីបង្កើត Responsive ដោយគ្មាន Media Queries: */
grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));`,
    htmlExample: `<!-- ឧទាហរណ៍កាតវគ្គបណ្តុះបណ្តាល IT -->
<div class="courses-minmax-grid">
  <div class="course-card-box">
    <h4>React.js Fundamentals</h4>
    <p>ស្វែងយល់ពី Component Lifecycle និង Hooks (ទិន្នន័យគំរូ)</p>
  </div>
  <div class="course-card-box">
    <h4>Node.js Backend Architecture</h4>
    <p>បង្កើត RESTful API និងគ្រប់គ្រង Express</p>
  </div>
  <div class="course-card-box">
    <h4>Database Modeling & SQL</h4>
    <p>រចនា ERD និងសរសេរ Complex Queries</p>
  </div>
</div>`,
    cssExample: `.courses-minmax-grid {
  display: grid;
  /* Track នីមួយៗតូចបំផុតមិនឱ្យក្រោម 200px ឡើយ ហើយបើអេក្រង់ធំវាអាចរីកដល់ 1fr */
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 16px;
  background-color: #f8fafc;
  padding: 16px;
  border-radius: 8px;
}

.course-card-box {
  background-color: #ffffff;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  padding: 16px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.04);
}

.course-card-box h4 {
  color: #1e40af;
  margin-bottom: 8px;
}`,
    codeExplanation: [
      "minmax(220px, 1fr) មានន័យថា៖ កាតនីមួយៗត្រូវមានទទឹងយ៉ាងតិច 220px (មិនអាចរួញតូចជាងនេះទេ)។ ប៉ុន្តែប្រសិនបើមានកន្លែងទំនេរ វាអាចពង្រីកធំរហូតដល់ 1fr។",
      "នៅពេលផ្សំជាមួយ repeat(auto-fit, ...)៖ នៅលើអេក្រង់ទូរស័ព្ទតូច (360px) វាធ្លាក់មកនៅ 1 Column។ នៅលើ Tablet (768px) វាឡើងទៅ 3 Columns។ នៅលើ Desktop ធំ វាអាចឡើងដល់ 4 ឬ 5 Columns ដោយស្វ័យប្រវត្តិ!",
      "ទាំងអស់នេះកើតឡើងដោយមិនចាំបាច់សរសេរ @media query សូម្បីតែមួយបន្ទាត់!"
    ],
    expectedResult: {
      description: "កាតនីមួយៗមានទំហំយ៉ាងតិច 220px។ ពេលពង្រីក Browser កាតនឹងពង្រីកតាម ហើយពេលបង្រួមតូចរហូតមិនល្មម 220px នោះចំនួន Columns នឹងថយចុះដោយស្វ័យប្រវត្តិ។",
      diagramText: `អេក្រង់ធំ (Desktop):
+-------------------+-------------------+-------------------+
| Card 1 (>= 220px) | Card 2 (>= 220px) | Card 3 (>= 220px) |
+-------------------+-------------------+-------------------+

អេក្រង់តូច (Mobile 360px):
+---------------------------------------+
| Card 1 (រីកពេញ 1fr)                    |
+---------------------------------------+
| Card 2 (រីកពេញ 1fr)                    |
+---------------------------------------+`
    },
    commonMistakes: [
      {
        mistake: "សរសេរ minmax(1fr, 200px) — ដាក់តម្លៃធំនៅខាងមុខ។",
        solution: "minmax(min, max) ត្រូវតែដាក់ទំហំតូចនៅមុខ និងទំហំធំនៅក្រោយជានិច្ច។ លើសពីនេះ 1fr មិនអាចប្រើក្នុងតម្លៃ min បានទេ (minmax(1fr, ...) មិនត្រឹមត្រូវតាមស្តង់ដារឡើយ)។"
      }
    ],
    quickChallenge: {
      question: "តើអ្វីកើតឡើងប្រសិនបើអ្នកប្រើ repeat(3, minmax(300px, 1fr)) នៅលើអេក្រង់ទូរស័ព្ទទទឹង 360px?",
      task: "ពន្យល់ពីមូលហេតុដែលវានៅតែ Overflow និងវិធីកែតម្រូវ។",
      hint: "វានៅតែបង្ខំបង្កើត 3 Columns x 300px = 900px លើសពី 360px បណ្តាលឱ្យធ្លាយ Overflow! វិធីកែគឺប្តូរលេខ 3 ទៅជា auto-fit។"
    }
  },
  {
    id: "sec-12-13",
    number: "12.13",
    title: "auto-fit និង auto-fill",
    englishTitle: "auto-fit vs. auto-fill — The Deep Dive",
    definition: "auto-fit និង auto-fill គឺជាពាក្យគន្លឹះពិសេសប្រើក្នុងអនុគមន៍ repeat() ដើម្បីឱ្យ Browser គណនាចំនួន Columns ដោយស្វ័យប្រវត្តិតាមទំហំ Container។\n- auto-fill: បង្កើត Column Tracks ឱ្យបានច្រើនបំផុតតាមដែលអាចធ្វើទៅបាន ហើយរក្សាទុក Empty Tracks (ទោះជាគ្មាន Item ក៏ទុកក្រឡាទទេដែរ)។\n- auto-fit: បង្កើត Tracks ដូចគ្នា ប៉ុន្តែវា Collapse (រំលាយ) Empty Tracks ចោល ហើយអនុញ្ញាតឱ្យ Tracks ដែលមាន Items ស្រាប់ពង្រីកខ្លួនពេញទំហំដែលនៅសល់។",
    purposeAndWhenToUse: "ប្រើ auto-fit នៅពេលអ្នកចង់ឱ្យកាតព័ត៌មាន ឬរូបភាពពង្រីកពេញទទឹងស្អាត (Stretch to fill) ទោះបីជាមានចំនួន Items តិចក៏ដោយ។ ប្រើ auto-fill ក្នុងករណីពិសេសដែលអ្នកចង់រក្សាទុកទំហំកាតឱ្យនៅថេរដដែល ហើយបន្សល់ទុកចន្លោះទំនេរនៅខាងស្តាំសម្រាប់ Items ថ្មីដែលនឹងបន្ថែមទៅថ្ងៃក្រោយ។",
    syntax: `/* auto-fit: Items នឹងពង្រីកសន្ធឹងពេញទំហំ */
grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));

/* auto-fill: រក្សាចន្លោះក្រឡាទទេ (Empty Tracks) */
grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));

/* គំរូការពារ Responsive លំដាប់សកល (Bulletproof Pattern): */
grid-template-columns: repeat(auto-fit, minmax(min(100%, 220px), 1fr));`,
    htmlExample: `<!-- ឧទាហរណ៍ដូចគ្នាបេះបិទ៖ Container ធំទូលាយ ប៉ុន្តែមាន Item តែ 2 ប៉ុណ្ណោះ -->
<div class="demo-group">
  <h4>1. auto-fill (រក្សា Empty Tracks ទុកចំហ)</h4>
  <div class="grid-fill">
    <div class="item-card">កាតទី១ (ទិន្នន័យគំរូ)</div>
    <div class="item-card">កាតទី២</div>
  </div>

  <h4 style="margin-top: 24px;">2. auto-fit (Collapse ក្រឡាទទេ ហើយ Items ពង្រីកពេញ)</h4>
  <div class="grid-fit">
    <div class="item-card">កាតទី១ (ទិន្នន័យគំរូ)</div>
    <div class="item-card">កាតទី២</div>
  </div>
</div>`,
    cssExample: `/* 1. AUTO-FILL: បង្កើត Empty Tracks បើទោះជាគ្មាន Item ក៏ដោយ */
.grid-fill {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 16px;
  background-color: #f1f5f9;
  padding: 16px;
  border-radius: 8px;
  border: 2px dashed #94a3b8;
}

/* 2. AUTO-FIT: Collapse ក្រឡាទទេចោល ហើយឱ្យកាតទាំង ២ ពង្រីកយកកន្លែង */
.grid-fit {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  background-color: #f1f5f9;
  padding: 16px;
  border-radius: 8px;
  border: 2px solid #3b82f6;
}

.item-card {
  background-color: #3b82f6;
  color: #ffffff;
  padding: 20px;
  border-radius: 6px;
  text-align: center;
  font-weight: 500;
}`,
    codeExplanation: [
      "ឧបមាថា Container មានទទឹង 900px ហើយ minmax(200px, 1fr)៖ Container អាចផ្ទុកបានរហូតដល់ 4 Columns។",
      "ជាមួយ auto-fill៖ ដោយសារមាន Item តែ ២ វាបង្កើត 4 Tracks ដដែល ដោយដាក់ Item ក្នុង Col 1 និង Col 2 ហើយទុក Col 3 និង Col 4 ជា Empty Tracks ចំហចោល។ កាតនីមួយៗមានទំហំប្រហែល 210px ប៉ុណ្ណោះ។",
      "ជាមួយ auto-fit៖ វាបង្កើត 4 Tracks ដែរ ប៉ុន្តែពេលឃើញ Col 3 និង Col 4 គ្មាន Item វាលុប (Collapse) ចោលភ្លាម! ហើយយកទំហំទំនេរទាំងអស់មកចែកឱ្យ Item 1 និង Item 2 ធ្វើឱ្យកាតទាំងពីររីកធំឡើង (ម្នាក់ៗជិត 440px) ពេញ Container យ៉ាងស្អាត!",
      "សម្គាល់សំខាន់៖ នៅពេលណាដែលចំនួន Items មានច្រើនពេញគ្រប់ Tracks នោះ auto-fit និង auto-fill នឹងផ្តល់លទ្ធផលដូចគ្នាបេះបិទ!",
      "ការពន្យល់ repeat(auto-fit, minmax(min(100%, 220px), 1fr))៖ min(100%, 220px) ធានាថានៅលើអេក្រង់តូចជាង 220px (ដូចជា Smartwatch ឬទូរស័ព្ទតូច) កាតនឹងមិនបង្ក Overflow ឡើយ ព្រោះវាជ្រើសរើសយក 100% នៃទទឹងអេក្រង់!"
    ],
    expectedResult: {
      description: "auto-fill បន្សល់ទុកចន្លោះទំនេរធំនៅខាងស្តាំ ចំណែក auto-fit ពង្រីកកាតទាំងពីរឱ្យពេញទទឹង Container ទាំងមូល។",
      diagramText: `Container ទទឹង 900px (មានកាតតែ 2):

[1. auto-fill] -> រក្សា Empty Tracks:
+-------------------+-------------------+-------------------+-------------------+
| Card 1 (210px)    | Card 2 (210px)    | [ Empty Track ]   | [ Empty Track ]   |
+-------------------+-------------------+-------------------+-------------------+

[2. auto-fit] -> Collapse Empty Tracks & Expand:
+---------------------------------------+---------------------------------------+
| Card 1 (រីកពេញ 440px)                  | Card 2 (រីកពេញ 440px)                  |
+---------------------------------------+---------------------------------------+`
    },
    commonMistakes: [
      {
        mistake: "ប្រើ auto-fill សម្រាប់ Card List ធម្មតា ធ្វើឱ្យពេលមានទិន្នន័យតិច កាតសល់កន្ទុយចន្លោះទទេមើលទៅដូចគេហទំព័រមិនទាន់ធ្វើរួច។",
        solution: "ភាគច្រើនលើសលប់ (៩០%) ក្នុង Web Design ជាក់ស្តែង គឺយើងត្រូវការ auto-fit ដើម្បីឱ្យ Layout មើលទៅពេញលេញ និងសមាមាត្រល្អជានិច្ច។"
      }
    ],
    quickChallenge: {
      question: "តើនៅពេលណាដែល auto-fit និង auto-fill ផ្តល់រូបរាងដូចគ្នាបេះបិទនៅលើ Browser?",
      task: "ឆ្លើយសំណួរ និងពន្យល់ពីហេតុផល។",
      hint: "នៅពេលដែលចំនួន Items មានច្រើនគ្រប់គ្រាន់ដើម្បីបំពេញពេញគ្រប់ Tracks ដែលអាចផ្ទុកបាន (គ្មាន Empty Track ណាត្រូវ Collapse ឡើយ)។"
    }
  },
  {
    id: "sec-12-14",
    number: "12.14",
    title: "បង្កើត Gallery ជាមួយ Grid",
    englishTitle: "Practical Project: Responsive Campus Gallery",
    definition: "ការអនុវត្តជាក់ស្តែងក្នុងការកសាង Campus Gallery ដ៏ស្រស់ស្អាត និង Responsive ពេញលេញដោយប្រើប្រាស់ CSS Grid សុទ្ធសាធ (Pure HTML5 & CSS)។ វិចិត្រសាលនេះមានរូបភាពយ៉ាងតិច ៦ សន្លឹក រួមទាំង Featured Image គ្រប 2 Columns x 2 Rows នៅលើ Desktop និងរៀបជា 1 Column ដោយស្វ័យប្រវត្តិនៅលើ Mobile។",
    purposeAndWhenToUse: "រៀនពីរបៀបរួមបញ្ចូលគ្នានូវ repeat(), auto-fit, minmax(), gap, aspect-ratio, object-fit និងការ Reset Grid Span លើ Mobile Screens ដើម្បីធានាថាក្រឡាមិនបែក ឬធ្លាយចេញក្រៅ។",
    syntax: `/* គ្រោងគន្លឹះនៃ Gallery */
.gallery-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 16px;
}

@media (min-width: 768px) {
  .featured-photo {
    grid-column: span 2;
    grid-row: span 2;
  }
}`,
    htmlExample: `<!DOCTYPE html>
<html lang="km">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>វិចិត្រសាលសាកលវិទ្យាល័យ (Campus Gallery)</title>
  <link rel="stylesheet" href="gallery.css">
</head>
<body>

  <header class="gallery-header">
    <h2>វិចិត្រសាលសកម្មភាពនិស្សិត និងបរិវេណសាលា (Campus Gallery)</h2>
    <p>កម្រងរូបភាពសកម្មភាពសិក្សា និងការស្រាវជ្រាវ (ទិន្នន័យរូបភាពគំរូ)</p>
  </header>

  <main class="gallery-container">
    <!-- រូបភាពទី១: Featured Item (លេចធ្លោលើ Tablet/Desktop) -->
    <figure class="gallery-item featured">
      <img src="https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=800&auto=format&fit=crop&q=80" 
           alt="អគារបណ្ណាល័យកណ្តាល និងទីធ្លាសាកលវិទ្យាល័យ" 
           loading="lazy">
      <figcaption>អគារបណ្ណាល័យកណ្តាល និងទីធ្លាសាកលវិទ្យាល័យ (Featured)</figcaption>
    </figure>

    <!-- រូបភាពទី២ -->
    <figure class="gallery-item">
      <img src="https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=600&auto=format&fit=crop&q=80" 
           alt="និស្សិតពិភាក្សាមេរៀនក្នុងបន្ទប់សិក្ខាសាលា" 
           loading="lazy">
      <figcaption>និស្សិតពិភាក្សាមេរៀនជាក្រុម</figcaption>
    </figure>

    <!-- រូបភាពទី៣ -->
    <figure class="gallery-item">
      <img src="https://images.unsplash.com/photo-1562774053-701939374585?w=600&auto=format&fit=crop&q=80" 
           alt="ទិដ្ឋភាពអគារសិក្សាពេលព្រឹកព្រលឹម" 
           loading="lazy">
      <figcaption>បរិវេណអគារសិក្សាព័ត៌មានវិទ្យា</figcaption>
    </figure>

    <!-- រូបភាពទី៤ -->
    <figure class="gallery-item">
      <img src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600&auto=format&fit=crop&q=80" 
           alt="ការពិសោធន៍កូដក្នុងបន្ទប់ Lab កុំព្យូទ័រ" 
           loading="lazy">
      <figcaption>ម៉ោងអនុវត្តជាក់ស្តែងក្នុង Lab</figcaption>
    </figure>

    <!-- រូបភាពទី៥ -->
    <figure class="gallery-item">
      <img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=600&auto=format&fit=crop&q=80" 
           alt="និស្សិតធ្វើបទបង្ហាញគម្រោងបញ្ចប់ការសិក្សា" 
           loading="lazy">
      <figcaption>បទបង្ហាញគម្រោង Final Project</figcaption>
    </figure>

    <!-- រូបភាពទី៦ -->
    <figure class="gallery-item">
      <img src="https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?w=600&auto=format&fit=crop&q=80" 
           alt="ក្លឹបសិក្សាបច្ចេកវិទ្យា និងការបង្កើតថ្មី" 
           loading="lazy">
      <figcaption>ក្លឹបបង្កើតគំនិតច្នៃប្រឌិត (Innovation Club)</figcaption>
    </figure>
  </main>

</body>
</html>`,
    cssExample: `/* Global Box Sizing Reset */
*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: 'Kantumruy Pro', sans-serif;
  background-color: #0f172a;
  color: #f8fafc;
  padding: 24px 16px;
}

.gallery-header {
  text-align: center;
  max-width: 800px;
  margin: 0 auto 32px;
}

.gallery-header h2 {
  font-size: 24px;
  color: #38bdf8;
  margin-bottom: 8px;
}

.gallery-header p {
  color: #94a3b8;
  font-size: 15px;
}

/* 1. GRID CONTAINER សម្រាប់ GALLERY */
.gallery-container {
  display: grid;
  /* ប្រើ min(100%, 260px) សម្រាប់ Responsive សុវត្ថិភាព */
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 260px), 1fr));
  gap: 16px;
  max-width: 1200px;
  margin: 0 auto;
}

/* 2. GALLERY ITEM (FIGURE) */
.gallery-item {
  position: relative;
  background-color: #1e293b;
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid #334155;
  display: flex;
  flex-direction: column;
}

/* 3. RESPONSIVE IMAGE ជាមួយ ASPECT-RATIO & OBJECT-FIT */
.gallery-item img {
  width: 100%;
  height: 100%;
  aspect-ratio: 4 / 3;
  object-fit: cover; /* រក្សាសមាមាត្ររូបភាព មិនឱ្យសំប៉ែត ឬខូចទ្រង់ទ្រាយ */
  display: block;
  transition: transform 0.3s ease;
}

.gallery-item:hover img {
  transform: scale(1.04);
}

.gallery-item figcaption {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(to top, rgba(0,0,0,0.85), transparent);
  color: #ffffff;
  padding: 16px 12px 10px;
  font-size: 14px;
  line-height: 1.4;
}

/* 4. FEATURED ITEM នៅលើ TABLET/DESKTOP (>= 768px) */
@media (min-width: 768px) {
  .gallery-item.featured {
    grid-column: span 2;
    grid-row: span 2;
  }

  .gallery-item.featured img {
    aspect-ratio: auto;
    height: 100%;
  }
}

/* នៅលើ Mobile (< 768px) មិនមាន Span ទេ គឺរត់ 1 Column ស្អាតស្មើគ្នាទាំងអស់! */`,
    codeExplanation: [
      "grid-template-columns: repeat(auto-fit, minmax(min(100%, 260px), 1fr))៖ ធានាថារូបភាពសម្របខ្លួនដោយរលូនលើគ្រប់ទំហំអេក្រង់ ចាប់ពី 360px ដល់ 1280px+។",
      "aspect-ratio: 4 / 3 និង object-fit: cover៖ ធានាថារូបភាពទាំងអស់មានកម្ពស់ស្មើបាតគ្នាស្អាត មិនខូចសមាមាត្ររូបភាពដើមឡើយ។",
      "@media (min-width: 768px)៖ យើងកំណត់ span 2 លើ .featured តែនៅពេលអេក្រង់ធំល្មមប៉ុណ្ណោះ។ នេះជាវិធានការដោះស្រាយកំហុសដ៏សំខាន់ បើដាក់ span 2 នៅលើ Mobile តូច វានឹងបង្ខំឱ្យ Browser បង្កើត Column ទីពីរដែលមើលមិនឃើញ ធ្វើឱ្យ Layout ធ្លាយផ្ដេក!",
      "loading=\"lazy\" និង alt text៖ បង្កើន Accessibility និងល្បឿន Performance នៃគេហទំព័រ។"
    ],
    expectedResult: {
      description: "លើ Desktop៖ រូបទី១ (Featured) មានទំហំធំគ្រប 2 Cols x 2 Rows នៅជ្រុងឆ្វេង រីឯរូប ៥ ផ្សេងទៀតតម្រៀបបំពេញជុំវិញ។ លើ Mobile៖ រូបភាពទាំងអស់ធ្លាក់មកនៅ 1 Column ស្អាតបាតតាមលំដាប់លំដោយ។",
      diagramText: `Desktop Layout (>= 768px):
+-----------------------------------+-----------------+-----------------+
|                                   | រូបភាព ២        | រូបភាព ៣        |
| រូបភាព ១ (FEATURED PHOTO)          +-----------------+-----------------+
| (grid-column: span 2)              | រូបភាព ៤        | រូបភាព ៥        |
| (grid-row: span 2)                 +-----------------+-----------------+
|                                   | រូបភាព ៦        | [ auto-fit ]    |
+-----------------------------------+-----------------+-----------------+`
    },
    commonMistakes: [
      {
        mistake: "ភ្លេចដាក់ object-fit: cover លើរូបភាព ធ្វើឱ្យរូបភាពដែលកាត់តាម Grid ទាញយឺតសំប៉ែតខូចសោភ័ណភាព។",
        solution: "ដាក់ width: 100%; height: 100%; object-fit: cover; និង aspect-ratio លើរូបភាពជានិច្ច!"
      },
      {
        mistake: "ដាក់ grid-column: span 2 នៅខាងក្រៅ Media Query ធ្វើឱ្យទូរស័ព្ទតូច 360px កើតមាន Horizontal Scrollbar។",
        solution: "ប្រើ Mobile-First៖ សរសេរ span 2 នៅខាងក្នុង @media (min-width: 768px) ប៉ុណ្ណោះ។"
      }
    ],
    quickChallenge: {
      question: "ហេតុអ្វីបានជាយើងគួរប្រើ aspect-ratio: 4 / 3 រួមជាមួយ object-fit: cover នៅក្នុង Grid Gallery?",
      task: "ពន្យល់ពីផលប្រយោជន៍ចំពោះការទប់ស្កាត់ Layout Shift (CLS)។",
      hint: "វាជួយកក់កន្លែងទុកមុនសម្រាប់រូបភាពកុំឱ្យទំព័ររលាក់ (Zero CLS) និងរក្សារូបភាពមិនឱ្យខូចសមាមាត្រ!"
    }
  },
  {
    id: "sec-12-15",
    number: "12.15",
    title: "បង្កើត Dashboard Layout ជាមួយ Grid",
    englishTitle: "Practical Project: Responsive Student Dashboard",
    definition: "ការកសាងផ្ទាំងគ្រប់គ្រងព័ត៌មាននិស្សិត (Student Dashboard) ពេញលេញមួយដោយប្រើប្រាស់ CSS Grid ទំនើប រួមមាន Header, Sidebar Navigation, Main Statistics Cards, Enrolled Courses Section និង Footer ដោយប្រើប្រាស់បច្ចេកទេស grid-template-areas, grid-area និង Nested Grids។",
    purposeAndWhenToUse: "រៀនពីវិធីរៀបចំ Architecture នៃគេហទំព័រកម្រិត Real-world Web Application ដោយប្រើ Grid ធំសម្រាប់រចនាសម្ព័ន្ធទំព័រ (Macro Layout) និងប្រើ Nested Grid សម្រាប់ Stats Cards (Micro Layout) ព្រមទាំងប្តូរទៅជា Single Column នៅលើអេក្រង់ទូរស័ព្ទដៃ។",
    syntax: `/* ការប្រើ grid-template-areas មើលដូចគំនូរ Layout */
.dashboard-layout {
  display: grid;
  grid-template-columns: 240px 1fr;
  grid-template-rows: 70px 1fr 50px;
  grid-template-areas:
    "header  header"
    "sidebar main"
    "footer  footer";
}

/* ភ្ជាប់កូនៗទៅកាន់ឈ្មោះ Area នីមួយៗ */
.site-header { grid-area: header; }
.site-nav    { grid-area: sidebar; }
.site-main   { grid-area: main; }
.site-footer { grid-area: footer; }`,
    htmlExample: `<!DOCTYPE html>
<html lang="km">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ផ្ទាំងគ្រប់គ្រងនិស្សិត (Student Dashboard)</title>
  <link rel="stylesheet" href="dashboard.css">
</head>
<body>

  <div class="dashboard-grid">
    <!-- 1. HEADER -->
    <header class="dash-header">
      <div class="header-brand">
        <h1>វិទ្យាស្ថានបច្ចេកវិទ្យាព័ត៌មាន (IT Portal)</h1>
      </div>
      <div class="header-user">
        <span>និស្សិត៖ ហេង សំណាង (ទិន្នន័យគំរូ)</span>
      </div>
    </header>

    <!-- 2. SIDEBAR NAVIGATION -->
    <nav class="dash-sidebar" aria-label="ម៉ឺនុយមេ">
      <ul class="nav-links">
        <li><a href="#" class="active">ផ្ទាំងគ្រប់គ្រង</a></li>
        <li><a href="#">មុខវិជ្ជាចុះឈ្មោះ</a></li>
        <li><a href="#">កាលវិភាគប្រឡង</a></li>
        <li><a href="#">លទ្ធផលសិក្សា</a></li>
        <li><a href="#">កំណត់គណនី</a></li>
      </ul>
    </nav>

    <!-- 3. MAIN CONTENT -->
    <main class="dash-main">
      <section class="overview-section">
        <h2>ទិដ្ឋភាពទូទៅនៃការសិក្សា</h2>
        
        <!-- NESTED GRID: 4 Statistics Cards -->
        <div class="stats-nested-grid">
          <div class="stat-card">
            <span class="stat-title">ក្រេឌីតសរុប</span>
            <span class="stat-value">៦៤ / ១២០</span>
            <span class="stat-sub">ឆមាសទី១ ឆ្នាំទី២</span>
          </div>
          <div class="stat-card">
            <span class="stat-title">GPA មធ្យមភាគ</span>
            <span class="stat-value">៣.៨២</span>
            <span class="stat-sub">និទ្ទេសល្អប្រសើរ (Very Good)</span>
          </div>
          <div class="stat-card">
            <span class="stat-title">មុខវិជ្ជាកំពុងរៀន</span>
            <span class="stat-value">៥ មុខវិជ្ជា</span>
            <span class="stat-sub">១៥ ម៉ោងក្នុងមួយសប្តាហ៍</span>
          </div>
          <div class="stat-card">
            <span class="stat-title">វត្តមានសរុប</span>
            <span class="stat-value">៩៨%</span>
            <span class="stat-sub">អនុវត្តទៀងទាត់</span>
          </div>
        </div>
      </section>

      <!-- COURSE LIST SECTION -->
      <section class="courses-section">
        <h3>មុខវិជ្ជាកំពុងសិក្សាក្នុងឆមាសនេះ (ទិន្នន័យគំរូ)</h3>
        <div class="courses-nested-grid">
          <article class="course-item-card">
            <h4>CS201: Web Development II (CSS Grid)</h4>
            <p>សាស្រ្តាចារ្យ៖ សុខ ចាន់ថន | បន្ទប់៖ Lab 302</p>
            <div class="progress-bar"><div class="progress-fill" style="width: 75%;"></div></div>
          </article>
          <article class="course-item-card">
            <h4>CS202: Data Structures & Algorithms</h4>
            <p>សាស្រ្តាចារ្យ៖ គង់ សុជាតិ | បន្ទប់៖ Room 405</p>
            <div class="progress-bar"><div class="progress-fill" style="width: 60%;"></div></div>
          </article>
        </div>
      </section>
    </main>

    <!-- 4. FOOTER -->
    <footer class="dash-footer">
      <p>&copy; ២០២៦ មហាវិទ្យាល័យវិទ្យាសាស្ត្រ និងបច្ចេកវិទ្យា។ រក្សាសិទ្ធិគ្រប់យ៉ាង។</p>
    </footer>
  </div>

</body>
</html>`,
    cssExample: `/* CSS Reset */
*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: 'Kantumruy Pro', sans-serif;
  background-color: #f1f5f9;
  color: #1e293b;
  min-height: 100vh;
}

/* 1. PARENT GRID: Macro Layout ជាមួយ grid-template-areas */
.dashboard-grid {
  display: grid;
  min-height: 100vh;
  /* Mobile First: 1 Column */
  grid-template-columns: 1fr;
  grid-template-rows: auto auto 1fr auto;
  grid-template-areas:
    "header"
    "sidebar"
    "main"
    "footer";
}

/* កំណត់ Area Name ទៅតាម Semantic Elements */
.dash-header  { grid-area: header; }
.dash-sidebar { grid-area: sidebar; }
.dash-main    { grid-area: main; }
.dash-footer  { grid-area: footer; }

/* HEADER STYLING */
.dash-header {
  background-color: #1e3a8a;
  color: #ffffff;
  padding: 16px 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 2px solid #1d4ed8;
}

.dash-header h1 {
  font-size: 18px;
}

/* SIDEBAR STYLING */
.dash-sidebar {
  background-color: #ffffff;
  border-right: 1px solid #e2e8f0;
  padding: 20px 16px;
}

.nav-links {
  list-style: none;
}

.nav-links li {
  margin-bottom: 8px;
}

.nav-links a {
  display: block;
  padding: 10px 14px;
  color: #475569;
  text-decoration: none;
  border-radius: 6px;
  font-weight: 500;
  transition: all 0.2s ease;
}

.nav-links a:hover,
.nav-links a.active {
  background-color: #eff6ff;
  color: #1d4ed8;
  font-weight: 600;
}

/* MAIN CONTENT STYLING */
.dash-main {
  padding: 24px;
}

.dash-main h2 {
  font-size: 20px;
  margin-bottom: 16px;
  color: #0f172a;
}

/* NESTED GRID 1: 4 Statistics Cards */
.stats-nested-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  margin-bottom: 28px;
}

.stat-card {
  background-color: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 18px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.05);
  display: flex;
  flex-direction: column;
}

.stat-title {
  font-size: 13px;
  color: #64748b;
  margin-bottom: 6px;
}

.stat-value {
  font-size: 22px;
  font-weight: 700;
  color: #0284c7;
  margin-bottom: 4px;
}

.stat-sub {
  font-size: 12px;
  color: #10b981;
}

/* NESTED GRID 2: Courses Section */
.courses-section h3 {
  font-size: 17px;
  margin-bottom: 14px;
}

.courses-nested-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 16px;
}

.course-item-card {
  background-color: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 18px;
}

.course-item-card h4 {
  font-size: 15px;
  color: #1e293b;
  margin-bottom: 6px;
}

.course-item-card p {
  font-size: 13px;
  color: #64748b;
  margin-bottom: 12px;
}

.progress-bar {
  width: 100%;
  height: 6px;
  background-color: #e2e8f0;
  border-radius: 3px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background-color: #2563eb;
}

/* FOOTER */
.dash-footer {
  background-color: #ffffff;
  border-top: 1px solid #e2e8f0;
  padding: 14px 24px;
  text-align: center;
  font-size: 13px;
  color: #64748b;
}

/* 2. DESKTOP RESPONSIVE (>= 992px) */
@media (min-width: 992px) {
  .dashboard-grid {
    grid-template-columns: 240px 1fr;
    grid-template-rows: 64px 1fr 50px;
    grid-template-areas:
      "header  header"
      "sidebar main"
      "footer  footer";
  }
}`,
    codeExplanation: [
      "grid-template-areas ផ្តល់នូវភាពងាយស្រួលអស្ចារ្យ៖ យើងអាចមើលឃើញរូបរាង Layout ផ្ទាល់ក្នុងកូដ CSS ដូចជាគំនូសព្រាង (header header / sidebar main / footer footer)។",
      "Mobile-First Approach៖ នៅលើអេក្រង់តូច យើងរៀប areas ជាជួរឈរទោលបញ្ឈរ (header / sidebar / main / footer) ធានាថាមិនមាន Overflow និងមាន Keyboard / DOM order ត្រឹមត្រូវ។",
      "Nested Grids លើកាត Stats និង Courses៖ ប្រើ repeat(auto-fit, minmax(200px, 1fr)) ធ្វើឱ្យកាតស្ថិតិទាំង ៤ សម្របខ្លួនយ៉ាងរលូនពី 1 Column លើទូរស័ព្ទ ទៅ 2 Columns លើ Tablet និង 4 Columns លើ Desktop!"
    ],
    expectedResult: {
      description: "នៅលើ Desktop (>=992px)៖ Header ពេញទទឹងខាងលើ, Sidebar ទទឹង 240px នៅឆ្វេង, Main Content នៅស្តាំ និង Footer ពេញទទឹងខាងក្រោម។ នៅខាងក្នុង Main មានកាតស្ថិតិ ៤ បែងចែកស្មើគ្នា។ លើ Mobile (<992px)៖ រៀបជា Single Column ចុះក្រោមយ៉ាងរលូន។",
      diagramText: `Desktop Layout (>= 992px):
+-------------------------------------------------------------+
| Header (grid-area: header)                                  |
+------------------------------+------------------------------+
| Sidebar (240px)              | Main Content (1fr)           |
| (grid-area: sidebar)         | [Stat 1] [Stat 2] [Stat 3]...|
|                              | [Courses Nested Grid]        |
+------------------------------+------------------------------+
| Footer (grid-area: footer)                                  |
+-------------------------------------------------------------+`
    },
    commonMistakes: [
      {
        mistake: "ភ្លេចដាក់ឈ្មោះ Area ក្នុង double quotes ឬចំនួន columns ក្នុងជួរនីមួយៗនៃ grid-template-areas មិនស្មើគ្នា។",
        solution: "រាល់ string នៃជួរនីមួយៗត្រូវតែមានចំនួន Area Words ស្មើគ្នាបេះបិទ! បើជួរលើមាន 2 ពាក្យ ('header header') នោះជួរក្រោមត្រូវតែមាន 2 ពាក្យដែរ ('sidebar main')។"
      }
    ],
    quickChallenge: {
      question: "តើអ្នកអាចទុកចន្លោះ Cell ណាមួយឱ្យនៅទទេដោយរបៀបណា នៅក្នុង grid-template-areas?",
      task: "ពន្យល់ពីនិមិត្តសញ្ញាដែលត្រូវប្រើ។",
      hint: "ប្រើសញ្ញាចុច (Period/Dot .) ដូចជា 'sidebar .' ដើម្បីទុកក្រឡានោះជា Empty Cell!"
    }
  }
];
