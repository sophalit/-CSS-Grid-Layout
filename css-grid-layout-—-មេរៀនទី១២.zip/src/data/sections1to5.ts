import { LessonSection } from '../types';

export const SECTIONS_1_TO_5: LessonSection[] = [
  {
    id: "sec-12-1",
    number: "12.1",
    title: "តើ CSS Grid ជាអ្វី?",
    englishTitle: "What is CSS Grid Layout?",
    definition: "CSS Grid Layout (ហៅកាត់ថា Grid) គឺជាប្រព័ន្ធរៀបចំ Layout ពីរវិមាត្រ (Two-Dimensional Layout System) ដ៏មានឥទ្ធិពលបំផុតនៅក្នុង CSS ទំនើប។ វាអនុញ្ញាតឱ្យយើងគ្រប់គ្រងការតម្រៀបធាតុទាំងលើជួរដេក (Rows) និងជួរឈរ (Columns) ក្នុងពេលដំណាលគ្នា ដោយមិនបាច់ពឹងផ្អែកលើ float, positioning ឬ table ឡើយ។",
    purposeAndWhenToUse: "ប្រើប្រាស់នៅពេលអ្នកចង់បង្កើតរចនាសម្ព័ន្ធទំព័រទាំងមូល (Page Layout) ដូចជា Header, Sidebar, Main Content, Footer ឬ Grid ប្រព័ន្ធកាត (Card Grid) និង Gallery ដែលទាមទារការតម្រឹមទាំងជួរដេក និងជួរឈរឱ្យត្រូវបន្ទាត់គ្នាត្រង់ភ្លឹង។ គួរជ្រើសរើស Grid នៅពេល Layout មានរាងជាក្រឡាចត្រង្គ 2D ចំណែក Flexbox គឺល្អសម្រាប់ One-Dimensional (1D) ក្នុងជួរតែមួយ (ជួរដេក ឬជួរឈរតែម្យ៉ាង)។",
    syntax: `/* កំណត់ទៅលើ Parent Element (Container) */
.layout-container {
  display: grid;
  grid-template-columns: 260px 1fr; /* ជួរឈរ: Sidebar និង Main Content */
  grid-template-rows: auto 1fr auto; /* ជួរដេក: Header, Content, Footer */
  gap: 20px;                         /* គម្លាតរវាងក្រឡា */
}`,
    htmlExample: `<!-- បង្ហាញការប្រើ Grid រួមគ្នាជាមួយ Flexbox -->
<div class="dashboard-shell">
  <header class="dash-header">
    <h2>ប្រព័ន្ធគ្រប់គ្រងនិស្សិត (Student Portal)</h2>
    <!-- ប្រើ Flexbox នៅខាងក្នុង Header សម្រាប់រៀបចំប៊ូតុង និង Profile -->
    <div class="user-nav">
      <span>សួស្តី, វីរៈ (និស្សិតគំរូ)</span>
      <button class="btn-logout">ចាកចេញ</button>
    </div>
  </header>

  <aside class="dash-sidebar">
    <nav class="side-menu">
      <a href="#" class="active">ផ្ទាំងគ្រប់គ្រង</a>
      <a href="#">មុខវិជ្ជា</a>
      <a href="#">កាលវិភាគ</a>
    </nav>
  </aside>

  <main class="dash-main">
    <h3>កាតព័ត៌មាននិស្សិត (Student Overview)</h3>
    <div class="stat-card">GPA មធ្យមភាគ: 3.85</div>
  </main>
</div>`,
    cssExample: `/* Global Reset សម្រាប់កាត់បន្ថយបញ្ហាគណនាទំហំ */
*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

/* Parent: CSS Grid គ្រប់គ្រង Layout ធំជារួម (2D) */
.dashboard-shell {
  display: grid;
  grid-template-columns: 240px 1fr;
  grid-template-rows: 70px auto;
  gap: 16px;
  min-height: 320px;
  background-color: #f8fafc;
  padding: 16px;
  font-family: 'Kantumruy Pro', sans-serif;
}

/* Header គ្របកាត់ទាំង 2 ជួរឈរ */
.dash-header {
  grid-column: 1 / -1;
  background-color: #1e293b;
  color: #ffffff;
  padding: 16px 20px;
  border-radius: 8px;
  /* ប្រើ Flexbox នៅខាងក្នុង Header សម្រាប់តម្រឹមធាតុ 1D ផ្ដេក */
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.user-nav {
  display: flex;
  gap: 12px;
  align-items: center;
}

.dash-sidebar {
  background-color: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 16px;
}

.dash-main {
  background-color: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 20px;
}`,
    codeExplanation: [
      "display: grid: បង្កើត Grid Formatting Context លើ .dashboard-shell ដោយប្រែក្លាយកូនផ្ទាល់របស់វាទាំងអស់ឱ្យទៅជា Grid Items។",
      "grid-template-columns: 240px 1fr: បង្កើត 2 ជួរឈរ — ជួរទី១ មានទទឹងថេរ 240px សម្រាប់ Sidebar និងជួរទី២ ប្រើ 1fr យកទំហំទំនេរដែលនៅសល់សម្រាប់ Main Content។",
      "grid-column: 1 / -1 លើ Header: បញ្ជាឱ្យ Header លាតសន្ធឹងចាប់ពីបន្ទាត់ទី១ រហូតដល់បន្ទាត់ចុងក្រោយបង្អស់ (គ្របលើជួរឈរទាំងពីរ)។",
      "display: flex ក្នុង Header: បង្ហាញការរួមបញ្ចូលគ្នាដ៏ល្អឥតខ្ចោះ — Grid គ្រប់គ្រងគ្រោងធំនៃទំព័រ (Macro Layout) ខណៈ Flexbox គ្រប់គ្រងការតម្រៀបផ្ដេកនៃប៊ូតុង និងអត្ថបទក្នុង Header (Micro Layout)។"
    ],
    expectedResult: {
      description: "Header ស្ថិតនៅខាងលើបង្អស់ពេញទទឹង។ នៅខាងក្រោម Header មាន Sidebar ទទឹង 240px នៅឆ្វេង និង Main Content នៅខាងស្តាំលាតពេញទទឹងដែលនៅសល់ ដោយមានគម្លាត 16px ចន្លោះក្រឡា។",
      diagramText: `+-------------------------------------------------------------+
| Line 1                      HEADER                   Line 3 |
| [Student Portal]                     [User Profile (Flex)]  |
+------------------------------+------------------------------+
| Line 1 (Col 1) Line 2 (Col 2)| Line 2 (Col 2) Line 3 (Col 3)|
|           SIDEBAR            |         MAIN CONTENT         |
|           (240px)            |             (1fr)            |
+------------------------------+------------------------------+`
    },
    commonMistakes: [
      {
        mistake: "ព្យាយាមប្រើ Flexbox ធ្វើ Layout ទំព័រទាំងមូល ដោយប្រើ float ឬ flex-wrap ធ្វើឱ្យ Columns មិនត្រង់ជួរគ្នា។",
        solution: "ប្រើ CSS Grid សម្រាប់ Layout ធំរួម 2D (ជួរដេក + ជួរឈរ) ហើយប្រើ Flexbox សម្រាប់តែសមាសភាគខាងក្នុង (Inline/1D UI) ដូចជា Navigation Links ឬ Button Groups។"
      },
      {
        mistake: "គិតថា Flexbox flex-wrap អាចជំនួស Grid បាន។",
        solution: "Flexbox wrap គិតតែលើបន្ទាត់នីមួយៗដាច់ដោយឡែកពីគ្នា (បើជួរចុងក្រោយមាន item តែមួយ វានឹងពង្រីក ឬនៅកណ្តាល មិនត្រូវបន្ទាត់ជាមួយជួរលើឡើយ)។ Grid រក្សា Alignment តាមជួរឈរ និងជួរដេកយ៉ាងរឹងមាំ។"
      }
    ],
    quickChallenge: {
      question: "តើនៅពេលណាដែលយើងគួរប្រើ CSS Grid ជាជាង Flexbox?",
      task: "សរសេរ selector .page-shell ដែលកំណត់ 3 ជួរឈរទំហំស្មើគ្នា និងគម្លាត 20px ដោយប្រើ Grid។",
      hint: "ប្រើ display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;"
    }
  },
  {
    id: "sec-12-2",
    number: "12.2",
    title: "Grid Container និង Grid Items",
    englishTitle: "Grid Container and Grid Items",
    definition: "នៅក្នុងប្រព័ន្ធ CSS Grid មានការបែងចែកកម្រិតច្បាស់លាស់រវាង Parent និង Children៖ មេផ្ទាល់ដែលបានប្រកាស display: grid ហៅថា Grid Container ហើយកូនផ្ទាល់តែមួយកម្រិត (Direct Children) នៅក្នុង Normal Flow ហៅថា Grid Items។",
    purposeAndWhenToUse: "ស្វែងយល់ដើម្បីកុំឱ្យច្រឡំទីតាំងសរសេរ CSS Properties។ Properties ដូចជា grid-template-columns, grid-template-rows និង gap ត្រូវសរសេរលើ Container។ ចំណែក Properties ដូចជា grid-column, grid-row ត្រូវសរសេរលើ Item នីមួយៗ។ លើសពីនេះ ត្រូវដឹងថាកូនចៅខាងក្នុង (Nested Elements) មិនក្លាយជា Grid Items ដោយស្វ័យប្រវត្តិទេ។",
    syntax: `/* សរសេរលើ Parent (Container) */
.student-grid {
  display: grid;
}

/* សរសេរលើ Direct Children (Items) */
.student-card {
  /* អាចកំណត់ទីតាំង និងការលាតសន្ធឹង */
  grid-column: span 1;
}`,
    htmlExample: `<div class="student-grid"> <!-- GRID CONTAINER -->
  
  <!-- ITEM 1: Direct Child -->
  <article class="student-card">
    <h4>សុខ សម្បត្តិ (ទិន្នន័យគំរូ)</h4>
    <p>ដេប៉ាតឺម៉ង់៖ វិទ្យាសាស្ត្រកុំព្យូទ័រ</p>
    <div class="badge-group"> <!-- NOT A GRID ITEM of .student-grid -->
      <span class="badge">ឆ្នាំទី២</span>
      <span class="badge">ឆមាសទី១</span>
    </div>
  </article>

  <!-- ITEM 2: Direct Child -->
  <article class="student-card">
    <h4>ចាន់ ធីតា (ទិន្នន័យគំរូ)</h4>
    <p>ដេប៉ាតឺម៉ង់៖ អភិវឌ្ឍន៍គេហទំព័រ</p>
    <div class="badge-group">
      <span class="badge">ឆ្នាំទី២</span>
      <span class="badge">ឆមាសទី១</span>
    </div>
  </article>

</div>`,
    cssExample: `/* 1. GRID CONTAINER */
.student-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
  background-color: #f1f5f9;
  padding: 20px;
  border-radius: 8px;
}

/* 2. GRID ITEMS (កូនផ្ទាល់ .student-card ទាំងពីរ) */
.student-card {
  background-color: #ffffff;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  padding: 16px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

/* 3. NESTED ELEMENTS (មិនមែនជា Grid Items របស់ .student-grid ទេ) */
.badge-group {
  margin-top: 10px;
  display: flex; /* យើងអាចប្រើ Flexbox ក្នុងកាតនេះបាន */
  gap: 8px;
}

.badge {
  background-color: #e0f2fe;
  color: #0369a1;
  font-size: 13px;
  padding: 4px 8px;
  border-radius: 4px;
}`,
    codeExplanation: [
      ".student-grid គឺជា Grid Container ដោយសារវាមាន display: grid។",
      "<article class=\"student-card\"> ទាំងពីរគឺជាកូនបង្កើតផ្ទាល់ (Direct Children) ដូច្នេះពួកវាទទួលឥទ្ធិពល និងតម្រៀបតាម Columns របស់ Grid ដោយស្វ័យប្រវត្តិ។",
      "<div class=\"badge-group\"> និង <span> ខាងក្នុង គឺជាចៅ (Nested Elements) មិនមែនជា Grid Items របស់ .student-grid ឡើយ ដូច្នេះពួកវានៅរក្សា Normal Block/Inline Flow ដដែល លុះត្រាតែយើងកំណត់ពួកវាជា flex ឬ grid បន្ថែម។"
    ],
    expectedResult: {
      description: "កាតនិស្សិតគំរូទាំងពីរតម្រៀបជាពីរជួរឈរទន្ទឹមគ្នា។ ធាតុខាងក្នុងកាតរក្សារចនាសម្ព័ន្ធធម្មតារបស់ខ្លួន ដោយមិនត្រូវបានបំបែកជា Grid Items របស់ Container មេឡើយ។",
      diagramText: `+======================== GRID CONTAINER (.student-grid) ========================+
|                                                                                |
|  +---------------- GRID ITEM 1 ----------------+  +---------------- GRID ITEM 2 ----------------+  |
|  | សុខ សម្បត្តិ (ទិន្នន័យគំរូ)                   |  | ចាន់ ធីតា (ទិន្នន័យគំរូ)                    |  |
|  | [ដេប៉ាតឺម៉ង់...]                             |  | [ដេប៉ាតឺម៉ង់...]                             |  |
|  | (Nested Element: .badge-group)              |  | (Nested Element: .badge-group)              |  |
|  +---------------------------------------------+  +---------------------------------------------+  |
|                                                                                |
+================================================================================+`
    },
    commonMistakes: [
      {
        mistake: "ព្យាយាមដាក់ grid-column ទៅលើ <p> ឬ <span> ដែលនៅខាងក្នុង .student-card ដោយសង្ឃឹមថាវានឹងរត់ក្នុង Grid មេ។",
        solution: "ចងចាំជានិច្ច៖ មានតែកូនផ្ទាល់ (Direct Children) ប៉ុណ្ណោះដែលជា Grid Items។ បើចង់ឱ្យកូនខាងក្នុងជា Grid ត្រូវប្រកាស display: grid លើកាតនោះបន្ថែមទៀត (Nested Grid)។"
      }
    ],
    quickChallenge: {
      question: "ប្រសិនបើ <section> មាន <div> ហើយក្នុង <div> មាន <button> បី តើ button ទាំងបីជា Grid Items របស់ <section> ដែរឬទេ?",
      task: "ពន្យល់ហេតុផល និងប្រាប់ថាតើអ្នកត្រូវធ្វើអ្វីដើម្បីឱ្យ button ទាំងបីក្លាយជា Grid Items។",
      hint: "ទេ! ព្រោះ button ជាកូនរបស់ div។ ដើម្បីឱ្យពួកវាក្លាយជា Grid Items ត្រូវដាក់ display: grid លើ div ផ្ទាល់។"
    }
  },
  {
    id: "sec-12-3",
    number: "12.3",
    title: "display: grid",
    englishTitle: "display: grid — The Grid Context",
    definition: "display: grid គឺជា CSS Declaration ដំបូងបង្អស់ដែលចាំបាច់ត្រូវសរសេរលើ Parent Element ដើម្បីបើកដំណើរការ Grid Formatting Context។ វាប្រែក្លាយ Block Element ធម្មតាឱ្យទៅជា Grid Container។",
    purposeAndWhenToUse: "ប្រើប្រាស់នៅពេលអ្នកចាប់ផ្តើមចង់រៀបចំ Layout ដោយប្រើ Grid។ សំខាន់ត្រូវចាំថា៖ ការដាក់ display: grid តែមួយមុខ មិនទាន់បង្កើត 2 ឬ 3 ជួរឈរដោយស្វ័យប្រវត្តិទេ គឺវាបង្កើត Implicit Single Column មួយដែលមាន Rows តម្រៀបចុះក្រោមដូច Block Elements ដែរ រហូតដល់យើងកំណត់ grid-template-columns។",
    syntax: `/* បង្កើត Block-level Grid */
.container {
  display: grid;
}

/* បង្កើត Inline-level Grid (កម្រប្រើជាង) */
.inline-container {
  display: inline-grid;
}`,
    htmlExample: `<!-- ការប្រៀបធៀប៖ មុន និងក្រោយពេលប្រើ display: grid ជាមួយទិន្នន័យកាតមុខវិជ្ជា -->
<div class="course-list-normal">
  <div class="course-item">HTML5 & Semantic Structure (មុខវិជ្ជាគំរូ)</div>
  <div class="course-item">CSS Box Model & Typography</div>
  <div class="course-item">Flexbox One-Dimensional Layout</div>
</div>

<div class="course-list-grid">
  <div class="course-item">HTML5 & Semantic Structure (មុខវិជ្ជាគំរូ)</div>
  <div class="course-item">CSS Box Model & Typography</div>
  <div class="course-item">Flexbox One-Dimensional Layout</div>
</div>`,
    cssExample: `/* មុន៖ ធាតុ Block ធម្មតា */
.course-list-normal {
  background-color: #fee2e2;
  padding: 16px;
  margin-bottom: 24px;
  border-radius: 8px;
}

/* ក្រោយ៖ បង្កើត Grid Formatting Context */
.course-list-grid {
  display: grid; /* បើកដំណើរការ Grid! */
  background-color: #e0e7ff;
  padding: 16px;
  border-radius: 8px;
}

.course-item {
  background-color: #ffffff;
  padding: 12px 16px;
  border: 1px solid #cbd5e1;
  margin-bottom: 8px; /* ក្នុង Block ត្រូវប្រើ margin */
  border-radius: 6px;
}`,
    codeExplanation: [
      "display: grid ប្រកាសថា .course-list-grid ជា Grid Container។",
      "ដោយសារយើងមិនទាន់បានកំណត់ grid-template-columns នោះ Grid Container នឹងបង្កើត Column តែមួយ (1 Column) ដោយស្វ័យប្រវត្តិ ហើយកូនៗនឹងក្លាយជា Grid Rows តម្រៀបពីលើចុះក្រោម។",
      "ភាពខុសគ្នាសំខាន់ពី Block Flow៖ នៅក្នុង Grid ទោះបីជា 1 Column ក៏ដោយ យើងអាចប្រើប្រាស់ Gap, Alignments (align-items, justify-items) និងសមត្ថភាពគ្រប់គ្រងទំហំ Row បានភ្លាមៗ។"
    ],
    expectedResult: {
      description: "ធាតុទាំងបីនៅតែតម្រៀបពីលើចុះក្រោម ប៉ុន្តែវាបានក្លាយជា Grid Tracks រួចជាស្រេច ហើយត្រៀមខ្លួនសម្រាប់បន្ថែម columns និង gap។",
      diagramText: `+-------------------------------------------------------------+
| Single-column Grid Track (កម្ពស់ស្មើតាម content ឬ stretch)  |
| [ Course Item 1 ]                                           |
| [ Course Item 2 ]                                           |
| [ Course Item 3 ]                                           |
+-------------------------------------------------------------+`
    },
    commonMistakes: [
      {
        mistake: "និស្សិតគិតថាដាក់តែ display: grid មួយម៉ាត់ វានឹងរៀបជា 3 Columns ដូចកាតពាណិជ្ជកម្មដោយស្វ័យប្រវត្តិ។",
        solution: "display: grid គ្រាន់តែជាការបើកទ្វារ Grid Context ប៉ុណ្ណោះ។ អ្នកត្រូវតែសរសេរ grid-template-columns បន្ថែមទៀតដើម្បីប្រាប់ Browser ថាចង់បានប៉ុន្មានជួរឈរ។"
      }
    ],
    quickChallenge: {
      question: "តើអ្វីទៅជាឥរិយាបថដើម (Default Behavior) របស់ display: grid បើគ្មាន grid-template-columns?",
      task: "សាកល្បងសរសេរ CSS សម្រាប់ .card-wrapper ឱ្យដំណើរការ Grid និងមានគម្លាតរវាងជួរ 12px។",
      hint: "display: grid; gap: 12px; (វានឹងបង្កើត 1 Column ដែលមានជួរតម្រៀបចុះក្រោមយ៉ាងស្អាត)"
    }
  },
  {
    id: "sec-12-4",
    number: "12.4",
    title: "Rows និង Columns",
    englishTitle: "Understanding Rows, Columns, Tracks, Cells, and Lines",
    definition: "ដើម្បីស្ទាត់ជំនាញ Grid យើងត្រូវយល់វាក្យសព្ទគ្រឹះចំនួន ៥៖\n1. Grid Line: បន្ទាត់បែងចែកដែលរត់ផ្តេក និងបញ្ឈរ (រាប់ចាប់ពីលេខ 1)\n2. Grid Track: ចន្លោះរវាងបន្ទាត់ពីរស្របគ្នា (គឺ Row ឬ Column)\n3. Grid Cell: ក្រឡាតែមួយតូចបំផុត (ចំនុចប្រសព្វរវាង 1 Row Track និង 1 Column Track)\n4. Grid Area: តំបន់ចតុកោណកែងដែលកើតពីក្រឡា Grid Cells មួយ ឬច្រើនបញ្ចូលគ្នា\n5. Explicit Grid vs. Implicit Grid: Explicit គឺជួរដែលយើងកំណត់ច្បាស់លាស់ក្នុង CSS ចំណែក Implicit គឺជួរដែល Browser បង្កើតបន្ថែមដោយស្វ័យប្រវត្តិនៅពេលមាន Content លើស។",
    purposeAndWhenToUse: "ស្វែងយល់ដើម្បីអាចគូរ និងស្រមៃគិតលេខ Line នៅក្នុងចិត្តបានត្រឹមត្រូវ ពីព្រោះការកំណត់ទីតាំងធាតុ (Item Placement) គឺផ្អែកទាំងស្រុងលើលេខបន្ទាត់ Line Numbers (ឧ. ចាប់ពី Line 1 ដល់ Line 3)។",
    syntax: `/* Grid ដែលមាន 3 Columns និង 2 Rows */
.grid-system {
  display: grid;
  grid-template-columns: 200px 200px 200px; /* បង្កើត 3 Columns = 4 Vertical Lines */
  grid-template-rows: 100px 100px;          /* បង្កើត 2 Rows = 3 Horizontal Lines */
}`,
    htmlExample: `<!-- ឧទាហរណ៍ Grid 3 Columns x 2 Rows ជាមួយលេខ Lines -->
<div class="campus-grid">
  <div class="grid-box">Cell (R1, C1)</div>
  <div class="grid-box">Cell (R1, C2)</div>
  <div class="grid-box">Cell (R1, C3)</div>
  <div class="grid-box">Cell (R2, C1)</div>
  <div class="grid-box">Cell (R2, C2)</div>
  <div class="grid-box">Cell (R2, C3)</div>
</div>`,
    cssExample: `.campus-grid {
  display: grid;
  /* កំណត់ Explicit Grid យ៉ាងច្បាស់៖ 3 ជួរឈរ និង 2 ជួរដេក */
  grid-template-columns: 180px 180px 180px;
  grid-template-rows: 90px 90px;
  gap: 12px;
  background-color: #f8fafc;
  padding: 16px;
  border: 2px dashed #94a3b8;
  border-radius: 8px;
}

.grid-box {
  background-color: #3b82f6;
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 500;
  border-radius: 4px;
}`,
    codeExplanation: [
      "grid-template-columns: 180px 180px 180px បង្កើត 3 Column Tracks ដែលមាន Vertical Grid Lines ចំនួន 4 (រាប់ពី Line 1, 2, 3, 4)។",
      "grid-template-rows: 90px 90px បង្កើត 2 Row Tracks ដែលមាន Horizontal Grid Lines ចំនួន 3 (រាប់ពី Line 1, 2, 3)។",
      "កូនទាំង 6 ត្រូវធ្លាក់ចូលក្នុងក្រឡា Cell នីមួយៗតាមលំដាប់លំដោយពីឆ្វេងទៅស្តាំ និងពីលើចុះក្រោម (Auto-placement algorithm)។"
    ],
    expectedResult: {
      description: "ក្រឡាចត្រង្គមាន 6 ប្រអប់ (3 ជួរឈរ x 2 ជួរដេក) ដែលមានបន្ទាត់ Line ច្បាស់លាស់។",
      diagramText: `Line 1 (Col)         Line 2               Line 3               Line 4 (Col)
  |                    |                    |                    |
--+--------------------+--------------------+--------------------+-- Line 1 (Row)
  |    Cell (R1, C1)   |    Cell (R1, C2)   |    Cell (R1, C3)   |
--+--------------------+--------------------+--------------------+-- Line 2 (Row)
  |    Cell (R2, C1)   |    Cell (R2, C2)   |    Cell (R2, C3)   |
--+--------------------+--------------------+--------------------+-- Line 3 (Row)
  |                    |                    |                    |`
    },
    commonMistakes: [
      {
        mistake: "និស្សិតច្រើនច្រឡំរវាងចំនួន Column និងចំនួន Line ដោយគិតថាមាន 3 Columns គឺមាន 3 Lines។",
        solution: "ចងចាំរូបមន្ត៖ ចំនួន Grid Lines = ចំនួន Tracks + 1 ជានិច្ច! បើមាន 3 Columns នោះគឺមាន 4 Grid Lines (បន្ទាត់ព្រំដែនសងខាង)។"
      }
    ],
    quickChallenge: {
      question: "ប្រសិនបើ Grid មួយមាន 4 Columns និង 3 Rows តើមាន Vertical Lines ប៉ុន្មាន និង Horizontal Lines ប៉ុន្មាន?",
      task: "ឆ្លើយចំនួនបន្ទាត់ និងពន្យល់ពីភាពខុសគ្នារវាង Grid Cell និង Grid Track។",
      hint: "Vertical Lines = 4 + 1 = 5; Horizontal Lines = 3 + 1 = 4។ Track គឺជួរទាំងមូល ចំណែក Cell គឺក្រឡាតែមួយ។"
    }
  },
  {
    id: "sec-12-5",
    number: "12.5",
    title: "grid-template-columns",
    englishTitle: "Defining Columns with grid-template-columns",
    definition: "grid-template-columns គឺជា Property ដ៏សំខាន់បំផុតមួយសម្រាប់កំណត់ចំនួន និងទទឹងនៃជួរឈរ (Column Tracks) នៅក្នុង Grid Container។ យើងអាចកំណត់ទំហំដោយប្រើប្រាស់រង្វាស់ជាច្រើនដូចជា px, %, em, rem និងឯកតាពិសេស fr (Fraction)។",
    purposeAndWhenToUse: "ប្រើនៅពេលអ្នកចង់បែងចែកជួរឈរនៃគេហទំព័រ ដូចជាការបង្កើត 2 Columns (Sidebar 260px និង Main Content 1fr) ឬ 3 Columns សម្រាប់បញ្ជីកាតផលិតផល/កាតនិស្សិត។ សំខាន់ត្រូវប្រយ័ត្នចំពោះការប្រើប្រាស់ Percentage (%) សរុប 100% ជាមួយ gap ព្រោះវានឹងបង្កជា Overflow ផ្តេក!",
    syntax: `/* 1 Column */
grid-template-columns: 1fr;

/* 2 Columns ទំហំស្មើគ្នា */
grid-template-columns: 1fr 1fr;

/* 2 Columns: Sidebar ថេរ និង Main បត់បែន */
grid-template-columns: 260px 1fr;

/* 3 Columns ទំហំខុសគ្នា */
grid-template-columns: 200px 1fr 300px;`,
    htmlExample: `<!-- ឧទាហរណ៍ Sidebar + Main Content Layout របស់និស្សិត -->
<div class="portal-layout">
  <aside class="sidebar-box">
    <h4>បញ្ជីមុខវិជ្ជា</h4>
    <ul>
      <li>Web Development I</li>
      <li>Database Systems</li>
      <li>Data Structures</li>
    </ul>
  </aside>

  <section class="main-content-box">
    <h3>កាលវិភាគសិក្សាប្រចាំសប្តាហ៍ (ទិន្នន័យគំរូ)</h3>
    <p>សូមស្វាគមន៍មកកាន់ឆមាសថ្មី! ថ្នាក់រៀនចាប់ផ្តើមពីម៉ោង ៨:០០ ព្រឹក។</p>
  </section>
</div>`,
    cssExample: `/* ឧទាហរណ៍ដ៏មានប្រយោជន៍បំផុត៖ Sidebar ថេរ 240px + Main Content បត់បែន 1fr */
.portal-layout {
  display: grid;
  grid-template-columns: 240px 1fr; /* 240px ថេរ និង 1fr បត់បែនតាមអេក្រង់ */
  gap: 20px;
  background-color: #f8fafc;
  padding: 20px;
  border-radius: 8px;
}

.sidebar-box {
  background-color: #ffffff;
  padding: 16px;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
}

.main-content-box {
  background-color: #ffffff;
  padding: 20px;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
}`,
    codeExplanation: [
      "grid-template-columns: 240px 1fr កំណត់ 2 ជួរឈរ។",
      "តម្លៃទី១ (240px): Sidebar នឹងរក្សាទទឹងរឹងមាំ 240px ជានិច្ច មិនថាក្នុងអេក្រង់កម្រិតណាក៏ដោយ។",
      "តម្លៃទី២ (1fr): Main Content នឹងទាញយកទំហំទំនេរដែលនៅសេសសល់ទាំងអស់ ធ្វើឱ្យ Layout រីកស្វ័យប្រវត្តិតាមទទឹង Browser។",
      "gap: 20px បង្កើតគម្លាតចន្លោះ Sidebar និង Content ដោយមិនធ្វើឱ្យធ្លាយ Overflow ឡើយ។"
    ],
    expectedResult: {
      description: "Sidebar នៅខាងឆ្វេងទទឹង 240px ថេរ ហើយ Main Content នៅខាងស្តាំពង្រីកពេញផ្ទៃអេក្រង់ដែលនៅសល់។",
      diagramText: `+--------------------+--------------------------------------------------+
| Sidebar (240px)    |               Main Content (1fr)                 |
| - Web Dev I        | កាលវិភាគសិក្សាប្រចាំសប្តាហ៍ (ទិន្នន័យគំរូ)...            |
| - Database         |                                                  |
+--------------------+--------------------------------------------------+`
    },
    commonMistakes: [
      {
        mistake: "ប្រើ grid-template-columns: 30% 70% ហើយបន្ថែម gap: 20px បណ្តាលឱ្យកើតមាន Horizontal Scrollbar (Overflow) ព្រោះ 30% + 70% = 100% បូកជាមួយ 20px ទៀតគឺលើសពី 100% នៃទទឹង!",
        solution: "ឈប់ប្រើ Percentage ក្នុង Grid! ត្រូវប្រើប្រាស់ fr (Fractional Unit) ជំនួសវិញ ដូចជា grid-template-columns: 1fr 2fr ឬ 250px 1fr ព្រោះ fr នឹងដក gap ចេញរួចរាល់ទើបយកទំហំដែលនៅសល់មកបែងចែក ធានាមិន Overflow 100%។"
      }
    ],
    quickChallenge: {
      question: "ហេតុអ្វីបានជា grid-template-columns: 50% 50% ជាមួយ gap: 20px បង្កជាបញ្ហា Overflow?",
      task: "កែប្រែបន្ទាត់កូដនោះឱ្យទៅជាកូដត្រឹមត្រូវដោយប្រើ fr។",
      hint: "កែជា៖ grid-template-columns: 1fr 1fr; gap: 20px; — fr នឹងគណនាដក 20px មុនចែកពាក់កណ្តាល 0% Overflow!"
    }
  }
];
