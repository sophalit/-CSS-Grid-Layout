import { LessonSection } from '../types';

export const SECTIONS_6_TO_10: LessonSection[] = [
  {
    id: "sec-12-6",
    number: "12.6",
    title: "grid-template-rows",
    englishTitle: "Defining Rows with grid-template-rows",
    definition: "grid-template-rows គឺជា Property សម្រាប់កំណត់ចំនួន និងកម្ពស់នៃជួរដេក (Row Tracks) ជាក់លាក់នៅក្នុង Explicit Grid។ យើងអាចកំណត់ជាកម្ពស់រឹង (Fixed Height ដូចជា 100px) ឬកំណត់តាមទំហំអត្ថបទជាក់ស្តែងដោយប្រើ auto។",
    purposeAndWhenToUse: "ប្រើនៅពេលយើងចង់ឱ្យ Header មានកម្ពស់ជាក់លាក់ (ឧ. 80px) ហើយ Footer មានកម្ពស់ថេរ (ឧ. 60px) ឬពេលចង់ឱ្យកម្ពស់រីកតាមទំហំ Content (auto)។ សំខាន់ត្រូវយល់ថា៖ ប្រសិនបើចំនួន Items មានលើសពីចំនួន Rows ដែលបានកំណត់ក្នុង grid-template-rows នោះ Rows ដែលបង្កើតបន្ថែមហៅថា Implicit Rows ហើយពួកវាមិនទទួលទំហំដែលយើងកំណត់ក្នុង grid-template-rows ដោយស្វ័យប្រវត្តិទេ (ពួកវានឹងយកទំហំ auto តាមលំនាំដើម លុះត្រាតែយើងកំណត់ grid-auto-rows)។",
    syntax: `/* កំណត់ទំហំជាក់លាក់ 2 ជួរដេក */
grid-template-rows: 100px 200px;

/* កំណត់តាមទំហំ Content ជាក់ស្តែង */
grid-template-rows: auto auto;

/* Header ថេរ, Content បត់បែន, Footer តាម content */
grid-template-rows: 80px 1fr auto;

/* ចំណេះដឹងបន្ថែម៖ កំណត់កម្ពស់ស្វ័យប្រវត្តិសម្រាប់ Implicit Rows ដែលលើស */
grid-auto-rows: 140px;`,
    htmlExample: `<!-- ឧទាហរណ៍ការកំណត់ Rows ជាក់លាក់ធៀបនឹងទំហំ auto -->
<div class="schedule-grid">
  <div class="row-header">កាលវិភាគសិក្សា (Header: 60px ថេរ)</div>
  <div class="row-main">
    <h4>មុខវិជ្ជា Web Development II</h4>
    <p>ម៉ោង ០៨:០០ - ១១:០០ ព្រឹក | បន្ទប់ Lab 304 (ទិន្នន័យគំរូ)</p>
    <p>មេរៀនថ្ងៃនេះ៖ CSS Grid Layout និង Responsive Dashboard Architecture។</p>
  </div>
  <div class="row-footer">សាកលវិទ្យាល័យភូមិន្ទភ្នំពេញ (Footer: 50px ថេរ)</div>
</div>`,
    cssExample: `.schedule-grid {
  display: grid;
  grid-template-columns: 1fr;
  /* Row 1 = 60px (Header), Row 2 = auto (រីកតាមទំហំអត្ថបទខ្មែរ), Row 3 = 50px (Footer) */
  grid-template-rows: 60px auto 50px;
  gap: 12px;
  background-color: #f8fafc;
  padding: 16px;
  border-radius: 8px;
}

.row-header {
  background-color: #0284c7;
  color: #ffffff;
  display: flex;
  align-items: center;
  padding: 0 16px;
  border-radius: 6px;
  font-weight: 600;
}

.row-main {
  background-color: #ffffff;
  border: 1px solid #e2e8f0;
  padding: 20px;
  border-radius: 6px;
  line-height: 1.6; /* ផ្តល់គម្លាតអត្ថបទខ្មែរងាយស្រួលអាន */
}

.row-footer {
  background-color: #e2e8f0;
  color: #475569;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  font-size: 14px;
}`,
    codeExplanation: [
      "grid-template-rows: 60px auto 50px កំណត់ Row ចំនួន ៣។",
      "ជួរទី១ (60px): Header មានកម្ពស់ជាក់លាក់ត្រឹមត្រូវ។",
      "ជួរទី២ (auto): ផ្នែក Main Content នឹងរីកកម្ពស់ទៅតាមបរិមាណអត្ថបទជាក់ស្តែង ជៀសវាងការដាច់ពាក្យ ឬ overflow អក្សរខ្មែរ។",
      "ជួរទី៣ (50px): Footer ខាងក្រោមរក្សាកម្ពស់ល្មមសមរម្យ។",
      "ចំណាំ៖ បើមានធាតុទី ៤ កើតឡើង វានឹងក្លាយជា Implicit Row ដែលយើងអាចគ្រប់គ្រងកម្ពស់តាមរយៈ grid-auto-rows: 100px;។"
    ],
    expectedResult: {
      description: "កាតកាលវិភាគមាន 3 ជួរដេក — ខាងលើកម្ពស់ 60px, កណ្តាលរីកតាមអត្ថបទខ្មែរ, និងខាងក្រោមកម្ពស់ 50px ថេរ។",
      diagramText: `+-------------------------------------------------------------+
| Row 1: 60px (Header)                                        |
+-------------------------------------------------------------+
| Row 2: auto (Main Content - រីកតាមកម្ពស់អត្ថបទជាក់ស្តែង)     |
| - មុខវិជ្ជា Web Development II                               |
| - ម៉ោង ០៨:០០ - ១១:០០...                                     |
+-------------------------------------------------------------+
| Row 3: 50px (Footer)                                        |
+-------------------------------------------------------------+`
    },
    commonMistakes: [
      {
        mistake: "ដាក់ Fixed Height ដូចជា grid-template-rows: 60px 80px 50px លើផ្នែកដែលមានអក្សរវែង ធ្វើឱ្យអក្សរខ្មែរធ្លាយចេញក្រៅប្រអប់ (Text Overflow / Clipping)។",
        solution: "ចំពោះផ្នែកដែលមានអត្ថបទ ឬទិន្នន័យផ្លាស់ប្តូរ ត្រូវប្រើ auto ឬ minmax(80px, auto) ជានិច្ច ដើម្បីឱ្យជួរដេកអាចពង្រីកកម្ពស់បានតាមតម្រូវការជាក់ស្តែង។"
      }
    ],
    quickChallenge: {
      question: "តើអ្វីទៅជាភាពខុសគ្នារវាង grid-template-rows: 100px 100px និង grid-auto-rows: 100px?",
      task: "ពន្យល់ពីអត្ថប្រយោជន៍នៃ grid-auto-rows ពេលមានទិន្នន័យ Dynamic ច្រើនពី Database។",
      hint: "grid-template-rows កំណត់តែ 2 Rows ដំបូងប៉ុណ្ណោះ។ បើមក 10 Items ទៀត Rows ក្រោយៗនឹងក្លាយជា Implicit Rows ហើយ grid-auto-rows នឹងជួយឱ្យ Rows ក្រោយៗទាំងអស់មានកម្ពស់ 100px ដូចគ្នា!"
    }
  },
  {
    id: "sec-12-7",
    number: "12.7",
    title: "gap",
    englishTitle: "Controlling Spacing with gap, row-gap, and column-gap",
    definition: "gap (កាលពីមុនហៅថា grid-gap) គឺជា CSS Property សម្រាប់បង្កើតគម្លាតទទេរវាង Grid Tracks (ចន្លោះរវាងជួរដេក និងជួរឈរ) ដោយមិនប៉ះពាល់ដល់គែមខាងក្រៅរបស់ Container ឡើយ។",
    purposeAndWhenToUse: "ប្រើសម្រាប់បង្កើតចន្លោះស្អាតបាតរវាងកាតនិស្សិត ឬប្រអប់ព័ត៌មាន ដោយមិនបាច់សរសេរ margin-right ឬ margin-bottom លើ Items ហើយមិនបាច់ព្រួយបារម្ភរឿងដក margin ចេញពី item ចុងក្រោយបង្អស់ (:last-child) ឡើយ។",
    syntax: `/* គម្លាតស្មើគ្នាទាំង Row និង Column (20px) */
gap: 20px;

/* កំណត់ដាច់ដោយឡែក៖ gap: [row-gap] [column-gap] */
gap: 20px 30px; /* ជួរដេក 20px, ជួរឈរ 30px */

/* ឬសរសេរជា Properties នីមួយៗ */
row-gap: 20px;
column-gap: 30px;`,
    htmlExample: `<!-- បង្ហាញភាពខុសគ្នារវាង Gap, Padding និង Margin -->
<div class="cards-wrapper">
  <div class="mini-card">កាតទី១ (ទិន្នន័យគំរូ)</div>
  <div class="mini-card">កាតទី២</div>
  <div class="mini-card">កាតទី៣</div>
  <div class="mini-card">កាតទី៤</div>
</div>`,
    cssExample: `.cards-wrapper {
  display: grid;
  grid-template-columns: 1fr 1fr;
  /* GAP: បង្កើតចន្លោះតែរវាងកាត និងកាតប៉ុណ្ណោះ! */
  gap: 16px 24px; /* row-gap: 16px, column-gap: 24px */
  
  /* PADDING: បង្កើតចន្លោះខាងក្នុងជុំវិញគែម Container */
  padding: 20px;
  
  /* MARGIN: បង្កើតគម្លាតរុញ Container ចេញពី Element ខាងក្រៅ */
  margin: 20px auto;
  
  background-color: #f1f5f9;
  border: 2px solid #cbd5e1;
  border-radius: 8px;
}

.mini-card {
  background-color: #ffffff;
  padding: 16px;
  border: 1px solid #94a3b8;
  border-radius: 6px;
  text-align: center;
  font-weight: 500;
}`,
    codeExplanation: [
      "gap: 16px 24px កំណត់គម្លាតបញ្ឈរ (រវាងជួរដេក) 16px និងគម្លាតផ្ដេក (រវាងជួរឈរ) 24px។",
      "gap មិនបង្កើតគម្លាតនៅគែមខាងក្រៅនៃ Container ទេ (នោះជាតួនាទីរបស់ padding)។",
      "ចំណុចពិសេស៖ gap ដំណើរការទាំងស្រុងលើ Gutters ដោយមិនបាច់គណនាដកទំហំស្មុគស្មាញដូចការប្រើ margin ក្នុង float layout ឡើយ។"
    ],
    expectedResult: {
      description: "កាតទាំង ៤ តម្រៀបជា ២ ជួរឈរ និង ២ ជួរដេក។ ចន្លោះផ្ដេករវាងកាតមានទំហំ 24px ហើយចន្លោះបញ្ឈរមានទំហំ 16px ចំណែកគែមជុំវិញទាំង ៤ មាន padding 20px ស្មើគ្នា។",
      diagramText: `+==================== PADDING 20px ====================+
|  +-------------------+  <-- 24px -->  +-------------------+  |
|  |      កាតទី១       |    column-gap  |      កាតទី២       |  |
|  +-------------------+                +-------------------+  |
|          ^                                    ^              |
|          | 16px row-gap                       | 16px row-gap |
|          v                                    v              |
|  +-------------------+                +-------------------+  |
|  |      កាតទី៣       |  <-- 24px -->  |      កាតទី៤       |  |
|  +-------------------+                +-------------------+  |
+======================================================+`
    },
    commonMistakes: [
      {
        mistake: "និស្សិតគិតថា gap បង្កើតចន្លោះនៅគែមខាងក្រៅរបស់ Grid ដូច margin ដែរ។",
        solution: "gap កើតឡើងតែនៅចន្លោះ Tracks ខាងក្នុង (Gutters) ប៉ុណ្ណោះ។ បើចង់បានចន្លោះនៅគែមខាងក្រៅជុំវិញ Container ត្រូវប្រើ padding លើ Container នោះ។"
      }
    ],
    quickChallenge: {
      question: "តើកូដ gap: 15px 30px មានន័យដូចម្តេច?",
      task: "បំបែកកូដនេះទៅជា CSS Properties ពីរផ្សេងគ្នា។",
      hint: "row-gap: 15px; column-gap: 30px;"
    }
  },
  {
    id: "sec-12-8",
    number: "12.8",
    title: "grid-column",
    englishTitle: "Spanning Columns with grid-column",
    definition: "grid-column គឺជា Shorthand Property សរសេរនៅលើ Grid Item សម្រាប់កំណត់ទីតាំងចាប់ផ្តើម និងទីតាំងបញ្ចប់របស់ Item នោះកាត់តាមជួរឈរ (Columns) ដោយផ្អែកលើលេខ Grid Lines (Line-Based Placement)។",
    purposeAndWhenToUse: "ប្រើនៅពេលយើងចង់ឱ្យ Header ឬ Banner ណាមួយលាតសន្ធឹងកាត់ពេញទទឹងទំព័រ (Span across columns) ឬកាតសំខាន់មួយ (Featured Card) មានទំហំធំជាងគេទ្វេដង។",
    syntax: `/* 1. ប្រើលេខ Grid Line ចាប់ផ្តើម និងបញ្ចប់ (Line 1 ដល់ Line 3 = 2 Columns) */
grid-column: 1 / 3;

/* 2. ប្រើពាក្យគន្លឹះ span (លាតសន្ធឹង 2 Columns ចាប់ពីកន្លែងដែលវានៅ) */
grid-column: span 2;

/* 3. លាតសន្ធឹងពេញទទឹងទាំងអស់ (ពី Line 1 ដល់ Line ចុងក្រោយបង្អស់ -1) */
grid-column: 1 / -1;

/* សម្គាល់៖ grid-column គឺជា shorthand របស់ grid-column-start និង grid-column-end */
grid-column-start: 1;
grid-column-end: 3;`,
    htmlExample: `<!-- ឧទាហរណ៍ Header និងកាតនិស្សិតឆ្នើមគ្រប 2 ជួរឈរ -->
<div class="faculty-grid">
  <div class="grid-header">មហាវិទ្យាល័យវិទ្យាសាស្ត្រ (Header: span 3)</div>
  <div class="featured-card">និស្សិតឆ្នើមប្រចាំឆ្នាំ (Featured: span 2)</div>
  <div class="normal-card">និស្សិត A (ទិន្នន័យគំរូ)</div>
  <div class="normal-card">និស្សិត B</div>
  <div class="normal-card">និស្សិត C</div>
  <div class="normal-card">និស្សិត D</div>
</div>`,
    cssExample: `.faculty-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr); /* 3 ជួរឈរ = 4 Lines */
  gap: 16px;
  background-color: #f8fafc;
  padding: 16px;
  border-radius: 8px;
}

/* Header លាតសន្ធឹងចាប់ពី Line 1 រហូតដល់ Line ចុងក្រោយ (-1) */
.grid-header {
  grid-column: 1 / -1; /* គ្របទាំង 3 ជួរឈរពេញលេញ */
  background-color: #1e3a8a;
  color: #ffffff;
  padding: 16px;
  border-radius: 6px;
  font-size: 18px;
  font-weight: 600;
}

/* កាតពិសេសលាតសន្ធឹង 2 ជួរឈរ */
.featured-card {
  grid-column: span 2; /* យក 2 Columns */
  background-color: #fef08a;
  color: #854d0e;
  padding: 16px;
  border: 2px solid #eab308;
  border-radius: 6px;
  font-weight: 600;
}

.normal-card {
  background-color: #ffffff;
  border: 1px solid #e2e8f0;
  padding: 16px;
  border-radius: 6px;
}`,
    codeExplanation: [
      "Container មាន 3 Columns ដូច្នេះវាមាន Grid Lines ចំនួន 4 (Line 1, Line 2, Line 3, Line 4)។",
      "grid-column: 1 / -1 បញ្ជាឱ្យ .grid-header ចាប់ផ្តើមពី Line 1 រហូតដល់ Line 4 (បន្ទាត់ -1 សំដៅលើបន្ទាត់ចុងក្រោយបំផុតនៃ Explicit Grid)។ ដូច្នេះវាគ្របដណ្តប់ពេញទទឹង 100%។",
      "grid-column: span 2 បញ្ជាឱ្យ .featured-card ពង្រីកខ្លួនយក 2 ជួរឈរ ធ្វើឱ្យវាក្លាយជា Featured Item ធំជាងគេ។",
      ".normal-card បន្តធ្លាក់ចូលក្នុងក្រឡាដែលនៅសល់ដោយស្វ័យប្រវត្តិ។"
    ],
    expectedResult: {
      description: "Header គ្របលើ 3 ជួរឈរពេញទទឹង។ ជួរទីពីរមាន Featured Card គ្រប 2 ជួរឈរ និង Normal Card 1 ជួរឈរ។ ជួរទីបីមាន Normal Cards ចំនួន 3។",
      diagramText: `Line 1 (Col)         Line 2 (Col)         Line 3 (Col)         Line 4 (-1)
  |                    |                    |                    |
--+--------------------+--------------------+--------------------+--
  | [======= .grid-header: grid-column: 1 / -1 (ពេញ 3 Columns) =======] |
--+--------------------+--------------------+--------------------+--
  | [=== .featured-card: span 2 ===]        | [ Normal Card A ]  |
--+--------------------+--------------------+--------------------+--
  | [ Normal Card B ]  | [ Normal Card C ]  | [ Normal Card D ]  |
--+--------------------+--------------------+--------------------+--`
    },
    commonMistakes: [
      {
        mistake: "និស្សិតសរសេរ grid-column: 1 / 2 ដោយសង្ឃឹមថាវាគ្រប 2 Columns។",
        solution: "កំហុស Line Number! Line 1 ទៅ Line 2 គឺទើបតែបាន 1 Column ប៉ុណ្ណោះ។ ដើម្បីបាន 2 Columns ត្រូវសរសេរ grid-column: 1 / 3 ឬសរសេរឱ្យស្រួលចាំគឺ grid-column: span 2។"
      },
      {
        mistake: "ប្រើ grid-column: 1 / -1 នៅក្នុង Implicit Grid (Grid ដែលបង្កើតជួរស្វ័យប្រវត្តដោយគ្មាន template ជាក់លាក់)។",
        solution: "-1 ដំណើរការបានតែលើ Explicit Grid ប៉ុណ្ណោះ (Grid ដែលបានប្រកាស grid-template-columns ច្បាស់លាស់)។"
      }
    ],
    quickChallenge: {
      question: "ប្រសិនបើ Grid មាន 4 ជួរឈរ តើ grid-column: 2 / 4 គ្របដណ្តប់ប៉ុន្មានជួរឈរ?",
      task: "ពន្យល់ថាតើ Item នោះចាប់ផ្តើមពី Line ណា ហើយឈប់ត្រឹម Line ណា។",
      hint: "គ្រប 2 ជួរឈរ (Column 2 និង Column 3) ចាប់ផ្តើមពី Line 2 ដល់ Line 4 (4 - 2 = 2)។"
    }
  },
  {
    id: "sec-12-9",
    number: "12.9",
    title: "grid-row",
    englishTitle: "Spanning Rows with grid-row",
    definition: "grid-row គឺជា Shorthand Property សម្រាប់កំណត់ទីតាំង និងចំនួនជួរដេក (Rows) ដែល Grid Item ត្រូវលាតសន្ធឹងឆ្លងកាត់ផ្អែកលើ Horizontal Grid Lines។",
    purposeAndWhenToUse: "ប្រើសម្រាប់បង្កើតកាតលេចធ្លោ (Featured Card / Hero Banner) ឬ Sidebar ដែលត្រូវលាតសន្ធឹងកម្ពស់កាត់ 2 ឬ 3 ជួរដេកចុះក្រោម។ លើសពីនេះ យើងអាចប្រើ grid-column និង grid-row រួមគ្នាដើម្បីបង្កើត Big Block (ឧ. 2 Columns x 2 Rows) នៅក្នុង Gallery ឬ Dashboard។",
    syntax: `/* ចាប់ផ្តើមពី Horizontal Line 1 ដល់ Line 3 (គ្រប 2 Rows) */
grid-row: 1 / 3;

/* លាតសន្ធឹង 2 Rows ចុះក្រោម */
grid-row: span 2;

/* ប្រើ Column Span និង Row Span រួមគ្នាបង្កើត Big Card */
.big-featured-box {
  grid-column: span 2;
  grid-row: span 2;
}`,
    htmlExample: `<!-- ឧទាហរណ៍ Featured News គ្រប 2 Rows និង 2 Columns ក្នុង Campus Portal -->
<div class="news-grid">
  <article class="featured-news">
    <span class="tag">ព័ត៌មានសំខាន់</span>
    <h4>ពិធីសម្ពោធមន្ទីរពិសោធន៍ AI និងបច្ចេកវិទ្យាថ្មី (គ្រប 2 Rows x 2 Cols)</h4>
    <p>សាកលវិទ្យាល័យបានដាក់ឱ្យដំណើរការមន្ទីរពិសោធន៍កុំព្យូទ័រទំនើបសម្រាប់និស្សិតឆ្នាំទី២ (ទិន្នន័យគំរូ)។</p>
  </article>

  <article class="news-item">ព័ត៌មានទី១៖ សិក្ខាសាលា Web Security</article>
  <article class="news-item">ព័ត៌មានទី២៖ ការប្រកួត Hackathon ថ្នាក់ជាតិ</article>
  <article class="news-item">ព័ត៌មានទី៣៖ កាលវិភាគប្រឡងឆមាសទី១</article>
  <article class="news-item">ព័ត៌មានទី៤៖ អាហារូបករណ៍ផ្លាស់ប្តូរការសិក្សា</article>
</div>`,
    cssExample: `.news-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: auto auto;
  gap: 16px;
  background-color: #f8fafc;
  padding: 16px;
  border-radius: 8px;
}

/* កាតពិសេស៖ គ្រប 2 ជួរឈរ និង 2 ជួរដេក */
.featured-news {
  grid-column: span 2;
  grid-row: span 2;
  background-color: #0f172a;
  color: #ffffff;
  padding: 24px;
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.tag {
  background-color: #ef4444;
  color: #ffffff;
  padding: 4px 10px;
  border-radius: 4px;
  font-size: 12px;
  width: fit-content;
}

.news-item {
  background-color: #ffffff;
  border: 1px solid #e2e8f0;
  padding: 16px;
  border-radius: 6px;
  font-weight: 500;
}`,
    codeExplanation: [
      ".featured-news ប្រើ grid-column: span 2 ដើម្បីយក 2 ជួរឈរ។",
      "ទន្ទឹមនឹងនោះ វាប្រើ grid-row: span 2 ដើម្បីយក 2 ជួរដេកចុះក្រោម។",
      "លទ្ធផលបង្កើតបានជាប្រអប់ចតុកោណកែងធំ (Big Hero Card) ដែលទាក់ទាញភ្នែកខ្លាំង។",
      "កាតព័ត៌មានតូចៗ (news-item) នឹងតម្រៀបបំពេញចន្លោះនៅ Column ទី ៣ ខាងស្តាំ (Row 1 និង Row 2) និងជួរខាងក្រោមដោយស្វ័យប្រវត្តិ។"
    ],
    expectedResult: {
      description: "កាតធំ .featured-news ស្ថិតនៅខាងឆ្វេងគ្របដណ្តប់ 2 Columns x 2 Rows ហើយកាតតូចៗចំនួន ២ តម្រៀបបញ្ឈរនៅខាងស្តាំ ក្នុង Column ទី ៣។",
      diagramText: `+-------------------------------------+--------------------+
|                                     | News Item 1 (Row 1)|
| FEATURED NEWS                       +--------------------+
| (grid-column: span 2)                | News Item 2 (Row 2)|
| (grid-row: span 2)                   +--------------------+
|                                     | News Item 3 (Row 3)|
+-------------------------------------+--------------------+
| News Item 4                         |                    |
+-------------------------------------+--------------------+`
    },
    commonMistakes: [
      {
        mistake: "ដាក់ grid-row: span 2 នៅលើ Mobile Screen ដែលមានតែ 1 Column ធ្វើឱ្យប្លង់កាតវែងអន្លាយខុសប្រក្រតី ឬបង្កចន្លោះទទេ (Gaps) មិនស្អាត។",
        solution: "នៅពេលសរសេរ Media Query សម្រាប់ Mobile (max-width: 768px) ត្រូវ Reset វាឡើងវិញដោយកំណត់ grid-column: auto; grid-row: auto; ជានិច្ច!"
      }
    ],
    quickChallenge: {
      question: "តើអ្វីកើតឡើងប្រសិនបើអ្នកដាក់ grid-column: 1 / 3 និង grid-row: 1 / 3 លើ Item មួយ?",
      task: "គូររូប Layout សង្ខេបនៅក្នុងចិត្ត ហើយពន្យល់ថាតើវាគ្របដណ្តប់ប៉ុន្មាន Cells។",
      hint: "វាគ្របដណ្តប់ 4 Cells (2 Columns គុណនឹង 2 Rows) ដូចប្រអប់ការ៉េធំមួយ!"
    }
  },
  {
    id: "sec-12-10",
    number: "12.10",
    title: "repeat()",
    englishTitle: "Simplifying Tracks with repeat()",
    definition: "repeat() គឺជា CSS Function សម្រាប់កាត់បន្ថយការសរសេរកូដស្ទួន នៅពេលយើងចង់បង្កើត Columns ឬ Rows ជាច្រើនដែលមានទំហំដូចគ្នា ឬមានលំនាំដដែលៗ (Pattern)។",
    purposeAndWhenToUse: "ជំនួសឱ្យការសរសេរ 1fr 1fr 1fr 1fr 1fr 1fr (៦ ដង) យើងគ្រាន់តែសរសេរ repeat(6, 1fr) គឺខ្លី ស្អាត និងងាយស្រួលកែសម្រួល។ លើសពីនេះ repeat() អាចប្រើជាមួយលំនាំឆ្លាស់គ្នា (Track Pattern) និងមុខងារ Auto Repeat (auto-fit, auto-fill) សម្រាប់ធ្វើ Responsive Layout ទៀតផង។",
    syntax: `/* បម្លែង 1fr 1fr 1fr ទៅជា repeat() */
grid-template-columns: repeat(3, 1fr);

/* បង្កើត 12-Column Grid System ដូច Bootstrap/Tailwind */
grid-template-columns: repeat(12, 1fr);

/* លំនាំឆ្លាស់គ្នា (Track Pattern): បង្កើត 200px 1fr 200px 1fr */
grid-template-columns: repeat(2, 200px 1fr);`,
    htmlExample: `<!-- បង្ហាញការប្រើ repeat(4, 1fr) ជាមួយកាតពិន្ទុនិស្សិត ៤ មុខវិជ្ជា -->
<div class="grades-grid">
  <div class="grade-card">
    <h5>Web Programming</h5>
    <p class="score">ពិន្ទុ៖ 95 (A)</p>
  </div>
  <div class="grade-card">
    <h5>Database Systems</h5>
    <p class="score">ពិន្ទុ៖ 88 (B+)</p>
  </div>
  <div class="grade-card">
    <h5>Data Structures</h5>
    <p class="score">ពិន្ទុ៖ 92 (A)</p>
  </div>
  <div class="grade-card">
    <h5>Computer Networks</h5>
    <p class="score">ពិន្ទុ៖ 85 (B)</p>
  </div>
</div>`,
    cssExample: `.grades-grid {
  display: grid;
  /* ជំនួសឱ្យការសរសេរ 1fr 1fr 1fr 1fr យើងប្រើ repeat() */
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  background-color: #f8fafc;
  padding: 16px;
  border-radius: 8px;
}

.grade-card {
  background-color: #ffffff;
  padding: 16px;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  text-align: center;
  box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.grade-card h5 {
  font-size: 15px;
  color: #1e293b;
  margin-bottom: 8px;
}

.score {
  color: #059669;
  font-weight: 600;
  font-size: 14px;
}`,
    codeExplanation: [
      "repeat(4, 1fr) ទទួល Argument ចំនួន ២៖ Argument ទី១ (4) គឺចំនួនដងដែលត្រូវបង្កើត, និង Argument ទី២ (1fr) គឺទំហំនៃ Track នីមួយៗ។",
      "វាស្មើនឹងការសរសេរ grid-template-columns: 1fr 1fr 1fr 1fr; ទាំងស្រុង ប៉ុន្តែកូដខ្លី និងងាយថែទាំជាង។",
      "បើចង់ប្តូរពី 4 Columns ទៅ 5 Columns គ្រាន់តែប្តូរលេខ 4 ទៅ 5 ជាការស្រេច។"
    ],
    expectedResult: {
      description: "កាតពិន្ទុទាំង ៤ ត្រូវបែងចែកជា ៤ ជួរឈរទំហំស្មើគ្នាបេះបិទ ក្នុងទទឹងមួយជួរ 1fr និងមានគម្លាត 16px រវាងគ្នា។",
      diagramText: `+---------------+---------------+---------------+---------------+
| Grade Card 1  | Grade Card 2  | Grade Card 3  | Grade Card 4  |
| Web (95)      | DB (88)       | DSA (92)      | Network (85)  |
| (1fr)         | (1fr)         | (1fr)         | (1fr)         |
+---------------+---------------+---------------+---------------+`
    },
    commonMistakes: [
      {
        mistake: "សរសេរ repeat(1fr, 3) ដោយដាក់តម្លៃច្រាសគ្នា។",
        solution: "ចាំ Syntax ឱ្យច្បាស់៖ repeat(ចំនួនដង, ទំហំ) — លេខរាប់ត្រូវនៅមុខជានិច្ច!"
      }
    ],
    quickChallenge: {
      question: "តើ grid-template-columns: repeat(3, 100px 1fr) នឹងបង្កើតជួរឈរសរុបប៉ុន្មាន? ហើយមានលំនាំយ៉ាងដូចម្តេច?",
      task: "គណនាចំនួន Columns សរុប និងរៀបរាប់លំដាប់លំដោយទំហំរបស់វា។",
      hint: "បង្កើតបាន 6 Columns សរុប! (100px 1fr 100px 1fr 100px 1fr) ព្រោះវា Repeat លំនាំ (100px 1fr) ចំនួន 3 ដង។"
    }
  }
];
