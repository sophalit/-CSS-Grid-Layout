import React, { useState } from 'react';
import { Navbar, TabType } from './components/Navbar';
import { CurriculumView } from './components/CurriculumView';
import { PlaygroundView } from './components/PlaygroundView';
import { ProjectsView } from './components/ProjectsView';
import { QuizView } from './components/QuizView';
import { AssignmentsView } from './components/AssignmentsView';
import { BookOpen, CheckCircle, Code, ShieldCheck } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('curriculum');

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-sky-500 selection:text-white">
      {/* Top Main Navigation */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Tab View */}
      <main className="flex-1 pb-16">
        {activeTab === 'curriculum' && <CurriculumView />}
        {activeTab === 'playground' && <PlaygroundView />}
        {activeTab === 'projects' && <ProjectsView />}
        {activeTab === 'quiz' && <QuizView />}
        {activeTab === 'assignments' && <AssignmentsView />}
      </main>

      {/* Course Architecture & Review Footer (R in CLEAR) */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 text-xs py-10 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Column 1: Pedagogical Model */}
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <BookOpen className="w-4 h-4 text-sky-400" />
                <span>CLEAR Framework Integration</span>
              </div>
              <p className="text-slate-400 leading-relaxed text-xs">
                រៀបចំឡើងតាមគំរូគរុកោសល្យ CLEAR (Context, Learning Outcomes, Execution, Assessment, Review) សម្រាប់ជំនួយការបង្រៀន និងស្វ័យសិក្សាផ្នែក Front-End Web Development។
              </p>
            </div>

            {/* Column 2: Code Standard */}
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Code className="w-4 h-4 text-emerald-400" />
                <span>ស្តង់ដារកូដកម្រិតវិជ្ជាជីវៈ (Code Quality)</span>
              </div>
              <p className="text-slate-400 leading-relaxed text-xs">
                កូដគំរូទាំងអស់ប្រើ HTML5 Semantic និង Pure CSS សុទ្ធសាធ (គ្មាន Framework ក្រៅ) ដោយប្រើ box-sizing, viewport meta, font-family ខ្មែរ Kantumruy Pro និង minmax(0, 1fr) ការពារ Overflow 100%។
              </p>
            </div>

            {/* Column 3: Review & Verification */}
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>ការត្រួតពិនិត្យ (R — Requirements & Review)</span>
              </div>
              <p className="text-slate-400 leading-relaxed text-xs">
                បានត្រួតពិនិត្យភាពត្រឹមត្រូវនៃ Grid Layout លើអេក្រង់ 360px (Mobile), 768px (Tablet), និង 1280px (Desktop)។ គ្រប់ទិន្នន័យត្រូវបានសម្គាល់ជាទិន្នន័យគំរូយ៉ាងច្បាស់លាស់។
              </p>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-500 text-[11px]">
            <div>
              &copy; ២០២៦ កម្មវិធីសិក្សា Front-End Development — សាស្រ្តាចារ្យ និង Senior Front-End Developer
            </div>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1 text-emerald-400">
                <CheckCircle className="w-3.5 h-3.5" /> HTML5 & W3C CSS Grid Level 2 Standard
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
