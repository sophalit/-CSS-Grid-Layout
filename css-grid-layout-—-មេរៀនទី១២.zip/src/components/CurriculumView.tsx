import React, { useState } from 'react';
import { ALL_LESSON_SECTIONS } from '../data/lessonIndex';
import { LESSON_META, LessonSection } from '../types';
import { SUMMARY_TABLE_DATA } from '../data/assessmentData';
import { 
  BookOpen, 
  CheckCircle2, 
  AlertCircle, 
  Code2, 
  HelpCircle, 
  Copy, 
  Check, 
  ChevronRight, 
  FileText,
  Table as TableIcon
} from 'lucide-react';

export const CurriculumView: React.FC = () => {
  const [selectedSectionId, setSelectedSectionId] = useState<string>(ALL_LESSON_SECTIONS[0].id);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [revealedHints, setRevealedHints] = useState<Record<string, boolean>>({});

  const handleCopy = (code: string, key: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(key);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const toggleHint = (sectionId: string) => {
    setRevealedHints(prev => ({ ...prev, [sectionId]: !prev[sectionId] }));
  };

  const currentSection = ALL_LESSON_SECTIONS.find(s => s.id === selectedSectionId) || ALL_LESSON_SECTIONS[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Course Context & CLEAR Header Banner */}
      <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 text-white shadow-xl mb-8">
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <span className="bg-sky-500/20 text-sky-300 border border-sky-500/30 px-3 py-1 rounded-full text-xs font-semibold">
            {LESSON_META.courseNumber}
          </span>
          <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-semibold">
            Front-End Web Development
          </span>
          <span className="bg-purple-500/20 text-purple-300 border border-purple-500/30 px-3 py-1 rounded-full text-xs font-semibold">
            CLEAR Framework
          </span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-bold tracking-tight text-white mb-3">
          {LESSON_META.title}
        </h1>
        <p className="text-base sm:text-lg text-slate-300 mb-6 font-light max-w-3xl">
          {LESSON_META.englishTitle} — កម្មវិធីសិក្សាលម្អិតកម្រិតឧត្តមសិក្សា សម្រាប់និស្សិតឆ្នាំទី២ ដេប៉ាតឺម៉ង់ វិទ្យាសាស្ត្រកុំព្យូទ័រ និងព័ត៌មានវិទ្យា។
        </p>

        {/* Source Note Callout */}
        <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4 mb-6 text-xs sm:text-sm text-slate-300 flex items-start gap-3">
          <FileText className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-sky-300">កំណត់សម្គាល់ឯកសារប្រភព៖</span> ឯកសារ 
            <code className="bg-slate-900 px-1.5 py-0.5 rounded text-sky-200 mx-1">«មេរៀនទី១២៖ ការប្រើប្រាស់ CSS Grid Layout.docx»</code> 
            មិនត្រូវបានភ្ជាប់មកជាមួយទេ ដូច្នេះមេរៀននេះត្រូវបានរៀបចំឡើងយ៉ាងពេញលេញផ្អែកលើវិសាលភាព និងស្តង់ដារបច្ចេកទេសដែលបានកំណត់ក្នុង CLEAR Framework ដោយរក្សាភាពត្រឹមត្រូវតាមស្ថាបត្យកម្ម W3C CSS Grid Level 2។
          </div>
        </div>

        {/* Prerequisites & Outcomes Accordion */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4">
            <h3 className="text-sm font-semibold text-sky-400 mb-2.5 flex items-center gap-2">
              <BookOpen className="w-4 h-4" /> ចំណេះដឹងដែលត្រូវមានមុន (Prerequisites)
            </h3>
            <ul className="space-y-1.5 text-xs sm:text-sm text-slate-300">
              {LESSON_META.prerequisites.map((p, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="text-sky-400 font-mono font-bold">•</span>
                  <span>{p}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4">
            <h3 className="text-sm font-semibold text-emerald-400 mb-2.5 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" /> គោលបំណងសិក្សា (16 Learning Outcomes)
            </h3>
            <div className="max-h-36 overflow-y-auto pr-2 space-y-1.5 text-xs sm:text-sm text-slate-300 scrollbar-thin">
              {LESSON_META.outcomes.map((outcome, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <span className="text-emerald-400 font-semibold shrink-0">{idx + 1}.</span>
                  <span>{outcome}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Layout: Sidebar Navigation + Chapter Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Sidebar Table of Contents */}
        <aside className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-4 shadow-sm sticky top-20">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-sky-600" />
              <span>មាតិកាមេរៀន (១៥ ប្រធានបទ)</span>
            </h2>
            <span className="text-xs bg-slate-100 text-slate-600 font-mono px-2 py-0.5 rounded">
              15 ផ្នែក
            </span>
          </div>

          <div className="space-y-1 max-h-[calc(100vh-180px)] overflow-y-auto pr-1 text-sm">
            {ALL_LESSON_SECTIONS.map((sec) => {
              const isSelected = sec.id === selectedSectionId;
              return (
                <button
                  key={sec.id}
                  onClick={() => {
                    setSelectedSectionId(sec.id);
                    window.scrollTo({ top: 400, behavior: 'smooth' });
                  }}
                  className={`w-full text-left px-3 py-2.5 rounded-lg flex items-center justify-between transition-all ${
                    isSelected
                      ? 'bg-sky-50 text-sky-900 font-semibold border-l-4 border-sky-600 shadow-xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <span className={`text-xs font-mono px-1.5 py-0.5 rounded ${
                      isSelected ? 'bg-sky-600 text-white font-bold' : 'bg-slate-100 text-slate-500'
                    }`}>
                      {sec.number}
                    </span>
                    <span className="truncate">{sec.title}</span>
                  </div>
                  <ChevronRight className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-sky-600' : 'text-slate-300'}`} />
                </button>
              );
            })}
          </div>
        </aside>

        {/* Right Section Content Detail */}
        <main className="lg:col-span-8 space-y-6">
          <SectionDetailCard
            section={currentSection}
            onCopy={handleCopy}
            copiedCode={copiedCode}
            isHintRevealed={!!revealedHints[currentSection.id]}
            onToggleHint={() => toggleHint(currentSection.id)}
          />

          {/* Quick Jump Buttons */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-200">
            {(() => {
              const currentIndex = ALL_LESSON_SECTIONS.findIndex(s => s.id === currentSection.id);
              const prevSection = ALL_LESSON_SECTIONS[currentIndex - 1];
              const nextSection = ALL_LESSON_SECTIONS[currentIndex + 1];

              return (
                <>
                  {prevSection ? (
                    <button
                      onClick={() => {
                        setSelectedSectionId(prevSection.id);
                        window.scrollTo({ top: 400, behavior: 'smooth' });
                      }}
                      className="px-4 py-2 text-xs sm:text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
                    >
                      ← {prevSection.number} {prevSection.title}
                    </button>
                  ) : <div />}

                  {nextSection ? (
                    <button
                      onClick={() => {
                        setSelectedSectionId(nextSection.id);
                        window.scrollTo({ top: 400, behavior: 'smooth' });
                      }}
                      className="px-4 py-2 text-xs sm:text-sm font-medium text-white bg-sky-600 rounded-lg hover:bg-sky-700 transition-colors"
                    >
                      {nextSection.number} {nextSection.title} →
                    </button>
                  ) : <div />}
                </>
              );
            })()}
          </div>

          {/* Summary Table Component at bottom */}
          <div className="mt-12 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
              <TableIcon className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-bold text-slate-900">
                តារាងសង្ខេប Properties & Functions នៃ CSS Grid Layout
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 border-b border-slate-200">
                    <th className="p-3 font-semibold">Property / Function</th>
                    <th className="p-3 font-semibold">ទីតាំងប្រើ</th>
                    <th className="p-3 font-semibold">តួនាទីសង្ខេបជាភាសាខ្មែរ</th>
                    <th className="p-3 font-semibold">ឧទាហរណ៍ខ្លី</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {SUMMARY_TABLE_DATA.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 transition-colors">
                      <td className="p-3 font-mono font-bold text-sky-700 whitespace-nowrap">
                        {item.property}
                      </td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                          item.appliedTo === 'Container' 
                            ? 'bg-blue-100 text-blue-800' 
                            : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          {item.appliedTo}
                        </span>
                      </td>
                      <td className="p-3 text-slate-700">{item.roleKm}</td>
                      <td className="p-3 font-mono text-slate-600 text-xs bg-slate-50 rounded">
                        {item.example}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

interface SectionDetailCardProps {
  section: LessonSection;
  onCopy: (code: string, key: string) => void;
  copiedCode: string | null;
  isHintRevealed: boolean;
  onToggleHint: () => void;
}

const SectionDetailCard: React.FC<SectionDetailCardProps> = ({
  section,
  onCopy,
  copiedCode,
  isHintRevealed,
  onToggleHint
}) => {
  return (
    <article className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm space-y-6">
      {/* Section Heading */}
      <div className="border-b border-slate-100 pb-4">
        <div className="flex items-center gap-2 mb-1">
          <span className="bg-sky-100 text-sky-800 text-xs font-mono font-bold px-2.5 py-0.5 rounded-full">
            ប្រធានបទ {section.number}
          </span>
          <span className="text-slate-400 text-xs font-medium">{section.englishTitle}</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
          {section.title}
        </h2>
      </div>

      {/* 1. និយមន័យសាមញ្ញ */}
      <div>
        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-sky-500"></span>
          ១. និយមន័យសាមញ្ញ (Simple Definition)
        </h3>
        <p className="text-slate-700 leading-relaxed text-sm sm:text-base whitespace-pre-line bg-sky-50/50 p-4 rounded-xl border border-sky-100">
          {section.definition}
        </p>
      </div>

      {/* 2. តួនាទី និងពេលគួរប្រើ */}
      <div>
        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
          ២. តួនាទី និងពេលគួរប្រើ (Purpose & When to Use)
        </h3>
        <p className="text-slate-700 leading-relaxed text-sm sm:text-base bg-slate-50 p-4 rounded-xl border border-slate-100">
          {section.purposeAndWhenToUse}
        </p>
      </div>

      {/* 3. Syntax */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-purple-500"></span>
            ៣. Syntax
          </h3>
          <button
            onClick={() => onCopy(section.syntax, `syntax-${section.id}`)}
            className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 font-mono"
          >
            {copiedCode === `syntax-${section.id}` ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-600">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>
        <pre className="bg-slate-900 text-slate-100 p-4 rounded-xl font-mono text-xs sm:text-sm overflow-x-auto leading-relaxed border border-slate-800">
          {section.syntax}
        </pre>
      </div>

      {/* 4. ឧទាហរណ៍ HTML និង CSS */}
      <div className="space-y-4">
        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-amber-500"></span>
          ៤. ឧទាហរណ៍ HTML និង CSS ជាក់ស្តែង (Practical Code)
        </h3>

        {/* HTML Block */}
        <div>
          <div className="flex items-center justify-between bg-slate-800 px-4 py-2 rounded-t-xl text-xs font-mono text-slate-300">
            <span>HTML Structure</span>
            <button
              onClick={() => onCopy(section.htmlExample, `html-${section.id}`)}
              className="text-slate-400 hover:text-white flex items-center gap-1"
            >
              {copiedCode === `html-${section.id}` ? (
                <Check className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )}
              <span>Copy HTML</span>
            </button>
          </div>
          <pre className="bg-slate-900 text-amber-200 p-4 rounded-b-xl font-mono text-xs sm:text-sm overflow-x-auto leading-relaxed border-x border-b border-slate-800">
            {section.htmlExample}
          </pre>
        </div>

        {/* CSS Block */}
        <div>
          <div className="flex items-center justify-between bg-slate-800 px-4 py-2 rounded-t-xl text-xs font-mono text-slate-300">
            <span>CSS Rules</span>
            <button
              onClick={() => onCopy(section.cssExample, `css-${section.id}`)}
              className="text-slate-400 hover:text-white flex items-center gap-1"
            >
              {copiedCode === `css-${section.id}` ? (
                <Check className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )}
              <span>Copy CSS</span>
            </button>
          </div>
          <pre className="bg-slate-900 text-sky-200 p-4 rounded-b-xl font-mono text-xs sm:text-sm overflow-x-auto leading-relaxed border-x border-b border-slate-800">
            {section.cssExample}
          </pre>
        </div>
      </div>

      {/* 5. ការពន្យល់បន្ទាត់កូដសំខាន់ៗ */}
      <div>
        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3 flex items-center gap-2">
          <Code2 className="w-4 h-4 text-sky-600" />
          ៥. ការពន្យល់បន្ទាត់កូដសំខាន់ៗ (Code Breakdown)
        </h3>
        <ul className="space-y-2 text-sm text-slate-700 bg-slate-50 p-4 rounded-xl border border-slate-200">
          {section.codeExplanation.map((exp, idx) => (
            <li key={idx} className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-sky-100 text-sky-700 text-xs flex items-center justify-center font-bold shrink-0 mt-0.5">
                {idx + 1}
              </span>
              <span className="leading-relaxed">{exp}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* 6. លទ្ធផលដែលរំពឹងទុក & ASCII Diagram */}
      <div>
        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
          ៦. លទ្ធផលដែលរំពឹងទុក (Expected Visual Output & Diagram)
        </h3>
        <p className="text-sm text-slate-700 mb-3">
          {section.expectedResult.description}
        </p>
        <div className="bg-slate-900 text-emerald-400 p-4 rounded-xl font-mono text-xs sm:text-sm overflow-x-auto leading-relaxed border border-slate-800 whitespace-pre">
          {section.expectedResult.diagramText}
        </div>
      </div>

      {/* 7. កំហុសដែលជួបញឹកញាប់ និងរបៀបកែ */}
      <div>
        <h3 className="text-sm font-bold text-rose-700 uppercase tracking-wider mb-3 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600" />
          ៧. កំហុសដែលជួបញឹកញាប់ និងរបៀបកែ (Common Pitfalls & Fixes)
        </h3>
        <div className="space-y-3">
          {section.commonMistakes.map((item, idx) => (
            <div key={idx} className="bg-rose-50 border border-rose-100 rounded-xl p-4 text-sm">
              <div className="flex items-start gap-2 mb-2 text-rose-800 font-semibold">
                <span className="text-rose-600 font-bold shrink-0">⚠️ កំហុស៖</span>
                <span>{item.mistake}</span>
              </div>
              <div className="flex items-start gap-2 text-emerald-800 font-medium pl-6 bg-emerald-50/80 p-2.5 rounded-lg border border-emerald-100">
                <span className="text-emerald-600 font-bold shrink-0">✅ ដំណោះស្រាយ៖</span>
                <span>{item.solution}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 8. លំហាត់សាកល្បងខ្លីមួយ */}
      <div className="bg-amber-50/60 border border-amber-200 rounded-xl p-5">
        <h3 className="text-sm font-bold text-amber-900 uppercase tracking-wider mb-2 flex items-center gap-2">
          <HelpCircle className="w-4 h-4 text-amber-600" />
          ៨. លំហាត់សាកល្បងខ្លីមួយ (Quick Challenge)
        </h3>
        <p className="text-sm font-semibold text-slate-800 mb-2">
          ❓ {section.quickChallenge.question}
        </p>
        <p className="text-xs sm:text-sm text-slate-600 mb-3">
          🎯 <span className="font-medium">កិច្ចការ៖</span> {section.quickChallenge.task}
        </p>
        <button
          onClick={onToggleHint}
          className="text-xs font-semibold text-amber-700 hover:text-amber-900 bg-amber-100 hover:bg-amber-200 px-3 py-1.5 rounded-md transition-colors"
        >
          {isHintRevealed ? 'លាក់ចម្លើយ / Hint' : 'បង្ហាញចម្លើយ / Hint'}
        </button>
        {isHintRevealed && (
          <div className="mt-3 p-3 bg-white border border-amber-200 rounded-lg text-xs sm:text-sm text-slate-700 font-medium animate-in fade-in duration-200">
            💡 <span className="font-bold text-amber-800">ចម្លើយណែនាំ៖</span> {section.quickChallenge.hint}
          </div>
        )}
      </div>
    </article>
  );
};
