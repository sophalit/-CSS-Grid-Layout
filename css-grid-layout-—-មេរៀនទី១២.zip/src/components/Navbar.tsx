import React from 'react';
import { BookOpen, FlaskConical, LayoutGrid, CheckSquare, Award } from 'lucide-react';

export type TabType = 'curriculum' | 'playground' | 'projects' | 'quiz' | 'assignments';

interface NavbarProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'curriculum', label: 'មេរៀនពេញលេញ (Textbook)', icon: BookOpen },
    { id: 'playground', label: 'CSS Grid Generator (cssgridgenerator.io)', icon: LayoutGrid },
    { id: 'projects', label: 'គម្រោងគំរូជាក់ស្តែង (Live Projects)', icon: FlaskConical },
    { id: 'quiz', label: 'សំណួរត្រួតពិនិត្យ (Quiz)', icon: CheckSquare },
    { id: 'assignments', label: 'កិច្ចការ & Rubric (Rubric)', icon: Award },
  ] as const;

  return (
    <header className="sticky top-0 z-50 bg-slate-900 border-b border-slate-800 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between py-3 gap-3">
          {/* Brand & Course Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center shadow-inner">
              <LayoutGrid className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-sky-500/20 text-sky-400 text-xs px-2 py-0.5 rounded font-semibold border border-sky-500/30">
                  មេរៀនទី១២
                </span>
                <span className="text-slate-400 text-xs font-mono">CLEAR Framework</span>
              </div>
              <h1 className="text-base sm:text-lg font-bold text-white tracking-tight">
                CSS Grid Layout — Modern CSS Layout
              </h1>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center overflow-x-auto pb-1 md:pb-0 gap-1.5 scrollbar-none">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium whitespace-nowrap transition-all duration-150 ${
                    isActive
                      ? 'bg-sky-600 text-white shadow-sm font-semibold'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </header>
  );
};
