import React, { useState, useRef, useCallback, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Copy, 
  Check, 
  Code, 
  Sliders, 
  RotateCcw, 
  Sparkles, 
  Maximize2, 
  Move, 
  Layout, 
  HelpCircle,
  Eye,
  Settings2,
  ChevronRight,
  ExternalLink,
  Layers,
  ArrowRight,
  Palette,
  X
} from 'lucide-react';
import { GridDivItem } from '../types';
import { VisualPresetGallery } from './VisualPresetGallery';
import { LAYOUT_PRESETS, LayoutPreset } from '../data/gridPresets';

const PALETTE = [
  { bg: 'bg-emerald-500/15', border: 'border-emerald-500', solidBg: '#10b981', text: 'text-emerald-800', badge: 'bg-emerald-600' },
  { bg: 'bg-sky-500/15', border: 'border-sky-500', solidBg: '#0ea5e9', text: 'text-sky-800', badge: 'bg-sky-600' },
  { bg: 'bg-violet-500/15', border: 'border-violet-500', solidBg: '#8b5cf6', text: 'text-violet-800', badge: 'bg-violet-600' },
  { bg: 'bg-amber-500/15', border: 'border-amber-500', solidBg: '#f59e0b', text: 'text-amber-800', badge: 'bg-amber-600' },
  { bg: 'bg-rose-500/15', border: 'border-rose-500', solidBg: '#f43f5e', text: 'text-rose-800', badge: 'bg-rose-600' },
  { bg: 'bg-teal-500/15', border: 'border-teal-500', solidBg: '#14b8a6', text: 'text-teal-800', badge: 'bg-teal-600' },
  { bg: 'bg-indigo-500/15', border: 'border-indigo-500', solidBg: '#6366f1', text: 'text-indigo-800', badge: 'bg-indigo-600' },
  { bg: 'bg-orange-500/15', border: 'border-orange-500', solidBg: '#f97316', text: 'text-orange-800', badge: 'bg-orange-600' },
  { bg: 'bg-cyan-500/15', border: 'border-cyan-500', solidBg: '#06b6d4', text: 'text-cyan-800', badge: 'bg-cyan-600' },
  { bg: 'bg-fuchsia-500/15', border: 'border-fuchsia-500', solidBg: '#d946ef', text: 'text-fuchsia-800', badge: 'bg-fuchsia-600' },
];

const INITIAL_ITEMS: GridDivItem[] = [
  { id: '1', name: 'div1', colStart: 1, colSpan: 5, rowStart: 1, rowSpan: 1, color: PALETTE[0].badge },
  { id: '2', name: 'div2', colStart: 1, colSpan: 2, rowStart: 2, rowSpan: 3, color: PALETTE[1].badge },
  { id: '3', name: 'div3', colStart: 3, colSpan: 3, rowStart: 2, rowSpan: 2, color: PALETTE[2].badge },
  { id: '4', name: 'div4', colStart: 3, colSpan: 3, rowStart: 4, rowSpan: 1, color: PALETTE[3].badge },
  { id: '5', name: 'div5', colStart: 1, colSpan: 5, rowStart: 5, rowSpan: 1, color: PALETTE[4].badge },
];

export const CssGridGenerator: React.FC = () => {
  // Grid Dimensions & Gaps
  const [columns, setColumns] = useState<number>(5);
  const [rows, setRows] = useState<number>(5);
  const [colGap, setColGap] = useState<number>(12);
  const [rowGap, setRowGap] = useState<number>(12);
  const [linkGaps, setLinkGaps] = useState<boolean>(true);

  // Track unit lists (default '1fr' for each)
  const [colUnits, setColUnits] = useState<string[]>(['1fr', '1fr', '1fr', '1fr', '1fr']);
  const [rowUnits, setRowUnits] = useState<string[]>(['1fr', '1fr', '1fr', '1fr', '1fr']);

  // Placed DIV elements
  const [items, setItems] = useState<GridDivItem[]>(INITIAL_ITEMS);
  const [selectedItemId, setSelectedItemId] = useState<string | null>('1');

  // Syntax style: 'grid-area' or 'grid-column-row'
  const [syntaxStyle, setSyntaxStyle] = useState<'grid-area' | 'grid-column-row'>('grid-area');

  // Active Code Tab for Live Panel: 'css' | 'html' | 'preview'
  const [activeCodeTab, setActiveCodeTab] = useState<'css' | 'html' | 'preview'>('css');

  // Modal / Drawer state
  const [showCodeModal, setShowCodeModal] = useState<boolean>(false);
  const [showPresetModal, setShowPresetModal] = useState<boolean>(false);
  const [activePresetId, setActivePresetId] = useState<string>('holy-grail');
  const [topBannerCategory, setTopBannerCategory] = useState<string>('all');
  const [presetToast, setPresetToast] = useState<string | null>(null);
  const [copyStatus, setCopyStatus] = useState<'idle' | 'html' | 'css' | 'all'>('idle');
  const [showGuide, setShowGuide] = useState<boolean>(true);

  // Dragging & Resizing Refs
  const gridContainerRef = useRef<HTMLDivElement | null>(null);
  const [activeDrag, setActiveDrag] = useState<{
    type: 'move' | 'resize';
    itemId: string;
    startCol: number;
    startRow: number;
    initialColSpan: number;
    initialRowSpan: number;
    startX: number;
    startY: number;
    offsetCol?: number;
    offsetRow?: number;
  } | null>(null);

  // Sync track units with columns and rows count
  useEffect(() => {
    setColUnits(prev => {
      const next = [...prev];
      while (next.length < columns) next.push('1fr');
      return next.slice(0, columns);
    });
  }, [columns]);

  useEffect(() => {
    setRowUnits(prev => {
      const next = [...prev];
      while (next.length < rows) next.push('1fr');
      return next.slice(0, rows);
    });
  }, [rows]);

  // Handle Gap Linkage
  const handleColGapChange = (val: number) => {
    setColGap(val);
    if (linkGaps) setRowGap(val);
  };

  const handleRowGapChange = (val: number) => {
    setRowGap(val);
    if (linkGaps) setColGap(val);
  };

  // Add element to cell
  const handleAddElement = (row: number, col: number) => {
    const nextIndex = items.length + 1;
    const paletteColor = PALETTE[(nextIndex - 1) % PALETTE.length].badge;
    const newItem: GridDivItem = {
      id: Date.now().toString(),
      name: `div${nextIndex}`,
      colStart: col,
      colSpan: 1,
      rowStart: row,
      rowSpan: 1,
      color: paletteColor,
    };
    setItems(prev => [...prev, newItem]);
    setSelectedItemId(newItem.id);
  };

  // Delete element
  const handleDeleteElement = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setItems(prev => prev.filter(item => item.id !== id));
    if (selectedItemId === id) setSelectedItemId(null);
  };

  // Clear all elements
  const handleClearAll = () => {
    setItems([]);
    setSelectedItemId(null);
  };

  // Apply a rich Layout Preset directly
  const applyLayoutPreset = (preset: LayoutPreset) => {
    setColumns(preset.columns);
    setRows(preset.rows);
    setColGap(preset.colGap);
    setRowGap(preset.rowGap);
    setColUnits([...preset.colUnits]);
    setRowUnits([...preset.rowUnits]);
    setItems(preset.items.map(item => ({ ...item })));
    setActivePresetId(preset.id);
    setSelectedItemId(preset.items[0]?.id || null);
    setPresetToast(`បានអនុវត្តគំរូ "${preset.name}" (${preset.columns}×${preset.rows}) ជោគជ័យ!`);
    setTimeout(() => setPresetToast(null), 3500);
  };

  // Quick preset loader helper
  const loadPreset = (type: 'default' | 'holyGrail' | 'dashboard' | 'mosaic' | 'clear') => {
    if (type === 'clear') {
      setItems([]);
      setSelectedItemId(null);
      return;
    }

    const presetMap: Record<string, string> = {
      holyGrail: 'holy-grail',
      dashboard: 'dashboard-admin',
      mosaic: 'photo-mosaic',
    };

    const targetId = presetMap[type];
    const found = LAYOUT_PRESETS.find(p => p.id === targetId);
    if (found) {
      applyLayoutPreset(found);
      return;
    }

    if (type === 'default') {
      setColumns(5);
      setRows(5);
      setColGap(12);
      setRowGap(12);
      setColUnits(['1fr', '1fr', '1fr', '1fr', '1fr']);
      setRowUnits(['1fr', '1fr', '1fr', '1fr', '1fr']);
      setItems(INITIAL_ITEMS);
      setSelectedItemId('1');
      setActivePresetId('default');
      setPresetToast('បានកំណត់ឡើងវិញនូវគំរូដើម 5×5!');
      setTimeout(() => setPresetToast(null), 3000);
    }
  };

  // Cycle unit for a column or row track
  const cycleUnit = (type: 'col' | 'row', index: number) => {
    const units = ['1fr', '2fr', '150px', 'auto'];
    if (type === 'col') {
      setColUnits(prev => {
        const next = [...prev];
        const current = next[index] || '1fr';
        const currentIndex = units.indexOf(current);
        next[index] = units[(currentIndex + 1) % units.length];
        return next;
      });
    } else {
      setRowUnits(prev => {
        const next = [...prev];
        const current = next[index] || '1fr';
        const currentIndex = units.indexOf(current);
        next[index] = units[(currentIndex + 1) % units.length];
        return next;
      });
    }
  };

  // Convert mouse event position into (col, row) relative to grid container
  const getCellCoordinates = useCallback((clientX: number, clientY: number) => {
    if (!gridContainerRef.current) return null;
    const rect = gridContainerRef.current.getBoundingClientRect();
    const relativeX = clientX - rect.left;
    const relativeY = clientY - rect.top;

    const cellWidth = rect.width / columns;
    const cellHeight = rect.height / rows;

    const col = Math.max(1, Math.min(columns, Math.floor(relativeX / cellWidth) + 1));
    const row = Math.max(1, Math.min(rows, Math.floor(relativeY / cellHeight) + 1));

    return { col, row };
  }, [columns, rows]);

  // Pointer Down for Move / Drag Reposition
  const handleStartMove = (e: React.PointerEvent, item: GridDivItem) => {
    if ((e.target as HTMLElement).closest('.resize-handle') || (e.target as HTMLElement).closest('button') || (e.target as HTMLElement).closest('input')) {
      return;
    }
    e.preventDefault();
    setSelectedItemId(item.id);
    const coords = getCellCoordinates(e.clientX, e.clientY);
    const offsetCol = coords ? Math.max(0, coords.col - item.colStart) : 0;
    const offsetRow = coords ? Math.max(0, coords.row - item.rowStart) : 0;
    setActiveDrag({
      type: 'move',
      itemId: item.id,
      startCol: item.colStart,
      startRow: item.rowStart,
      initialColSpan: item.colSpan,
      initialRowSpan: item.rowSpan,
      startX: e.clientX,
      startY: e.clientY,
      offsetCol,
      offsetRow,
    });
  };

  // Pointer Down for Resize Handle
  const handleStartResize = (e: React.PointerEvent, item: GridDivItem) => {
    e.preventDefault();
    e.stopPropagation();
    setSelectedItemId(item.id);
    setActiveDrag({
      type: 'resize',
      itemId: item.id,
      startCol: item.colStart,
      startRow: item.rowStart,
      initialColSpan: item.colSpan,
      initialRowSpan: item.rowSpan,
      startX: e.clientX,
      startY: e.clientY,
    });
  };

  // Global Pointer Move & Pointer Up
  useEffect(() => {
    if (!activeDrag) return;

    const handlePointerMove = (e: PointerEvent) => {
      const coords = getCellCoordinates(e.clientX, e.clientY);
      if (!coords) return;

      const { col, row } = coords;

      setItems(prevItems => {
        return prevItems.map(item => {
          if (item.id !== activeDrag.itemId) return item;

          if (activeDrag.type === 'move') {
            // Drag and drop reposition with offset
            const maxColStart = columns - item.colSpan + 1;
            const maxRowStart = rows - item.rowSpan + 1;

            const targetCol = col - (activeDrag.offsetCol || 0);
            const targetRow = row - (activeDrag.offsetRow || 0);

            const newColStart = Math.max(1, Math.min(maxColStart, targetCol));
            const newRowStart = Math.max(1, Math.min(maxRowStart, targetRow));

            return {
              ...item,
              colStart: newColStart,
              rowStart: newRowStart,
            };
          } else if (activeDrag.type === 'resize') {
            // Resize using handle in bottom right corner
            const newColSpan = Math.max(1, Math.min(columns - item.colStart + 1, col - item.colStart + 1));
            const newRowSpan = Math.max(1, Math.min(rows - item.rowStart + 1, row - item.rowStart + 1));

            return {
              ...item,
              colSpan: newColSpan,
              rowSpan: newRowSpan,
            };
          }

          return item;
        });
      });
    };

    const handlePointerUp = () => {
      setActiveDrag(null);
    };

    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);

    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
    };
  }, [activeDrag, columns, rows, getCellCoordinates]);

  // Format CSS Template Columns
  const gridTemplateColsCSS = colUnits.every(u => u === colUnits[0]) && colUnits[0] === '1fr'
    ? `repeat(${columns}, 1fr)`
    : colUnits.join(' ');

  const gridTemplateRowsCSS = rowUnits.every(u => u === rowUnits[0]) && rowUnits[0] === '1fr'
    ? `repeat(${rows}, 1fr)`
    : rowUnits.join(' ');

  // Generated CSS Code
  const generateCSS = () => {
    let css = `.parent {\n  display: grid;\n  grid-template-columns: ${gridTemplateColsCSS};\n  grid-template-rows: ${gridTemplateRowsCSS};\n`;
    if (colGap === rowGap) {
      css += `  gap: ${colGap}px;\n`;
    } else {
      css += `  grid-column-gap: ${colGap}px;\n  grid-row-gap: ${rowGap}px;\n`;
    }
    css += `}\n\n`;

    items.forEach(item => {
      const colEnd = item.colStart + item.colSpan;
      const rowEnd = item.rowStart + item.rowSpan;

      if (syntaxStyle === 'grid-area') {
        // cssgridgenerator.io standard: grid-area: row-start / col-start / row-end / col-end
        css += `.${item.name} {\n  grid-area: ${item.rowStart} / ${item.colStart} / ${rowEnd} / ${colEnd};\n}\n`;
      } else {
        css += `.${item.name} {\n  grid-column: ${item.colStart} / span ${item.colSpan};\n  grid-row: ${item.rowStart} / span ${item.rowSpan};\n}\n`;
      }
    });

    return css;
  };

  // Generated HTML Code
  const generateHTML = () => {
    let html = `<div class="parent">\n`;
    items.forEach(item => {
      html += `  <div class="${item.name}"></div>\n`;
    });
    html += `</div>`;
    return html;
  };

  // Copy handlers
  const copyToClipboard = (text: string, type: 'html' | 'css' | 'all') => {
    navigator.clipboard.writeText(text);
    setCopyStatus(type);
    setTimeout(() => setCopyStatus('idle'), 2000);
  };

  const selectedItem = items.find(i => i.id === selectedItemId);

  return (
    <div className="space-y-6">
      {/* 5-Step Instruction Banner directly implementing the user request */}
      {showGuide && (
        <div className="bg-gradient-to-r from-sky-900 via-slate-900 to-indigo-950 border border-sky-500/30 rounded-2xl p-5 text-white shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-white/10">
            <div className="flex items-center gap-2.5">
              <span className="p-1.5 bg-sky-500/20 text-sky-400 rounded-lg border border-sky-400/30">
                <HelpCircle className="w-5 h-5" />
              </span>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                  <span>How to use CSS Grid Generator?</span>
                  <a 
                    href="https://cssgridgenerator.io/" 
                    target="_blank" 
                    rel="noreferrer"
                    className="text-[11px] font-normal text-sky-300 hover:text-sky-200 flex items-center gap-1 bg-white/10 px-2 py-0.5 rounded-full"
                  >
                    <span>cssgridgenerator.io</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </h3>
                <p className="text-xs text-slate-300">
                  ណែនាំ ៥ ជំហានងាយៗក្នុងការបង្កើត CSS Grid Layout តាមរយៈ UI អន្តរកម្មផ្ទាល់
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowGuide(false)}
              className="text-xs text-slate-400 hover:text-white px-2 py-1 rounded bg-white/5 hover:bg-white/10 transition-colors"
            >
              បិទការណែនាំ
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
            <div className="bg-white/5 rounded-xl p-3 border border-white/10 flex flex-col justify-between hover:bg-white/10 transition-all">
              <div className="flex items-center gap-2 mb-1.5 font-bold text-sky-300">
                <span className="w-5 h-5 rounded-full bg-sky-500/30 border border-sky-400 text-sky-200 flex items-center justify-center text-[10px]">1</span>
                <span>Customize Grid</span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Customize the number of columns, rows, and gaps to fit your needs.
              </p>
            </div>

            <div className="bg-white/5 rounded-xl p-3 border border-white/10 flex flex-col justify-between hover:bg-white/10 transition-all">
              <div className="flex items-center gap-2 mb-1.5 font-bold text-emerald-300">
                <span className="w-5 h-5 rounded-full bg-emerald-500/30 border border-emerald-400 text-emerald-200 flex items-center justify-center text-[10px]">2</span>
                <span>Add Element (+)</span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Click the square with + sign to add a new element to the grid.
              </p>
            </div>

            <div className="bg-white/5 rounded-xl p-3 border border-white/10 flex flex-col justify-between hover:bg-white/10 transition-all">
              <div className="flex items-center gap-2 mb-1.5 font-bold text-violet-300">
                <span className="w-5 h-5 rounded-full bg-violet-500/30 border border-violet-400 text-violet-200 flex items-center justify-center text-[10px]">3</span>
                <span>Resize Handle</span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Resize the DIV using the handle in the bottom right corner.
              </p>
            </div>

            <div className="bg-white/5 rounded-xl p-3 border border-white/10 flex flex-col justify-between hover:bg-white/10 transition-all">
              <div className="flex items-center gap-2 mb-1.5 font-bold text-amber-300">
                <span className="w-5 h-5 rounded-full bg-amber-500/30 border border-amber-400 text-amber-200 flex items-center justify-center text-[10px]">4</span>
                <span>Drag & Reposition</span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Drag and drop the DIV to reposition it as desired.
              </p>
            </div>

            <div className="bg-white/5 rounded-xl p-3 border border-white/10 flex flex-col justify-between hover:bg-white/10 transition-all">
              <div className="flex items-center gap-2 mb-1.5 font-bold text-rose-300">
                <span className="w-5 h-5 rounded-full bg-rose-500/30 border border-rose-400 text-rose-200 flex items-center justify-center text-[10px]">5</span>
                <span>Copy Code</span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Finally, copy the generated HTML and CSS code and paste it into your project.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Visual Presets Showcase Carousel */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950 border border-slate-800 rounded-2xl p-4 text-white shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-sky-500/20 text-sky-400 rounded-xl border border-sky-400/30">
              <Palette className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white">
                  គំរូ Layouts (Presets) យកទៅប្រើបានភ្លាមៗ
                </h3>
                <span className="text-[10px] font-mono font-bold bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full">
                  {LAYOUT_PRESETS.length} គំរូពេញលេញ
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                ចុចលើគំរូណាមួយ ដើម្បីបញ្ចូល Layout ពេញលេញ និងបង្កើតកូដ CSS ស្វ័យប្រវត្តិ
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowPresetModal(true)}
            className="px-3.5 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all self-start sm:self-auto cursor-pointer shadow-xs"
          >
            <Layout className="w-3.5 h-3.5" />
            <span>មើលគំរូទាំងអស់ ({LAYOUT_PRESETS.length})</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Category Filter Pills for Top Banner */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-2 scrollbar-none">
          {[
            { id: 'all', label: 'ទាំងអស់ (All)' },
            { id: 'food', label: 'ម្ហូប & កាហ្វេ (Food/Cafe)' },
            { id: 'education', label: 'ការអប់រំ (Edu & Academic)' },
            { id: 'entertainment', label: 'ភាពយន្ត & សៀវភៅ 3D' },
            { id: 'ecommerce', label: 'ហាង & Tech' },
            { id: 'portfolio', label: 'វិចិត្រសាល (Photo & Bento)' },
            { id: 'marketing', label: 'ទេសចរណ៍ & Landing' },
            { id: 'web', label: 'គេហទំព័រ & News' },
          ].map((tab) => {
            const isTabActive = topBannerCategory === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setTopBannerCategory(tab.id)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isTabActive
                    ? 'bg-sky-500 text-white font-bold'
                    : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Quick Visual Thumbnail Cards Horizontal Row */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5">
          {(topBannerCategory === 'all'
            ? LAYOUT_PRESETS.slice(0, 12)
            : LAYOUT_PRESETS.filter(p => {
                if (topBannerCategory === 'entertainment') return p.category === 'entertainment' || p.id === '3d-book-portfolio';
                return p.category === topBannerCategory;
              })
          ).slice(0, 6).map((preset) => {
            const isCurrent = activePresetId === preset.id;
            return (
              <button
                key={preset.id}
                onClick={() => applyLayoutPreset(preset)}
                className={`group p-2 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  isCurrent
                    ? 'bg-sky-600/30 border-sky-400 ring-1 ring-sky-400 shadow-xs'
                    : 'bg-slate-950/80 hover:bg-slate-800/80 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[9px] font-bold text-sky-400 uppercase truncate">
                      {preset.categoryLabel}
                    </span>
                    <span className="text-[9px] font-mono text-slate-400">
                      {preset.columns}×{preset.rows}
                    </span>
                  </div>

                  {/* Visual Mini Wireframe Preview */}
                  <div className="bg-slate-950 p-1 rounded-lg border border-slate-800 my-1">
                    <div
                      className="w-full aspect-[16/10] rounded overflow-hidden"
                      style={{
                        display: 'grid',
                        gridTemplateColumns: preset.columns === 12 ? 'repeat(12, 1fr)' : preset.colUnits.join(' '),
                        gridTemplateRows: preset.rowUnits.join(' '),
                        gap: '2px',
                      }}
                    >
                      {preset.items.map((item) => (
                        <div
                          key={item.id}
                          style={{
                            gridColumn: `${item.colStart} / span ${item.colSpan}`,
                            gridRow: `${item.rowStart} / span ${item.rowSpan}`,
                            backgroundColor: item.color,
                          }}
                          className="rounded-[2px]"
                        />
                      ))}
                    </div>
                  </div>

                  <div className="text-[11px] font-bold text-slate-200 group-hover:text-sky-300 truncate mt-1">
                    {preset.name}
                  </div>
                </div>

                <div className="mt-1 pt-1 border-t border-white/5 flex items-center justify-between text-[10px] text-slate-400">
                  <span className="truncate">{preset.items.length} DIVs</span>
                  {isCurrent ? (
                    <span className="text-emerald-400 font-bold flex items-center gap-0.5">
                      <Check className="w-2.5 h-2.5" /> សកម្ម
                    </span>
                  ) : (
                    <span className="text-sky-400 font-semibold group-hover:underline">ប្រើ</span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Workspace Layout: Controls on Left, Visual Interactive Canvas on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Toolbar & Configuration Panel */}
        <div className="lg:col-span-4 space-y-5 bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
          {/* Header & Quick Action Buttons */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-sky-600" />
              <h3 className="font-bold text-slate-800 text-sm">Grid Settings</h3>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => loadPreset('default')}
                title="Reset to default 5x5 layout"
                className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors text-xs flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span className="text-[11px]">Reset</span>
              </button>
              <button
                onClick={handleClearAll}
                title="Clear all DIV elements"
                className="p-1.5 text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors text-xs flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="text-[11px]">Clear</span>
              </button>
            </div>
          </div>

          {/* Quick Layout Presets with Modal Opener */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700">
                គំរូ Layouts (Presets):
              </span>
              <button
                onClick={() => setShowPresetModal(true)}
                className="text-xs font-bold text-sky-600 hover:text-sky-700 flex items-center gap-0.5 cursor-pointer"
              >
                <span>មើលទាំងអស់ ({LAYOUT_PRESETS.length})</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => loadPreset('default')}
                className={`p-2 text-xs text-left rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  activePresetId === 'default'
                    ? 'bg-sky-50 border-sky-400 text-sky-900 font-bold'
                    : 'bg-slate-50 hover:bg-sky-50/60 border-slate-200 text-slate-700'
                }`}
              >
                <span className="truncate">5×5 Standard</span>
                <span className="text-[10px] text-slate-400 font-mono mt-0.5">5 DIV items</span>
              </button>
              <button
                onClick={() => {
                  const p = LAYOUT_PRESETS.find(it => it.id === 'holy-grail');
                  if (p) applyLayoutPreset(p);
                }}
                className={`p-2 text-xs text-left rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  activePresetId === 'holy-grail'
                    ? 'bg-sky-50 border-sky-400 text-sky-900 font-bold'
                    : 'bg-slate-50 hover:bg-sky-50/60 border-slate-200 text-slate-700'
                }`}
              >
                <span className="truncate">Holy Grail</span>
                <span className="text-[10px] text-slate-400 font-mono mt-0.5">3×3 • Header/Side/Main</span>
              </button>
              <button
                onClick={() => {
                  const p = LAYOUT_PRESETS.find(it => it.id === 'dashboard-admin');
                  if (p) applyLayoutPreset(p);
                }}
                className={`p-2 text-xs text-left rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  activePresetId === 'dashboard-admin'
                    ? 'bg-sky-50 border-sky-400 text-sky-900 font-bold'
                    : 'bg-slate-50 hover:bg-sky-50/60 border-slate-200 text-slate-700'
                }`}
              >
                <span className="truncate">Admin Dashboard</span>
                <span className="text-[10px] text-slate-400 font-mono mt-0.5">4×4 • Sidebar/Metrics</span>
              </button>
              <button
                onClick={() => {
                  const p = LAYOUT_PRESETS.find(it => it.id === 'bento-grid');
                  if (p) applyLayoutPreset(p);
                }}
                className={`p-2 text-xs text-left rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  activePresetId === 'bento-grid'
                    ? 'bg-sky-50 border-sky-400 text-sky-900 font-bold'
                    : 'bg-slate-50 hover:bg-sky-50/60 border-slate-200 text-slate-700'
                }`}
              >
                <span className="truncate">Bento Grid</span>
                <span className="text-[10px] text-slate-400 font-mono mt-0.5">4×3 • Modern Cards</span>
              </button>
              <button
                onClick={() => {
                  const p = LAYOUT_PRESETS.find(it => it.id === 'cafe-restaurant');
                  if (p) applyLayoutPreset(p);
                }}
                className={`p-2 text-xs text-left rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  activePresetId === 'cafe-restaurant'
                    ? 'bg-sky-50 border-sky-400 text-sky-900 font-bold'
                    : 'bg-slate-50 hover:bg-sky-50/60 border-slate-200 text-slate-700'
                }`}
              >
                <span className="truncate">Cafe & Resto</span>
                <span className="text-[10px] text-slate-400 font-mono mt-0.5">4×3 • Menu & Booking</span>
              </button>
              <button
                onClick={() => {
                  const p = LAYOUT_PRESETS.find(it => it.id === 'movie-tv-streaming');
                  if (p) applyLayoutPreset(p);
                }}
                className={`p-2 text-xs text-left rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  activePresetId === 'movie-tv-streaming'
                    ? 'bg-sky-50 border-sky-400 text-sky-900 font-bold'
                    : 'bg-slate-50 hover:bg-sky-50/60 border-slate-200 text-slate-700'
                }`}
              >
                <span className="truncate">Movie OTT</span>
                <span className="text-[10px] text-slate-400 font-mono mt-0.5">4×4 • Hero & Posters</span>
              </button>
            </div>

            {/* Prominent Browse Presets Gallery Button */}
            <button
              onClick={() => setShowPresetModal(true)}
              className="mt-2 w-full py-2 px-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Palette className="w-3.5 h-3.5 text-indigo-600" />
              <span>បណ្ណាល័យគំរូ Layouts ({LAYOUT_PRESETS.length} គំរូពេញលេញ)</span>
            </button>
          </div>

          {/* Columns & Rows Controls */}
          <div className="space-y-4 pt-3 border-t border-slate-100">
            {/* Columns Stepper */}
            <div>
              <div className="flex items-center justify-between mb-1.5 text-xs font-semibold text-slate-700">
                <span>Columns (ជួរឈរ)</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono bg-sky-50 text-sky-700 px-2 py-0.5 rounded text-xs border border-sky-200">
                    {columns} cols
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="1"
                  max="12"
                  value={columns}
                  onChange={(e) => setColumns(Number(e.target.value))}
                  className="flex-1 accent-sky-600"
                />
                <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden shrink-0">
                  <button
                    disabled={columns <= 1}
                    onClick={() => setColumns(c => Math.max(1, c - 1))}
                    className="px-2 py-1 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-700 text-xs font-mono"
                  >
                    -
                  </button>
                  <span className="px-2 text-xs font-mono font-bold text-slate-800">{columns}</span>
                  <button
                    disabled={columns >= 12}
                    onClick={() => setColumns(c => Math.min(12, c + 1))}
                    className="px-2 py-1 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-700 text-xs font-mono"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            {/* Rows Stepper */}
            <div>
              <div className="flex items-center justify-between mb-1.5 text-xs font-semibold text-slate-700">
                <span>Rows (ជួរដេក)</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded text-xs border border-indigo-200">
                    {rows} rows
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="1"
                  max="12"
                  value={rows}
                  onChange={(e) => setRows(Number(e.target.value))}
                  className="flex-1 accent-indigo-600"
                />
                <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden shrink-0">
                  <button
                    disabled={rows <= 1}
                    onClick={() => setRows(r => Math.max(1, r - 1))}
                    className="px-2 py-1 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-700 text-xs font-mono"
                  >
                    -
                  </button>
                  <span className="px-2 text-xs font-mono font-bold text-slate-800">{rows}</span>
                  <button
                    disabled={rows >= 12}
                    onClick={() => setRows(r => Math.min(12, r + 1))}
                    className="px-2 py-1 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-700 text-xs font-mono"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            {/* Gaps Controls with Link toggle */}
            <div className="pt-2">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-700">Gaps (គម្លាតចន្លោះ)</span>
                <button
                  onClick={() => setLinkGaps(!linkGaps)}
                  className={`text-[11px] px-2 py-0.5 rounded font-mono transition-colors flex items-center gap-1 ${
                    linkGaps 
                      ? 'bg-sky-100 text-sky-700 border border-sky-300' 
                      : 'bg-slate-100 text-slate-600 border border-slate-200'
                  }`}
                >
                  <span>{linkGaps ? '🔗 Linked' : '🔓 Unlinked'}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex justify-between text-[11px] text-slate-600 mb-1">
                    <span>Column Gap</span>
                    <span className="font-mono font-bold text-sky-600">{colGap}px</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="40"
                    step="2"
                    value={colGap}
                    onChange={(e) => handleColGapChange(Number(e.target.value))}
                    className="w-full accent-sky-600"
                  />
                </div>
                <div>
                  <div className="flex justify-between text-[11px] text-slate-600 mb-1">
                    <span>Row Gap</span>
                    <span className="font-mono font-bold text-indigo-600">{rowGap}px</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="40"
                    step="2"
                    value={rowGap}
                    onChange={(e) => handleRowGapChange(Number(e.target.value))}
                    className="w-full accent-indigo-600"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Selected Element Quick Controls */}
          {selectedItem && (
            <div className="pt-3 border-t border-slate-100 bg-slate-50 p-3 rounded-xl space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span 
                    className="w-3.5 h-3.5 rounded-full shadow-xs" 
                    style={{ backgroundColor: selectedItem.color }}
                  />
                  <input
                    type="text"
                    value={selectedItem.name}
                    onChange={(e) => {
                      const newName = e.target.value.trim().replace(/\s+/g, '-');
                      setItems(prev => prev.map(it => it.id === selectedItem.id ? { ...it, name: newName || 'div' } : it));
                    }}
                    className="text-xs font-mono font-bold bg-white border border-slate-200 rounded px-2 py-0.5 text-slate-800 w-28 focus:ring-1 focus:ring-sky-500"
                  />
                </div>
                <button
                  onClick={() => handleDeleteElement(selectedItem.id)}
                  className="text-rose-500 hover:text-rose-700 p-1 hover:bg-rose-50 rounded transition-colors text-xs"
                  title="Delete element"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-600">
                <div className="bg-white p-1.5 rounded border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Position:</span>
                  <span>Row {selectedItem.rowStart}, Col {selectedItem.colStart}</span>
                </div>
                <div className="bg-white p-1.5 rounded border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Span:</span>
                  <span>{selectedItem.colSpan} cols × {selectedItem.rowSpan} rows</span>
                </div>
              </div>

              <p className="text-[11px] text-slate-500 italic">
                💡 ចុចអូស <strong>Resize Handle</strong> នៅជ្រុងស្តាំក្រោមនៃ Card ដើម្បីពង្រីក ឬចុចអូស Card ទាំងមូលដើម្បីផ្លាស់ប្តូរទីតាំង។
              </p>
            </div>
          )}

          {/* Action: Get Code Modal Button */}
          <div className="pt-2">
            <button
              onClick={() => setShowCodeModal(true)}
              className="w-full py-2.5 px-4 bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold rounded-xl shadow-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Code className="w-4 h-4" />
              <span>Get HTML & CSS Code</span>
            </button>
          </div>
        </div>

        {/* Right Canvas: Interactive Grid Area (cssgridgenerator.io visual experience) */}
        <div className="lg:col-span-8 space-y-3">
          {/* Canvas Top Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 bg-slate-900 text-white px-4 py-2.5 rounded-xl text-xs">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1.5 text-sky-400 font-semibold">
                <Layout className="w-4 h-4" />
                <span>Interactive Grid Canvas</span>
              </span>
              <span className="text-slate-400">
                {columns} × {rows} ({items.length} elements placed)
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowCodeModal(true)}
                className="flex items-center gap-1 bg-white/10 hover:bg-white/20 text-sky-200 hover:text-white px-2.5 py-1 rounded-lg transition-colors font-mono text-[11px]"
              >
                <Code className="w-3.5 h-3.5" />
                <span>View Code</span>
              </button>
            </div>
          </div>

          {/* Grid Canvas Wrapper with Track Labels */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 sm:p-6 overflow-x-auto shadow-inner">
            {/* Column Track Size Header Badges */}
            <div 
              className="mb-2 pl-8 grid gap-2"
              style={{
                gridTemplateColumns: colUnits.join(' '),
                columnGap: `${colGap}px`,
              }}
            >
              {colUnits.map((unit, idx) => (
                <button
                  key={idx}
                  onClick={() => cycleUnit('col', idx)}
                  title={`Column ${idx + 1} track unit: ${unit} (Click to toggle fr/px/auto)`}
                  className="py-1 px-1.5 bg-white border border-slate-300 hover:border-sky-500 rounded text-[10px] font-mono text-center text-slate-700 shadow-2xs hover:bg-sky-50 transition-colors"
                >
                  <span className="text-slate-400 text-[9px] block">Col {idx + 1}</span>
                  <span className="font-bold text-sky-600">{unit}</span>
                </button>
              ))}
            </div>

            {/* Grid Container with Left Row Track Labels */}
            <div className="flex gap-2">
              {/* Row Track Size Labels (Left) */}
              <div 
                className="w-7 shrink-0 grid gap-2"
                style={{
                  gridTemplateRows: rowUnits.join(' '),
                  rowGap: `${rowGap}px`,
                }}
              >
                {rowUnits.map((unit, idx) => (
                  <button
                    key={idx}
                    onClick={() => cycleUnit('row', idx)}
                    title={`Row ${idx + 1} track unit: ${unit} (Click to toggle fr/px/auto)`}
                    className="h-full py-1 bg-white border border-slate-300 hover:border-indigo-500 rounded text-[9px] font-mono flex flex-col items-center justify-center text-slate-700 shadow-2xs hover:bg-indigo-50 transition-colors"
                  >
                    <span className="text-slate-400 text-[8px]">R{idx + 1}</span>
                    <span className="font-bold text-indigo-600 text-[9px]">{unit}</span>
                  </button>
                ))}
              </div>

              {/* The Actual Interactive Grid Stage */}
              <div
                ref={gridContainerRef}
                className="flex-1 bg-white border-2 border-dashed border-slate-300 rounded-xl p-3 min-h-[460px] sm:min-h-[520px] relative select-none"
                style={{
                  display: 'grid',
                  gridTemplateColumns: colUnits.join(' '),
                  gridTemplateRows: rowUnits.join(' '),
                  columnGap: `${colGap}px`,
                  rowGap: `${rowGap}px`,
                }}
              >
                {/* 1. Base Grid Cells with '+' button to add new element (Step 2 in User Request) */}
                {Array.from({ length: rows }).map((_, rIdx) => {
                  const rowNum = rIdx + 1;
                  return Array.from({ length: columns }).map((_, cIdx) => {
                    const colNum = cIdx + 1;

                    // Check if this cell is occupied by any existing item
                    const isOccupied = items.some(item => {
                      const inCol = colNum >= item.colStart && colNum < item.colStart + item.colSpan;
                      const inRow = rowNum >= item.rowStart && rowNum < item.rowStart + item.rowSpan;
                      return inCol && inRow;
                    });

                    return (
                      <div
                        key={`cell-${rowNum}-${colNum}`}
                        style={{
                          gridColumn: colNum,
                          gridRow: rowNum,
                        }}
                        className={`rounded-lg border border-slate-200/80 flex items-center justify-center transition-all ${
                          isOccupied 
                            ? 'bg-slate-50/30' 
                            : 'bg-white hover:bg-sky-50/70 hover:border-sky-300 group cursor-pointer'
                        }`}
                        onClick={() => {
                          if (!isOccupied) {
                            handleAddElement(rowNum, colNum);
                          }
                        }}
                      >
                        {!isOccupied && (
                          <button
                            type="button"
                            className="w-7 h-7 rounded-md border border-dashed border-slate-300 group-hover:border-sky-500 group-hover:bg-sky-500 group-hover:text-white text-slate-400 flex items-center justify-center transition-all shadow-2xs"
                            title={`Click '+' to add element at Row ${rowNum}, Col ${colNum}`}
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    );
                  });
                })}

                {/* 2. Placed DIV Elements with Drag & Drop and Resize Handle (Steps 3 & 4 in User Request) */}
                {items.map((item) => {
                  const isSelected = item.id === selectedItemId;
                  const isDraggingThis = activeDrag?.itemId === item.id;

                  return (
                    <div
                      key={item.id}
                      onPointerDown={(e) => handleStartMove(e, item)}
                      onClick={() => setSelectedItemId(item.id)}
                      style={{
                        gridColumn: `${item.colStart} / span ${item.colSpan}`,
                        gridRow: `${item.rowStart} / span ${item.rowSpan}`,
                        backgroundColor: `${item.color}20`,
                        borderColor: item.color,
                        zIndex: isDraggingThis ? 20 : isSelected ? 10 : 5,
                      }}
                      className={`relative rounded-xl border-2 p-2.5 flex flex-col justify-between transition-shadow cursor-grab active:cursor-grabbing backdrop-blur-2xs ${
                        isSelected 
                          ? 'ring-2 ring-offset-1 ring-sky-500 shadow-md' 
                          : 'hover:shadow-sm'
                      } ${isDraggingThis ? 'opacity-90 shadow-xl' : ''}`}
                    >
                      {/* Top bar of DIV Card: Name + Span badge + Delete */}
                      <div className="flex items-center justify-between gap-1">
                        <div className="flex items-center gap-1.5 overflow-hidden">
                          <span 
                            className="w-2.5 h-2.5 rounded-full shrink-0" 
                            style={{ backgroundColor: item.color }} 
                          />
                          <span className="font-mono font-bold text-xs text-slate-900 truncate">
                            .{item.name}
                          </span>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white/80 text-slate-700 border border-slate-200/60 shadow-2xs">
                            {item.colSpan}×{item.rowSpan}
                          </span>
                          <button
                            type="button"
                            onClick={(e) => handleDeleteElement(item.id, e)}
                            className="w-5 h-5 rounded hover:bg-rose-500 hover:text-white text-slate-400 flex items-center justify-center transition-colors"
                            title="Remove element"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      {/* Center information / drag cue */}
                      <div className="flex-1 flex flex-col items-center justify-center my-1 text-center pointer-events-none opacity-80">
                        <Move className="w-3.5 h-3.5 text-slate-400 mb-0.5" />
                        <span className="text-[10px] font-mono text-slate-600 font-medium">
                          R{item.rowStart}:C{item.colStart}
                        </span>
                      </div>

                      {/* Bottom row: Spanning details & Step 3: Resize Handle in Bottom Right Corner */}
                      <div className="flex items-end justify-between mt-auto">
                        <span className="text-[9px] font-mono text-slate-500 pointer-events-none">
                          area: {item.rowStart}/{item.colStart}/{item.rowStart + item.rowSpan}/{item.colStart + item.colSpan}
                        </span>

                        {/* Dedicated Resize Handle in the Bottom Right Corner */}
                        <div
                          onPointerDown={(e) => handleStartResize(e, item)}
                          className="resize-handle w-5 h-5 -mr-1 -mb-1 rounded-br-lg rounded-tl-md bg-white border border-slate-300 hover:bg-sky-500 hover:text-white text-slate-600 flex items-center justify-center cursor-nwse-resize shadow-xs transition-colors z-30"
                          title="Resize DIV: Drag to expand/shrink columns and rows"
                        >
                          <svg className="w-3 h-3" viewBox="0 0 16 16" fill="currentColor">
                            <circle cx="12" cy="12" r="1.5" />
                            <circle cx="8" cy="12" r="1.5" />
                            <circle cx="12" cy="8" r="1.5" />
                            <circle cx="4" cy="12" r="1.5" />
                            <circle cx="8" cy="8" r="1.5" />
                            <circle cx="12" cy="4" r="1.5" />
                          </svg>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Embedded Live Code & Real-Time Output Panel */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 text-white overflow-hidden shadow-md">
            {/* Panel Header & Navigation */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between px-4 py-3 bg-slate-950/80 border-b border-slate-800 gap-2">
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1 text-xs font-bold text-sky-400">
                  <Code className="w-4 h-4" />
                  <span>Live Code & Preview:</span>
                </span>

                {/* Tabs */}
                <div className="flex bg-slate-800 p-0.5 rounded-lg border border-slate-700 text-xs">
                  <button
                    onClick={() => setActiveCodeTab('css')}
                    className={`px-3 py-1 rounded-md font-mono text-[11px] font-semibold transition-all cursor-pointer ${
                      activeCodeTab === 'css'
                        ? 'bg-sky-600 text-white shadow-xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    CSS (styles.css)
                  </button>
                  <button
                    onClick={() => setActiveCodeTab('html')}
                    className={`px-3 py-1 rounded-md font-mono text-[11px] font-semibold transition-all cursor-pointer ${
                      activeCodeTab === 'html'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    HTML (index.html)
                  </button>
                  <button
                    onClick={() => setActiveCodeTab('preview')}
                    className={`flex items-center gap-1 px-3 py-1 rounded-md font-mono text-[11px] font-semibold transition-all cursor-pointer ${
                      activeCodeTab === 'preview'
                        ? 'bg-purple-600 text-white shadow-xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Eye className="w-3 h-3" />
                    <span>Real-World Mockup</span>
                  </button>
                </div>
              </div>

              {/* Controls on Right */}
              <div className="flex items-center gap-2">
                {activeCodeTab === 'css' && (
                  <div className="flex bg-slate-800 p-0.5 rounded-md border border-slate-700 text-[10px]">
                    <button
                      onClick={() => setSyntaxStyle('grid-area')}
                      className={`px-2 py-0.5 rounded font-mono transition-colors cursor-pointer ${
                        syntaxStyle === 'grid-area' ? 'bg-sky-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                      }`}
                      title="Syntax: grid-area: row-start / col-start / row-end / col-end"
                    >
                      grid-area
                    </button>
                    <button
                      onClick={() => setSyntaxStyle('grid-column-row')}
                      className={`px-2 py-0.5 rounded font-mono transition-colors cursor-pointer ${
                        syntaxStyle === 'grid-column-row' ? 'bg-sky-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                      }`}
                      title="Syntax: grid-column: start / span n; grid-row: start / span n"
                    >
                      column / row
                    </button>
                  </div>
                )}

                {/* Copy Button */}
                <button
                  onClick={() => {
                    if (activeCodeTab === 'css') copyToClipboard(generateCSS(), 'css');
                    else if (activeCodeTab === 'html') copyToClipboard(generateHTML(), 'html');
                    else {
                      const combined = `<!-- HTML -->\n${generateHTML()}\n\n/* CSS */\n${generateCSS()}`;
                      copyToClipboard(combined, 'all');
                    }
                  }}
                  className="px-2.5 py-1 bg-white/10 hover:bg-white/20 text-white rounded-lg flex items-center gap-1.5 font-mono text-[11px] transition-colors cursor-pointer"
                >
                  {copyStatus !== 'idle' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-slate-300" />
                      <span>
                        {activeCodeTab === 'css' ? 'Copy CSS' : activeCodeTab === 'html' ? 'Copy HTML' : 'Copy HTML & CSS'}
                      </span>
                    </>
                  )}
                </button>

                {/* Modal Trigger */}
                <button
                  onClick={() => setShowCodeModal(true)}
                  className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                  title="Full screen code modal"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Panel Body */}
            <div className="p-4">
              {activeCodeTab === 'css' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span>Generated CSS rules for parent container & {items.length} child elements:</span>
                    <span className="text-sky-400">Syntax: {syntaxStyle}</span>
                  </div>
                  <pre className="bg-slate-950 p-4 rounded-xl text-xs font-mono text-sky-300 overflow-x-auto border border-slate-800/80 leading-relaxed max-h-64 scrollbar-thin">
                    {generateCSS()}
                  </pre>
                </div>
              )}

              {activeCodeTab === 'html' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span>HTML template with parent container and DIV class names:</span>
                    <span className="text-emerald-400">{items.length} child DIVs</span>
                  </div>
                  <pre className="bg-slate-950 p-4 rounded-xl text-xs font-mono text-emerald-300 overflow-x-auto border border-slate-800/80 leading-relaxed max-h-64 scrollbar-thin">
                    {generateHTML()}
                  </pre>
                </div>
              )}

              {activeCodeTab === 'preview' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-slate-300">
                    <span className="font-semibold text-purple-300">
                      💡 របៀបបង្ហាញជាក់ស្តែង (Real-World Web Preview)៖
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {columns} cols × {rows} rows | gap: {colGap}px {rowGap}px
                    </span>
                  </div>

                  <div
                    className="p-4 bg-slate-950 rounded-xl border border-slate-800 min-h-[260px] overflow-x-auto"
                    style={{
                      display: 'grid',
                      gridTemplateColumns: colUnits.join(' '),
                      gridTemplateRows: rowUnits.join(' '),
                      columnGap: `${colGap}px`,
                      rowGap: `${rowGap}px`,
                    }}
                  >
                    {items.map((item, idx) => {
                      const isFirst = idx === 0;
                      return (
                        <div
                          key={`mock-${item.id}`}
                          style={{
                            gridColumn: `${item.colStart} / span ${item.colSpan}`,
                            gridRow: `${item.rowStart} / span ${item.rowSpan}`,
                            backgroundColor: `${item.color}25`,
                            borderColor: item.color,
                          }}
                          className="rounded-lg border p-3 flex flex-col justify-between text-white shadow-xs"
                        >
                          <div>
                            <div className="flex items-center justify-between gap-1 mb-1">
                              <span 
                                className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded text-white"
                                style={{ backgroundColor: item.color }}
                              >
                                .{item.name}
                              </span>
                              <span className="text-[9px] text-slate-400 font-mono">
                                {item.colSpan}×{item.rowSpan}
                              </span>
                            </div>
                            <div className="text-xs font-bold text-slate-100 truncate">
                              {isFirst && item.colSpan >= 3 ? 'Hero Banner / Navigation Bar' : `Card Widget: ${item.name}`}
                            </div>
                            <p className="text-[11px] text-slate-300 line-clamp-2 mt-1">
                              {isFirst 
                                ? 'មាតិកាសំខាន់លើគេសម្រាប់ Web Application' 
                                : 'ទិន្នន័យ ឬកាតបង្ហាញព័ត៌មានតាម grid cell'}
                            </p>
                          </div>

                          <div className="pt-2 mt-2 border-t border-white/10 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                            <span>area: {item.rowStart}/{item.colStart}</span>
                            <span className="text-emerald-400">Active</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Code Export Modal / Dialog (Step 5 in User Request) */}
      {showCodeModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-white animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
              <div className="flex items-center gap-2.5">
                <Code className="w-5 h-5 text-sky-400" />
                <div>
                  <h3 className="font-bold text-base text-white">Generated CSS Grid Code</h3>
                  <p className="text-xs text-slate-400">
                    ចម្លងកូដ HTML និង CSS យកទៅប្រើប្រាស់ក្នុងគម្រោង Web របស់អ្នកភ្លាមៗ
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                {/* Syntax Selector */}
                <div className="flex bg-slate-800 p-0.5 rounded-lg border border-slate-700 text-xs">
                  <button
                    onClick={() => setSyntaxStyle('grid-area')}
                    className={`px-2.5 py-1 rounded-md font-mono transition-colors ${
                      syntaxStyle === 'grid-area' ? 'bg-sky-600 text-white font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    grid-area
                  </button>
                  <button
                    onClick={() => setSyntaxStyle('grid-column-row')}
                    className={`px-2.5 py-1 rounded-md font-mono transition-colors ${
                      syntaxStyle === 'grid-column-row' ? 'bg-sky-600 text-white font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    column / row
                  </button>
                </div>

                <button
                  onClick={() => setShowCodeModal(false)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Modal Content: Code Blocks */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* CSS Code Section */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-sky-400 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-sky-400"></span>
                    CSS (styles.css)
                  </span>
                  <button
                    onClick={() => copyToClipboard(generateCSS(), 'css')}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-xs font-mono rounded flex items-center gap-1.5 transition-colors"
                  >
                    {copyStatus === 'css' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy CSS</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="bg-slate-950 p-4 rounded-xl text-xs font-mono text-sky-300 overflow-x-auto border border-slate-800 leading-relaxed max-h-56">
                  {generateCSS()}
                </pre>
              </div>

              {/* HTML Code Section */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    HTML (index.html)
                  </span>
                  <button
                    onClick={() => copyToClipboard(generateHTML(), 'html')}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-xs font-mono rounded flex items-center gap-1.5 transition-colors"
                  >
                    {copyStatus === 'html' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy HTML</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="bg-slate-950 p-4 rounded-xl text-xs font-mono text-emerald-300 overflow-x-auto border border-slate-800 leading-relaxed max-h-48">
                  {generateHTML()}
                </pre>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-4 border-t border-slate-800 bg-slate-900/90 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-xs text-slate-400 flex items-center gap-2">
                <span>Standard CSS Grid</span>
                <span>•</span>
                <span>Compatibility: All modern browsers</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const combined = `<!-- HTML -->\n${generateHTML()}\n\n/* CSS */\n${generateCSS()}`;
                    copyToClipboard(combined, 'all');
                  }}
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold rounded-xl flex items-center gap-2 transition-colors cursor-pointer"
                >
                  {copyStatus === 'all' ? (
                    <>
                      <Check className="w-4 h-4 text-white" />
                      <span>Copied HTML & CSS!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy HTML & CSS</span>
                    </>
                  )}
                </button>
                <button
                  onClick={() => setShowCodeModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-xl transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Visual Presets Gallery Modal */}
      {showPresetModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-5xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-sky-500/20 text-sky-400 rounded-2xl border border-sky-400/30">
                  <Palette className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-white">
                      បណ្ណាល័យគំរូរូបភាព Layouts (CSS Grid Presets Gallery)
                    </h3>
                    <span className="text-xs font-mono font-bold bg-sky-500/20 text-sky-300 px-2.5 py-0.5 rounded-full border border-sky-400/30">
                      {LAYOUT_PRESETS.length} គំរូពេញលេញ
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    ជ្រើសរើសគំរូរូបភាព Layout ណាមួយ ដើម្បីបញ្ចូលក្នុង Grid Generator និងទាញយកកូដ CSS ប្រើប្រាស់ភ្លាមៗ
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowPresetModal(false)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
                title="បិទ (Close)"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body: VisualPresetGallery */}
            <div className="p-6 overflow-y-auto bg-slate-900/95 flex-1 scrollbar-thin">
              <VisualPresetGallery
                onSelectPreset={(p) => {
                  applyLayoutPreset(p);
                }}
                activePresetId={activePresetId}
                isModal={true}
                onCloseModal={() => setShowPresetModal(false)}
              />
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3.5 border-t border-slate-800 bg-slate-950 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-400">
              <span>💡 គំរូទាំងអស់ប្រើប្រាស់ Standard CSS Grid (ឆបគ្នាជាមួយ modern browsers 100%)</span>
              <button
                onClick={() => setShowPresetModal(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl transition-colors cursor-pointer"
              >
                បិទ (Close)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification for Preset Application */}
      {presetToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white border border-sky-500/40 px-4 py-3 rounded-2xl shadow-xl flex items-center gap-3 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-full border border-emerald-400/30">
            <Check className="w-4 h-4" />
          </div>
          <span className="text-xs font-semibold text-slate-100">{presetToast}</span>
        </div>
      )}
    </div>
  );
};
