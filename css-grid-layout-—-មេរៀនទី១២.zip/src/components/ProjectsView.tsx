import React, { useState } from 'react';
import { Smartphone, Tablet, Monitor, Copy, Check, ExternalLink, Image, LayoutDashboard, Code } from 'lucide-react';
import { SECTIONS_11_TO_15 } from '../data/sections11to15';

export const ProjectsView: React.FC = () => {
  const [activeProject, setActiveProject] = useState<'gallery' | 'dashboard'>('dashboard');
  const [viewportWidth, setViewportWidth] = useState<'360' | '768' | '1280'>('1280');
  const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const galleryData = SECTIONS_11_TO_15.find(s => s.id === 'sec-12-14')!;
  const dashboardData = SECTIONS_11_TO_15.find(s => s.id === 'sec-12-15')!;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const getContainerMaxWidth = () => {
    switch (viewportWidth) {
      case '360': return '360px';
      case '768': return '768px';
      case '1280': return '100%';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Banner & Selector */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <span className="text-xs font-mono font-bold text-sky-600 bg-sky-50 px-2.5 py-1 rounded-full">
              Real-World CSS Grid Projects
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
              គម្រោងអនុវត្តជាក់ស្តែងពេញលេញ (Live Practical Projects)
            </h2>
            <p className="text-slate-600 text-sm mt-1">
              គម្រោងទាំងពីរត្រូវបានសរសេរឡើងដោយប្រើ HTML5 និង CSS សុទ្ធសាធ (Pure CSS) ដោយគ្មាន Framework និង Responsive លើគ្រប់ឧបករណ៍។
            </p>
          </div>

          {/* Project Switcher */}
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setActiveProject('dashboard')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                activeProject === 'dashboard'
                  ? 'bg-white text-sky-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Student Dashboard</span>
            </button>
            <button
              onClick={() => setActiveProject('gallery')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                activeProject === 'gallery'
                  ? 'bg-white text-sky-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Image className="w-4 h-4" />
              <span>Campus Gallery</span>
            </button>
          </div>
        </div>
      </div>

      {/* Toolbar: Preview vs Code + Viewport Selector */}
      <div className="bg-slate-900 text-white rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-3">
          <div className="flex bg-slate-800 p-1 rounded-lg border border-slate-700">
            <button
              onClick={() => setViewMode('preview')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                viewMode === 'preview' ? 'bg-sky-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Live Preview</span>
            </button>
            <button
              onClick={() => setViewMode('code')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                viewMode === 'code' ? 'bg-sky-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Code className="w-3.5 h-3.5" />
              <span>Source Code (HTML & CSS)</span>
            </button>
          </div>
        </div>

        {/* Viewport Width Controls (Active only in preview mode) */}
        {viewMode === 'preview' && (
          <div className="flex items-center gap-2">
            <span className="text-slate-400 text-xs hidden sm:inline">សាកល្បងទំហំអេក្រង់៖</span>
            <div className="flex bg-slate-800 p-1 rounded-lg border border-slate-700 text-xs">
              <button
                onClick={() => setViewportWidth('360')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
                  viewportWidth === '360' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Mobile (360px)</span>
              </button>
              <button
                onClick={() => setViewportWidth('768')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
                  viewportWidth === '768' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Tablet className="w-3.5 h-3.5" />
                <span>Tablet (768px)</span>
              </button>
              <button
                onClick={() => setViewportWidth('1280')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
                  viewportWidth === '1280' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>Desktop (Full)</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Main Content Area */}
      {viewMode === 'preview' ? (
        <div className="bg-slate-200 border-2 border-dashed border-slate-300 rounded-2xl p-4 sm:p-8 flex justify-center overflow-x-auto min-h-[600px]">
          <div
            className="w-full transition-all duration-300 bg-white rounded-xl shadow-lg overflow-hidden border border-slate-300"
            style={{ maxWidth: getContainerMaxWidth() }}
          >
            {activeProject === 'dashboard' ? (
              <StudentDashboardSimulation viewport={viewportWidth} />
            ) : (
              <CampusGallerySimulation viewport={viewportWidth} />
            )}
          </div>
        </div>
      ) : (
        /* Source Code Viewer with Copy */
        <div className="space-y-6">
          {/* HTML Block */}
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
            <div className="bg-slate-800 text-slate-200 px-5 py-3 flex items-center justify-between text-xs font-mono">
              <span className="font-bold text-amber-400">
                {activeProject === 'dashboard' ? 'index.html (Student Dashboard)' : 'index.html (Campus Gallery)'}
              </span>
              <button
                onClick={() =>
                  handleCopy(
                    activeProject === 'dashboard' ? dashboardData.htmlExample : galleryData.htmlExample,
                    'project-html'
                  )
                }
                className="flex items-center gap-1.5 bg-slate-700 hover:bg-slate-600 text-white px-3 py-1.5 rounded-md transition-colors"
              >
                {copiedKey === 'project-html' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400 font-semibold">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Pure HTML</span>
                  </>
                )}
              </button>
            </div>
            <pre className="p-5 bg-slate-950 text-amber-200 text-xs sm:text-sm font-mono overflow-x-auto leading-relaxed max-h-[480px]">
              {activeProject === 'dashboard' ? dashboardData.htmlExample : galleryData.htmlExample}
            </pre>
          </div>

          {/* CSS Block */}
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
            <div className="bg-slate-800 text-slate-200 px-5 py-3 flex items-center justify-between text-xs font-mono">
              <span className="font-bold text-sky-400">
                {activeProject === 'dashboard' ? 'css/style.css (Dashboard CSS Grid)' : 'gallery.css (Gallery CSS Grid)'}
              </span>
              <button
                onClick={() =>
                  handleCopy(
                    activeProject === 'dashboard' ? dashboardData.cssExample : galleryData.cssExample,
                    'project-css'
                  )
                }
                className="flex items-center gap-1.5 bg-slate-700 hover:bg-slate-600 text-white px-3 py-1.5 rounded-md transition-colors"
              >
                {copiedKey === 'project-css' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400 font-semibold">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Pure CSS</span>
                  </>
                )}
              </button>
            </div>
            <pre className="p-5 bg-slate-950 text-sky-200 text-xs sm:text-sm font-mono overflow-x-auto leading-relaxed max-h-[480px]">
              {activeProject === 'dashboard' ? dashboardData.cssExample : galleryData.cssExample}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};

/* Live Embedded Simulation Components matching pure CSS Grid rules */

const StudentDashboardSimulation: React.FC<{ viewport: string }> = ({ viewport }) => {
  const isDesktop = viewport === '1280';

  return (
    <div
      style={{
        display: 'grid',
        minHeight: '600px',
        gridTemplateColumns: isDesktop ? '230px 1fr' : '1fr',
        gridTemplateRows: isDesktop ? '60px 1fr 48px' : 'auto auto 1fr auto',
        gridTemplateAreas: isDesktop
          ? '"header header" "sidebar main" "footer footer"'
          : '"header" "sidebar" "main" "footer"',
        fontFamily: "'Kantumruy Pro', sans-serif",
        backgroundColor: '#f1f5f9',
        color: '#1e293b'
      }}
    >
      {/* Header */}
      <header
        style={{
          gridArea: 'header',
          backgroundColor: '#1e3a8a',
          color: '#ffffff',
          padding: '12px 20px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderBottom: '2px solid #1d4ed8'
        }}
      >
        <h1 style={{ fontSize: '16px', fontWeight: 'bold' }}>
          វិទ្យាស្ថានបច្ចេកវិទ្យាព័ត៌មាន (IT Portal)
        </h1>
        <span style={{ fontSize: '13px', opacity: 0.9 }}>
          និស្សិត៖ ហេង សំណាង (ទិន្នន័យគំរូ)
        </span>
      </header>

      {/* Sidebar */}
      <nav
        style={{
          gridArea: 'sidebar',
          backgroundColor: '#ffffff',
          borderRight: isDesktop ? '1px solid #e2e8f0' : 'none',
          borderBottom: isDesktop ? 'none' : '1px solid #e2e8f0',
          padding: '16px'
        }}
      >
        <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: isDesktop ? 'block' : 'flex', flexWrap: 'wrap', gap: '8px' }}>
          {['ផ្ទាំងគ្រប់គ្រង', 'មុខវិជ្ជាចុះឈ្មោះ', 'កាលវិភាគប្រឡង', 'លទ្ធផលសិក្សា', 'កំណត់គណនី'].map((item, idx) => (
            <li key={idx} style={{ marginBottom: isDesktop ? '6px' : 0 }}>
              <a
                href="#link"
                onClick={(e) => e.preventDefault()}
                style={{
                  display: 'block',
                  padding: '8px 12px',
                  borderRadius: '6px',
                  textDecoration: 'none',
                  fontSize: '13px',
                  fontWeight: idx === 0 ? 600 : 500,
                  backgroundColor: idx === 0 ? '#eff6ff' : 'transparent',
                  color: idx === 0 ? '#1d4ed8' : '#475569'
                }}
              >
                {item}
              </a>
            </li>
          ))}
        </ul>
      </nav>

      {/* Main Content */}
      <main style={{ gridArea: 'main', padding: '20px' }}>
        <h2 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '16px', color: '#0f172a' }}>
          ទិដ្ឋភាពទូទៅនៃការសិក្សា (Student Overview)
        </h2>

        {/* 4 Stats Cards (Nested Grid) */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: isDesktop ? 'repeat(4, 1fr)' : viewport === '768' ? 'repeat(2, 1fr)' : '1fr',
            gap: '14px',
            marginBottom: '24px'
          }}
        >
          {[
            { title: 'ក្រេឌីតសរុប', value: '៦៤ / ១២០', sub: 'ឆមាសទី១ ឆ្នាំទី២', color: '#0284c7' },
            { title: 'GPA មធ្យមភាគ', value: '៣.៨២', sub: 'និទ្ទេសល្អប្រសើរ', color: '#059669' },
            { title: 'មុខវិជ្ជាកំពុងរៀន', value: '៥ មុខវិជ្ជា', sub: '១៥ ម៉ោងក្នុងមួយសប្តាហ៍', color: '#6366f1' },
            { title: 'វត្តមានសរុប', value: '៩៨%', sub: 'ទៀងទាត់តាមកាលវិភាគ', color: '#d97706' },
          ].map((stat, i) => (
            <div
              key={i}
              style={{
                backgroundColor: '#ffffff',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                padding: '14px',
                boxShadow: '0 1px 3px rgba(0,0,0,0.04)'
              }}
            >
              <div style={{ fontSize: '12px', color: '#64748b', marginBottom: '4px' }}>{stat.title}</div>
              <div style={{ fontSize: '20px', fontWeight: 'bold', color: stat.color, marginBottom: '2px' }}>
                {stat.value}
              </div>
              <div style={{ fontSize: '11px', color: '#10b981' }}>{stat.sub}</div>
            </div>
          ))}
        </div>

        {/* Courses Enrolled (Nested Grid) */}
        <div style={{ backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '16px' }}>
          <h3 style={{ fontSize: '15px', fontWeight: 'bold', marginBottom: '12px' }}>
            មុខវិជ្ជាកំពុងសិក្សាក្នុងឆមាសនេះ (ទិន្នន័យគំរូ)
          </h3>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: isDesktop || viewport === '768' ? '1fr 1fr' : '1fr',
              gap: '12px'
            }}
          >
            <div style={{ border: '1px solid #e2e8f0', borderRadius: '6px', padding: '12px' }}>
              <div style={{ fontWeight: 600, fontSize: '13px', color: '#1e293b' }}>
                CS201: Web Development II (CSS Grid)
              </div>
              <div style={{ fontSize: '12px', color: '#64748b', margin: '4px 0 8px' }}>
                សាស្រ្តាចារ្យ៖ សុខ ចាន់ថន | Lab 302
              </div>
              <div style={{ width: '100%', height: '6px', backgroundColor: '#e2e8f0', borderRadius: '3px', overflow: 'hidden' }}>
                <div style={{ width: '75%', height: '100%', backgroundColor: '#2563eb' }}></div>
              </div>
            </div>

            <div style={{ border: '1px solid #e2e8f0', borderRadius: '6px', padding: '12px' }}>
              <div style={{ fontWeight: 600, fontSize: '13px', color: '#1e293b' }}>
                CS202: Data Structures & Algorithms
              </div>
              <div style={{ fontSize: '12px', color: '#64748b', margin: '4px 0 8px' }}>
                សាស្រ្តាចារ្យ៖ គង់ សុជាតិ | Room 405
              </div>
              <div style={{ width: '100%', height: '6px', backgroundColor: '#e2e8f0', borderRadius: '3px', overflow: 'hidden' }}>
                <div style={{ width: '60%', height: '100%', backgroundColor: '#2563eb' }}></div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer
        style={{
          gridArea: 'footer',
          backgroundColor: '#ffffff',
          borderTop: '1px solid #e2e8f0',
          padding: '12px 20px',
          textAlign: 'center',
          fontSize: '12px',
          color: '#64748b'
        }}
      >
        &copy; ២០២៦ មហាវិទ្យាល័យវិទ្យាសាស្ត្រ និងបច្ចេកវិទ្យា។ រក្សាសិទ្ធិគ្រប់យ៉ាង។
      </footer>
    </div>
  );
};

const CampusGallerySimulation: React.FC<{ viewport: string }> = ({ viewport }) => {
  const isMobile = viewport === '360';

  const galleryItems = [
    {
      title: 'អគារបណ្ណាល័យកណ្តាល (Featured 2x2)',
      featured: true,
      url: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=800&auto=format&fit=crop&q=80'
    },
    {
      title: 'និស្សិតពិភាក្សាមេរៀនជាក្រុម',
      featured: false,
      url: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=600&auto=format&fit=crop&q=80'
    },
    {
      title: 'បរិវេណអគារសិក្សាព័ត៌មានវិទ្យា',
      featured: false,
      url: 'https://images.unsplash.com/photo-1562774053-701939374585?w=600&auto=format&fit=crop&q=80'
    },
    {
      title: 'ម៉ោងអនុវត្តជាក់ស្តែងក្នុង Lab',
      featured: false,
      url: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600&auto=format&fit=crop&q=80'
    },
    {
      title: 'បទបង្ហាញគម្រោង Final Project',
      featured: false,
      url: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=600&auto=format&fit=crop&q=80'
    },
    {
      title: 'ក្លឹបបង្កើតគំនិតច្នៃប្រឌិត (Innovation Club)',
      featured: false,
      url: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?w=600&auto=format&fit=crop&q=80'
    }
  ];

  return (
    <div style={{ backgroundColor: '#0f172a', padding: '24px 16px', color: '#f8fafc', minHeight: '600px' }}>
      <div style={{ textAlign: 'center', marginBottom: '24px' }}>
        <h2 style={{ fontSize: '20px', fontWeight: 'bold', color: '#38bdf8', marginBottom: '6px' }}>
          វិចិត្រសាលសកម្មភាពនិស្សិត និងបរិវេណសាលា (Campus Gallery)
        </h2>
        <p style={{ fontSize: '13px', color: '#94a3b8' }}>
          ទិន្នន័យរូបភាពគំរូ — ប្រើ CSS Grid, repeat(), auto-fit, minmax(), និង aspect-ratio
        </p>
      </div>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: isMobile ? '1fr' : 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: '14px',
          maxWidth: '1000px',
          margin: '0 auto'
        }}
      >
        {galleryItems.map((item, idx) => {
          const isFeatured = item.featured && !isMobile;
          return (
            <figure
              key={idx}
              style={{
                position: 'relative',
                borderRadius: '8px',
                overflow: 'hidden',
                backgroundColor: '#1e293b',
                border: '1px solid #334155',
                gridColumn: isFeatured ? 'span 2' : 'auto',
                gridRow: isFeatured ? 'span 2' : 'auto',
                margin: 0
              }}
            >
              <img
                src={item.url}
                alt={item.title}
                style={{
                  width: '100%',
                  height: '100%',
                  aspectRatio: isFeatured ? 'auto' : '4/3',
                  objectFit: 'cover',
                  display: 'block'
                }}
              />
              <figcaption
                style={{
                  position: 'absolute',
                  bottom: 0,
                  left: 0,
                  right: 0,
                  background: 'linear-gradient(to top, rgba(0,0,0,0.85), transparent)',
                  color: '#ffffff',
                  padding: '12px',
                  fontSize: '13px'
                }}
              >
                {item.title}
              </figcaption>
            </figure>
          );
        })}
      </div>
    </div>
  );
};
