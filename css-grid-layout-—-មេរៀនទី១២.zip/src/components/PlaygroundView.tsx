import React, { useState } from 'react';
import { Sliders, Copy, Check, Eye, RefreshCw, Smartphone, Tablet, Monitor, Sparkles, LayoutGrid } from 'lucide-react';
import { CssGridGenerator } from './CssGridGenerator';

type PresetType = 'equal3' | 'sidebar' | 'autofit' | 'autofill' | 'featured';

export const PlaygroundView: React.FC = () => {
  const [activeMode, setActiveMode] = useState<'generator' | 'simulator'>('generator');
  const [columnsMode, setColumnsMode] = useState<string>('repeat(3, 1fr)');
  const [gapSize, setGapSize] = useState<number>(16);
  const [itemsCount, setItemsCount] = useState<number>(6);
  const [showLineNumbers, setShowLineNumbers] = useState<boolean>(true);
  const [containerWidth, setContainerWidth] = useState<'mobile' | 'tablet' | 'desktop'>('desktop');
  const [selectedItem, setSelectedItem] = useState<number>(1);
  const [itemColSpan, setItemColSpan] = useState<number>(1);
  const [itemRowSpan, setItemRowSpan] = useState<number>(1);
  const [copied, setCopied] = useState<boolean>(false);

  const applyPreset = (preset: PresetType) => {
    switch (preset) {
      case 'equal3':
        setColumnsMode('repeat(3, 1fr)');
        setGapSize(16);
        setItemsCount(6);
        setItemColSpan(1);
        setItemRowSpan(1);
        break;
      case 'sidebar':
        setColumnsMode('240px 1fr');
        setGapSize(20);
        setItemsCount(4);
        setItemColSpan(1);
        setItemRowSpan(1);
        break;
      case 'autofit':
        setColumnsMode('repeat(auto-fit, minmax(200px, 1fr))');
        setGapSize(16);
        setItemsCount(3);
        setItemColSpan(1);
        setItemRowSpan(1);
        break;
      case 'autofill':
        setColumnsMode('repeat(auto-fill, minmax(200px, 1fr))');
        setGapSize(16);
        setItemsCount(3);
        setItemColSpan(1);
        setItemRowSpan(1);
        break;
      case 'featured':
        setColumnsMode('repeat(3, 1fr)');
        setGapSize(16);
        setItemsCount(6);
        setSelectedItem(1);
        setItemColSpan(2);
        setItemRowSpan(2);
        break;
    }
  };

  const generatedCss = `.grid-container {
  display: grid;
  grid-template-columns: ${columnsMode};
  gap: ${gapSize}px;
}

/* Item ${selectedItem} Custom Spanning */
.item-${selectedItem} {
  ${itemColSpan > 1 ? `grid-column: span ${itemColSpan};` : '/* grid-column: span 1 (default) */'}
  ${itemRowSpan > 1 ? `grid-row: span ${itemRowSpan};` : '/* grid-row: span 1 (default) */'}
}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedCss);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getContainerMaxWidth = () => {
    switch (containerWidth) {
      case 'mobile': return '360px';
      case 'tablet': return '768px';
      case 'desktop': return '100%';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Tool Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-white p-2 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex bg-slate-100 p-1 rounded-xl gap-1">
          <button
            onClick={() => setActiveMode('generator')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              activeMode === 'generator'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>CSS Grid Generator (cssgridgenerator.io)</span>
            <span className="bg-sky-500/30 text-[10px] text-white px-1.5 py-0.5 rounded-full uppercase tracking-wider">
              NEW
            </span>
          </button>
          <button
            onClick={() => setActiveMode('simulator')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              activeMode === 'simulator'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>Properties & Viewport Sandbox</span>
          </button>
        </div>

        <div className="text-xs text-slate-500 px-3 py-1 flex items-center gap-1.5">
          {activeMode === 'generator' ? (
            <span className="text-sky-700 font-medium">
              ✨ គាំទ្រ Add Element (+), Drag to Reposition, Resize Corner Handle & Copy Code
            </span>
          ) : (
            <span>💡 ពិសោធន៍ minmax(), repeat() និង auto-fit/auto-fill លើអេក្រង់ 360px</span>
          )}
        </div>
      </div>

      {activeMode === 'generator' ? (
        <CssGridGenerator />
      ) : (
        <>
          {/* Header */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
                  <Sliders className="w-6 h-6 text-sky-600" />
                  <span>បន្ទប់ពិសោធន៍ CSS Grid អន្តរកម្ម (Interactive Grid Lab)</span>
                </h2>
                <p className="text-slate-600 text-sm mt-1">
                  សាកល្បងកែសម្រួល Properties ផ្ទាល់ ហើយមើលឃើញការប្រែប្រួលភ្លាមៗ ព្រមទាំងតេស្តទំហំអេក្រង់ 360px, 768px និង Desktop!
                </p>
              </div>

              {/* Quick Presets */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-semibold text-slate-500">Presets:</span>
                <button
                  onClick={() => applyPreset('equal3')}
                  className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded-lg transition-colors"
                >
                  3 Columns
                </button>
                <button
                  onClick={() => applyPreset('sidebar')}
                  className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded-lg transition-colors"
                >
                  Sidebar + Main
                </button>
                <button
                  onClick={() => applyPreset('autofit')}
                  className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-medium rounded-lg transition-colors"
                >
                  auto-fit
                </button>
                <button
                  onClick={() => applyPreset('autofill')}
                  className="px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 text-xs font-medium rounded-lg transition-colors"
                >
                  auto-fill
                </button>
                <button
                  onClick={() => applyPreset('featured')}
                  className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-medium rounded-lg transition-colors"
                >
                  Featured (2x2)
                </button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Controls Panel */}
            <div className="lg:col-span-4 space-y-5 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider pb-2 border-b border-slate-100">
                ឧបករណ៍បញ្ជា (Grid Controls)
              </h3>

              {/* grid-template-columns Input / Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  grid-template-columns
                </label>
                <input
                  type="text"
                  value={columnsMode}
                  onChange={(e) => setColumnsMode(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
                  placeholder="e.g. repeat(3, 1fr) or 200px 1fr"
                />
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {[
                    'repeat(3, 1fr)',
                    '240px 1fr',
                    'repeat(auto-fit, minmax(200px, 1fr))',
                    'repeat(auto-fill, minmax(200px, 1fr))',
                    '1fr 2fr',
                    'minmax(150px, 1fr) 2fr'
                  ].map((template) => (
                    <button
                      key={template}
                      onClick={() => setColumnsMode(template)}
                      className={`text-[11px] font-mono px-2 py-1 rounded transition-colors ${
                        columnsMode === template
                          ? 'bg-sky-600 text-white font-semibold'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {template}
                    </button>
                  ))}
                </div>
              </div>

              {/* gap size slider */}
              <div>
                <div className="flex justify-between text-xs font-bold text-slate-700 mb-1.5">
                  <span>gap</span>
                  <span className="font-mono text-sky-600">{gapSize}px</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="40"
                  step="4"
                  value={gapSize}
                  onChange={(e) => setGapSize(Number(e.target.value))}
                  className="w-full accent-sky-600"
                />
              </div>

              {/* Items count slider */}
              <div>
                <div className="flex justify-between text-xs font-bold text-slate-700 mb-1.5">
                  <span>ចំនួន Items ក្នុង Grid</span>
                  <span className="font-mono text-sky-600">{itemsCount} ធាតុ</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="12"
                  value={itemsCount}
                  onChange={(e) => setItemsCount(Number(e.target.value))}
                  className="w-full accent-sky-600"
                />
              </div>

              {/* Selected Item Spanning Controls */}
              <div className="pt-3 border-t border-slate-100 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700">
                    កែប្រែ Item ទី {selectedItem} (Span)
                  </label>
                  <select
                    value={selectedItem}
                    onChange={(e) => setSelectedItem(Number(e.target.value))}
                    className="text-xs bg-slate-50 border border-slate-300 rounded px-2 py-1 font-mono"
                  >
                    {Array.from({ length: itemsCount }).map((_, i) => (
                      <option key={i + 1} value={i + 1}>Item {i + 1}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="block text-[11px] text-slate-500 font-semibold mb-1">grid-column span</span>
                    <select
                      value={itemColSpan}
                      onChange={(e) => setItemColSpan(Number(e.target.value))}
                      className="w-full text-xs bg-slate-50 border border-slate-300 rounded p-1.5 font-mono"
                    >
                      <option value={1}>span 1 (លំនាំដើម)</option>
                      <option value={2}>span 2 (២ ជួរឈរ)</option>
                      <option value={3}>span 3 (៣ ជួរឈរ)</option>
                    </select>
                  </div>

                  <div>
                    <span className="block text-[11px] text-slate-500 font-semibold mb-1">grid-row span</span>
                    <select
                      value={itemRowSpan}
                      onChange={(e) => setItemRowSpan(Number(e.target.value))}
                      className="w-full text-xs bg-slate-50 border border-slate-300 rounded p-1.5 font-mono"
                    >
                      <option value={1}>span 1 (លំនាំដើម)</option>
                      <option value={2}>span 2 (២ ជួរដេក)</option>
                      <option value={3}>span 3 (៣ ជួរដេក)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Toggle Grid Lines Guide */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Eye className="w-4 h-4 text-slate-500" /> បង្ហាញបន្ទាត់ Lines & Numbers
                </span>
                <input
                  type="checkbox"
                  checked={showLineNumbers}
                  onChange={(e) => setShowLineNumbers(e.target.checked)}
                  className="rounded text-sky-600 focus:ring-sky-500 h-4 w-4"
                />
              </div>

              {/* Live Generated CSS Code */}
              <div className="pt-3 border-t border-slate-100">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-mono font-bold text-slate-700">Generated CSS:</span>
                  <button
                    onClick={handleCopy}
                    className="text-xs text-sky-600 hover:text-sky-800 flex items-center gap-1 font-mono"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-600">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="bg-slate-900 text-sky-300 p-3 rounded-lg text-xs font-mono overflow-x-auto leading-relaxed">
                  {generatedCss}
                </pre>
              </div>
            </div>

            {/* Live Visual Canvas Area */}
            <div className="lg:col-span-8 space-y-4">
              {/* Responsive Viewport Switcher Toolbar */}
              <div className="bg-slate-800 rounded-xl p-2.5 flex items-center justify-between text-white text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 font-medium">Viewport Simulation:</span>
                  <div className="flex bg-slate-900 p-0.5 rounded-lg border border-slate-700">
                    <button
                      onClick={() => setContainerWidth('mobile')}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
                        containerWidth === 'mobile' ? 'bg-sky-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      <span>Mobile 360px</span>
                    </button>
                    <button
                      onClick={() => setContainerWidth('tablet')}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
                        containerWidth === 'tablet' ? 'bg-sky-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Tablet className="w-3.5 h-3.5" />
                      <span>Tablet 768px</span>
                    </button>
                    <button
                      onClick={() => setContainerWidth('desktop')}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
                        containerWidth === 'desktop' ? 'bg-sky-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Monitor className="w-3.5 h-3.5" />
                      <span>Desktop (100%)</span>
                    </button>
                  </div>
                </div>

                <div className="text-slate-400 font-mono hidden sm:block">
                  Width: {getContainerMaxWidth()}
                </div>
              </div>

              {/* Interactive Simulation Frame */}
              <div className="bg-slate-100 border-2 border-dashed border-slate-300 rounded-2xl p-6 min-h-[480px] flex items-start justify-center overflow-x-auto">
                <div
                  className="w-full transition-all duration-300 bg-white p-5 rounded-xl border border-slate-200 shadow-md relative"
                  style={{ maxWidth: getContainerMaxWidth() }}
                >
                  {/* Container Label */}
                  <div className="text-[11px] font-mono font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center justify-between">
                    <span>.grid-container (Container Width: {getContainerMaxWidth()})</span>
                    {columnsMode.includes('auto-fit') && (
                      <span className="text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">Mode: auto-fit</span>
                    )}
                    {columnsMode.includes('auto-fill') && (
                      <span className="text-amber-600 bg-amber-50 px-2 py-0.5 rounded">Mode: auto-fill</span>
                    )}
                  </div>

                  {/* The Live CSS Grid Container */}
                  <div
                    className="transition-all duration-200"
                    style={{
                      display: 'grid',
                      gridTemplateColumns: columnsMode,
                      gap: `${gapSize}px`,
                    }}
                  >
                    {Array.from({ length: itemsCount }).map((_, index) => {
                      const itemNumber = index + 1;
                      const isSelected = itemNumber === selectedItem;
                      const customStyle: React.CSSProperties = {};

                      if (isSelected) {
                        if (itemColSpan > 1) customStyle.gridColumn = `span ${itemColSpan}`;
                        if (itemRowSpan > 1) customStyle.gridRow = `span ${itemRowSpan}`;
                      }

                      return (
                        <div
                          key={itemNumber}
                          onClick={() => setSelectedItem(itemNumber)}
                          style={customStyle}
                          className={`p-4 rounded-lg cursor-pointer transition-all duration-200 border-2 ${
                            isSelected
                              ? 'bg-sky-50 border-sky-500 shadow-md text-sky-950'
                              : 'bg-slate-50 border-slate-200 hover:border-slate-300 text-slate-800'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                              isSelected ? 'bg-sky-600 text-white' : 'bg-slate-200 text-slate-700'
                            }`}>
                              Item {itemNumber}
                            </span>
                            {showLineNumbers && (
                              <span className="text-[10px] font-mono text-slate-400">
                                {isSelected && (itemColSpan > 1 || itemRowSpan > 1) ? `Span: ${itemColSpan}x${itemRowSpan}` : '1x1'}
                              </span>
                            )}
                          </div>

                          <div className="text-xs font-medium">
                            {itemNumber === 1 && (itemColSpan > 1 || itemRowSpan > 1)
                              ? 'កាតពិសេស (Featured Card) គ្របដណ្តប់ច្រើន Cells'
                              : `កាតនិស្សិតគំរូ #${itemNumber}`}
                          </div>

                          <div className="text-[11px] text-slate-500 mt-1">
                            ដេប៉ាតឺម៉ង់ Computer Science
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Explanatory Note for auto-fit vs auto-fill */}
                  {columnsMode.includes('auto') && (
                    <div className="mt-4 p-3 bg-sky-50 border border-sky-200 rounded-lg text-xs text-sky-900 leading-relaxed">
                      💡 <span className="font-bold">ការកត់សម្គាល់៖</span> សាកល្បងប្តូរពី <strong>Desktop</strong> ទៅ <strong>Mobile 360px</strong> ដើម្បីសង្កេតមើលពីរបៀបដែល Grid ទម្លាក់ Columns មកត្រឹម 1 Column ដោយស្វ័យប្រវត្តិនឹងភ្នែកផ្ទាល់!
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
