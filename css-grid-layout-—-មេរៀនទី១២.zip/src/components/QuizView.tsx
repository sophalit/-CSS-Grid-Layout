import React, { useState } from 'react';
import { QUIZ_QUESTIONS, QuizQuestion } from '../data/assessmentData';
import { CheckCircle2, XCircle, HelpCircle, BookOpen, RotateCcw, Award } from 'lucide-react';

export const QuizView: React.FC = () => {
  const [activeMode, setActiveMode] = useState<'interactive' | 'answersKey'>('interactive');
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);

  const handleSelectOption = (questionId: number, optionIndex: number) => {
    if (isSubmitted) return;
    setSelectedAnswers(prev => ({ ...prev, [questionId]: optionIndex }));
  };

  const calculateScore = () => {
    let score = 0;
    QUIZ_QUESTIONS.forEach(q => {
      if (selectedAnswers[q.id] === q.correctIndex) {
        score += 1;
      }
    });
    return score;
  };

  const handleReset = () => {
    setSelectedAnswers({});
    setIsSubmitted(false);
  };

  const score = calculateScore();
  const percentage = Math.round((score / QUIZ_QUESTIONS.length) * 100);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-purple-100 text-purple-800 text-xs font-mono font-bold px-2.5 py-0.5 rounded-full">
                ផ្នែកទី A: Assessment
              </span>
              <span className="text-slate-400 text-xs font-medium">15 សំណួរត្រួតពិនិត្យចំណេះដឹង</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              សំណួរត្រួតពិនិត្យ និងប្រឡងសាកល្បង (Comprehensive Quiz)
            </h2>
            <p className="text-slate-600 text-sm mt-1">
              រួមបញ្ចូល ១០ សំណួរយល់ដឹង (Comprehension) និង ៥ សំណួរអានកូដទស្សន៍ទាយ Layout (Code Prediction) ជាមួយការពន្យល់លម្អិត។
            </p>
          </div>

          {/* Mode Switcher */}
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setActiveMode('interactive')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                activeMode === 'interactive' ? 'bg-white text-purple-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <HelpCircle className="w-4 h-4" />
              <span>ប្រឡងសាកល្បង (Test Mode)</span>
            </button>
            <button
              onClick={() => setActiveMode('answersKey')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                activeMode === 'answersKey' ? 'bg-white text-purple-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>កូនសោចម្លើយ & ហេតុផល (Answer Key)</span>
            </button>
          </div>
        </div>
      </div>

      {activeMode === 'interactive' ? (
        <div className="space-y-6">
          {/* Score Summary Card (when submitted) */}
          {isSubmitted && (
            <div className="bg-gradient-to-r from-purple-900 to-indigo-900 text-white rounded-2xl p-6 shadow-md flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center border-2 border-white/20">
                  <Award className="w-8 h-8 text-amber-300" />
                </div>
                <div>
                  <h3 className="text-lg font-bold">លទ្ធផលតេស្តរបស់អ្នក</h3>
                  <p className="text-purple-200 text-sm">
                    អ្នកឆ្លើយត្រូវ {score} លើ {QUIZ_QUESTIONS.length} សំណួរ ({percentage}%)
                  </p>
                </div>
              </div>
              <button
                onClick={handleReset}
                className="flex items-center gap-2 bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span>ធ្វើតេស្តម្តងទៀត (Retake)</span>
              </button>
            </div>
          )}

          {/* Question List */}
          <div className="space-y-5">
            {QUIZ_QUESTIONS.map((q, idx) => {
              const userAnswer = selectedAnswers[q.id];
              const isAnswered = userAnswer !== undefined;
              const isCorrect = userAnswer === q.correctIndex;

              return (
                <div
                  key={q.id}
                  className={`bg-white border rounded-2xl p-6 shadow-sm transition-all ${
                    isSubmitted
                      ? isCorrect
                        ? 'border-emerald-300 bg-emerald-50/20'
                        : 'border-rose-300 bg-rose-50/20'
                      : 'border-slate-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-2">
                      <span className="w-7 h-7 rounded-lg bg-purple-100 text-purple-800 text-xs font-bold flex items-center justify-center font-mono">
                        {idx + 1}
                      </span>
                      <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-600 uppercase">
                        {q.type === 'comprehension' ? 'ការយល់ដឹង' : 'អានកូដ'}
                      </span>
                    </div>

                    {isSubmitted && (
                      <div>
                        {isCorrect ? (
                          <span className="flex items-center gap-1 text-emerald-600 text-xs font-bold bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                            <CheckCircle2 className="w-4 h-4" /> ត្រឹមត្រូវ (+1)
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-rose-600 text-xs font-bold bg-rose-50 px-2.5 py-1 rounded-full border border-rose-200">
                            <XCircle className="w-4 h-4" /> មិនត្រឹមត្រូវ
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  <h3 className="text-sm sm:text-base font-bold text-slate-900 mb-3">
                    {q.question}
                  </h3>

                  {/* Optional Code Snippet */}
                  {q.codeSnippet && (
                    <pre className="bg-slate-900 text-sky-300 p-3 rounded-xl font-mono text-xs mb-4 overflow-x-auto leading-relaxed border border-slate-800">
                      {q.codeSnippet}
                    </pre>
                  )}

                  {/* Options */}
                  <div className="space-y-2">
                    {q.options.map((option, optIdx) => {
                      const isOptionSelected = userAnswer === optIdx;
                      let optionClasses = 'border-slate-200 hover:border-purple-300 hover:bg-slate-50 text-slate-700';

                      if (isSubmitted) {
                        if (optIdx === q.correctIndex) {
                          optionClasses = 'border-emerald-500 bg-emerald-50 text-emerald-900 font-semibold';
                        } else if (isOptionSelected && !isCorrect) {
                          optionClasses = 'border-rose-500 bg-rose-50 text-rose-900 font-semibold';
                        } else {
                          optionClasses = 'border-slate-200 opacity-60 text-slate-500';
                        }
                      } else if (isOptionSelected) {
                        optionClasses = 'border-purple-600 bg-purple-50 text-purple-900 font-semibold shadow-xs';
                      }

                      return (
                        <div
                          key={optIdx}
                          onClick={() => handleSelectOption(q.id, optIdx)}
                          className={`p-3 rounded-xl border text-xs sm:text-sm cursor-pointer flex items-center justify-between transition-all ${optionClasses}`}
                        >
                          <div className="flex items-center gap-3">
                            <span className="w-5 h-5 rounded-full border flex items-center justify-center text-[11px] font-mono font-bold shrink-0">
                              {String.fromCharCode(65 + optIdx)}
                            </span>
                            <span>{option}</span>
                          </div>
                          {isSubmitted && optIdx === q.correctIndex && (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Explanation when submitted */}
                  {isSubmitted && (
                    <div className="mt-4 p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-700 leading-relaxed">
                      💡 <span className="font-bold text-slate-900">ហេតុផលពន្យល់៖</span> {q.explanation}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Submit Action Bar */}
          {!isSubmitted && (
            <div className="sticky bottom-4 bg-white/95 backdrop-blur-sm border border-slate-300 rounded-2xl p-4 shadow-xl flex items-center justify-between">
              <span className="text-xs sm:text-sm font-medium text-slate-700">
                បានឆ្លើយ {Object.keys(selectedAnswers).length} នៃ {QUIZ_QUESTIONS.length} សំណួរ
              </span>
              <button
                onClick={() => setIsSubmitted(true)}
                disabled={Object.keys(selectedAnswers).length === 0}
                className="bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold shadow-md transition-all"
              >
                ពិនិត្យចម្លើយ និងពិន្ទុ (Submit Quiz)
              </button>
            </div>
          )}
        </div>
      ) : (
        /* Separate Section: Answer Key & Full Detailed Explanations */
        <div className="space-y-6">
          <div className="bg-purple-50 border border-purple-200 rounded-2xl p-6">
            <h3 className="text-base sm:text-lg font-bold text-purple-950 mb-2">
              កូនសោចម្លើយ និងការពន្យល់ហេតុផលលម្អិត (Answer Key & In-Depth Explanations)
            </h3>
            <p className="text-xs sm:text-sm text-purple-800">
              ផ្នែកនេះផ្តល់នូវចម្លើយត្រឹមត្រូវ និងមូលដ្ឋានទ្រឹស្តីលម្អិតសម្រាប់សំណួរទាំង ១៥ ដើម្បីឱ្យសិស្សានុសិស្សអាចផ្ទៀងផ្ទាត់ និងពង្រឹងការយល់ដឹង។
            </p>
          </div>

          <div className="space-y-4">
            {QUIZ_QUESTIONS.map((q, idx) => (
              <div key={q.id} className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-mono font-bold bg-slate-100 text-slate-800 px-2 py-0.5 rounded">
                    សំណួរទី {idx + 1}
                  </span>
                  <span className="text-xs text-slate-400 font-mono">
                    ({q.type === 'comprehension' ? 'Comprehension' : 'Code Prediction'})
                  </span>
                </div>

                <h4 className="text-sm font-bold text-slate-900 mb-2">
                  {q.question}
                </h4>

                {q.codeSnippet && (
                  <pre className="bg-slate-900 text-sky-300 p-2.5 rounded-lg font-mono text-xs mb-3 overflow-x-auto">
                    {q.codeSnippet}
                  </pre>
                )}

                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs sm:text-sm mb-2">
                  <span className="font-bold text-emerald-800">✅ ចម្លើយត្រឹមត្រូវ៖ </span>
                  <span className="font-semibold text-emerald-950">
                    {String.fromCharCode(65 + q.correctIndex)}. {q.options[q.correctIndex]}
                  </span>
                </div>

                <div className="text-xs sm:text-sm text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-100">
                  <span className="font-bold text-slate-800">ហេតុផលបច្ចេកទេស៖ </span>
                  {q.explanation}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
