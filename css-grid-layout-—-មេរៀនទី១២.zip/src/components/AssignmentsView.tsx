import React from 'react';
import { PRACTICAL_ASSIGNMENTS, GRADING_RUBRIC } from '../data/assessmentData';
import { Award, CheckCircle2, ChevronRight, Layers, Lightbulb, Terminal, FolderCheck } from 'lucide-react';

export const AssignmentsView: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-1">
          <span className="bg-emerald-100 text-emerald-800 text-xs font-mono font-bold px-2.5 py-0.5 rounded-full">
            ផ្នែកទី A: Application & Assessment
          </span>
          <span className="text-slate-400 text-xs font-medium">លំហាត់អនុវត្ត ៥ កម្រិត & Rubric</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
          លំហាត់អនុវត្ត និងតារាងវាយតម្លៃពិន្ទុ (Practical Exercises & Rubric)
        </h2>
        <p className="text-slate-600 text-sm mt-1">
          រៀបចំឡើងជា ៥ កម្រិត ចាប់ពីកម្រិតគ្រឹះរហូតដល់កម្រិតស្ថាបត្យកម្ម Dashboard ពេញលេញ រួមជាមួយ Rubric សរុប ១០០ ពិន្ទុ។
        </p>
      </div>

      {/* 5 Practical Assignment Levels */}
      <div className="space-y-6">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
          <Layers className="w-5 h-5 text-sky-600" />
          <h3 className="text-lg font-bold text-slate-900">
            លំហាត់អនុវត្ត ៥ កម្រិត (5 Progressive Assignment Levels)
          </h3>
        </div>

        <div className="grid grid-cols-1 gap-6">
          {PRACTICAL_ASSIGNMENTS.map((assignment) => (
            <div
              key={assignment.level}
              className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4"
            >
              {/* Header */}
              <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-3">
                <div>
                  <span className="bg-sky-50 text-sky-700 text-xs font-bold font-mono px-2.5 py-1 rounded-md border border-sky-200">
                    កម្រិតទី {assignment.level}
                  </span>
                  <h4 className="text-base sm:text-lg font-bold text-slate-900 mt-1.5">
                    {assignment.title}
                  </h4>
                </div>
              </div>

              {/* Goal */}
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 text-xs sm:text-sm">
                <span className="font-bold text-slate-800">🎯 គោលដៅអនុវត្ត៖ </span>
                <span className="text-slate-700">{assignment.goal}</span>
              </div>

              {/* Required Properties */}
              <div>
                <span className="text-xs font-bold text-slate-700 block mb-2">
                  Properties & Functions ដែលត្រូវប្រើ៖
                </span>
                <div className="flex flex-wrap gap-2">
                  {assignment.requiredProperties.map((prop, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 bg-sky-50 text-sky-800 font-mono text-xs rounded-md border border-sky-100"
                    >
                      {prop}
                    </span>
                  ))}
                </div>
              </div>

              {/* Step-by-step instructions */}
              <div>
                <span className="text-xs font-bold text-slate-700 block mb-2">
                  ជំហានណែនាំអនុវត្ត៖
                </span>
                <ul className="space-y-1.5 text-xs sm:text-sm text-slate-600">
                  {assignment.steps.map((step, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <ChevronRight className="w-4 h-4 text-sky-500 shrink-0 mt-0.5" />
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Expected Deliverables */}
              <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl text-xs sm:text-sm text-emerald-900 flex items-start gap-2">
                <FolderCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">លទ្ធផលដែលត្រូវប្រគល់៖ </span>
                  {assignment.deliverables}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Mini Project Instructions & Expansion Tasks */}
      <div className="bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-2xl p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex items-center gap-3">
          <Terminal className="w-7 h-7 text-sky-400" />
          <div>
            <h3 className="text-lg sm:text-xl font-bold text-white">
              ការណែនាំដំណើរការ និងកែប្រែ Mini Project (Student Dashboard)
            </h3>
            <p className="text-slate-300 text-xs sm:text-sm">
              របៀបបើកដំណើរការកូដ ការផ្លាស់ប្តូរទិន្នន័យ និងកិច្ចការពង្រីកគំនិតច្នៃប្រឌិត (Expansion Challenges)
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs sm:text-sm">
          <div className="bg-slate-800/80 p-5 rounded-xl border border-slate-700 space-y-3">
            <h4 className="font-bold text-sky-300 text-sm flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" /> ជំហានបើក និងសាកល្បង Project
            </h4>
            <ol className="list-decimal list-inside space-y-2 text-slate-300">
              <li>បង្កើត Folder ឈ្មោះ <code className="text-sky-300 font-mono">student-dashboard</code> លើកុំព្យូទ័ររបស់អ្នក។</li>
              <li>បង្កើតឯកសារ <code className="text-sky-300 font-mono">index.html</code> និងបង្កើត Folder <code className="text-sky-300 font-mono">css/style.css</code>។</li>
              <li>Copy កូដពេញលេញពីផ្ទាំង <strong>«គម្រោងគំរូជាក់ស្តែង»</strong> យកទៅដាក់ក្នុងឯកសារនីមួយៗ។</li>
              <li>ចុច Double Click លើ <code className="text-sky-300 font-mono">index.html</code> ដើម្បីបើកមើលក្នុង Chrome, Firefox, ឬ Edge។</li>
              <li>ចុច <strong>F12 (DevTools)</strong> ហើយចុចលើរូបទូរស័ព្ទ (Toggle Device Toolbar) ដើម្បីតេស្តទំហំ 360px, 768px, និង 1280px!</li>
            </ol>
          </div>

          <div className="bg-slate-800/80 p-5 rounded-xl border border-slate-700 space-y-3">
            <h4 className="font-bold text-amber-300 text-sm flex items-center gap-2">
              <Lightbulb className="w-4 h-4" /> កិច្ចការពង្រីកគំនិត (Expansion Challenges)
            </h4>
            <ul className="space-y-2 text-slate-300">
              <li className="flex items-start gap-2">
                <span className="text-amber-400 font-bold">•</span>
                <span><strong>ប្តូរទំហំ Tracks៖</strong> សាកល្បងប្តូរ Sidebar ពី 240px ទៅជា <code className="text-amber-300 font-mono">minmax(200px, 280px)</code> រួចសង្កេតមើលឥរិយាបថ។</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400 font-bold">•</span>
                <span><strong>កែប្រែ Gap៖</strong> ប្តូរ gap ពី 16px ទៅជា 24px នៅលើ Desktop និងបន្ថយមក 12px លើ Mobile។</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400 font-bold">•</span>
                <span><strong>ប្តូរទីតាំង Items៖</strong> នៅក្នុង grid-template-areas សាកល្បងប្តូរទីតាំង Sidebar ឱ្យមកនៅខាងស្តាំវិញ (main sidebar)។</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400 font-bold">•</span>
                <span><strong>បន្ថែម Quick Actions Grid៖</strong> បង្កើត Nested Grid ថ្មីមួយទៀតដែលមានប៊ូតុងចុះឈ្មោះ និងទាញយកសញ្ញាបត្រគំរូ។</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* 100-Point Rubric */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <Award className="w-6 h-6 text-amber-500" />
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                តារាងវាយតម្លៃការអនុវត្ត (Comprehensive Grading Rubric)
              </h3>
              <p className="text-xs text-slate-500">ពិន្ទុសរុប ១០០ ពិន្ទុ (Total 100 Points)</p>
            </div>
          </div>
          <span className="bg-amber-100 text-amber-900 font-mono font-bold text-sm px-3 py-1 rounded-full border border-amber-300">
            100 Points
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {GRADING_RUBRIC.map((item, idx) => (
            <div
              key={idx}
              className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <h4 className="text-sm font-bold text-slate-900">
                    {item.category}
                  </h4>
                  <span className="bg-sky-100 text-sky-800 font-mono font-bold text-xs px-2 py-0.5 rounded shrink-0">
                    {item.maxScore} ពិន្ទុ
                  </span>
                </div>
                <ul className="space-y-2 text-xs text-slate-600">
                  {item.criteria.map((crit, cIdx) => (
                    <li key={cIdx} className="flex items-start gap-1.5">
                      <span className="text-sky-500 font-bold">•</span>
                      <span>{crit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
