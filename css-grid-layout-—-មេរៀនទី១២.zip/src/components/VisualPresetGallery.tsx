import React, { useState, useMemo } from 'react';
import { LAYOUT_PRESETS, LayoutPreset } from '../data/gridPresets';
import { 
  Sparkles, 
  Check, 
  ChevronRight, 
  Layout, 
  Filter, 
  Layers,
  ArrowRight,
  Maximize2,
  Search,
  X
} from 'lucide-react';

interface VisualPresetGalleryProps {
  onSelectPreset: (preset: LayoutPreset) => void;
  activePresetId?: string;
  isModal?: boolean;
  onCloseModal?: () => void;
}

export const VisualPresetGallery: React.FC<VisualPresetGalleryProps> = ({
  onSelectPreset,
  activePresetId,
  isModal = false,
  onCloseModal,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [appliedId, setAppliedId] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: 'ទាំងអស់' },
    { id: 'food', label: 'ម្ហូប & កាហ្វេ' },
    { id: 'education', label: 'ការអប់រំ & E-Learning' },
    { id: 'entertainment', label: 'ភាពយន្ត & Media' },
    { id: 'ecommerce', label: 'ហាងទំនិញ & Tech' },
    { id: 'portfolio', label: 'វិចិត្រសាល & សៀវភៅ 3D' },
    { id: 'marketing', label: 'ទេសចរណ៍ & Bento' },
    { id: 'web', label: 'គេហទំព័រ & News' },
    { id: 'dashboard', label: 'ផ្ទាំងគ្រប់គ្រង' },
  ];

  const filteredPresets = useMemo(() => {
    return LAYOUT_PRESETS.filter(preset => {
      const matchCategory = selectedCategory === 'all' || preset.category === selectedCategory;
      const query = searchQuery.trim().toLowerCase();
      if (!query) return matchCategory;

      const matchSearch = 
        preset.name.toLowerCase().includes(query) ||
        preset.nameEn.toLowerCase().includes(query) ||
        preset.description.toLowerCase().includes(query) ||
        preset.categoryLabel.toLowerCase().includes(query) ||
        preset.items.some(item => item.name.toLowerCase().includes(query));

      return matchCategory && matchSearch;
    });
  }, [selectedCategory, searchQuery]);

  const handleApply = (preset: LayoutPreset) => {
    onSelectPreset(preset);
    setAppliedId(preset.id);
    setTimeout(() => setAppliedId(null), 1800);
    if (isModal && onCloseModal) {
      setTimeout(() => onCloseModal(), 400);
    }
  };

  return (
    <div className="space-y-4">
      {/* Search Bar and Category Filter Pills */}
      <div className="flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center justify-between pb-1">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ស្វែងរកគំរូ Layout (ឧ. Cafe, Delivery, Movie, Book, Travel, Education...)"
            className="w-full pl-9 pr-8 py-2 bg-slate-800/90 hover:bg-slate-800 focus:bg-slate-900 border border-slate-700 focus:border-sky-500 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-hidden transition-all shadow-inner"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-white rounded-md cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Counter Badge */}
        <div className="text-xs text-slate-400 font-mono flex items-center gap-1.5 shrink-0 px-2">
          <span>បង្ហាញ:</span>
          <span className="font-bold text-sky-400 bg-sky-950/80 px-2 py-0.5 rounded-lg border border-sky-800/60">
            {filteredPresets.length} / {LAYOUT_PRESETS.length} គំរូ
          </span>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-thin">
        <span className="text-xs font-semibold text-slate-400 flex items-center gap-1 shrink-0 mr-1">
          <Filter className="w-3.5 h-3.5 text-slate-500" /> ប្រភេទ៖
        </span>
        {categories.map((cat) => {
          const count = cat.id === 'all' 
            ? LAYOUT_PRESETS.length 
            : LAYOUT_PRESETS.filter(p => p.category === cat.id).length;

          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                selectedCategory === cat.id
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700/80'
              }`}
            >
              <span>{cat.label}</span>
              <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                selectedCategory === cat.id ? 'bg-sky-700 text-white' : 'bg-slate-700 text-slate-300'
              }`}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Grid of Visual Preset Cards */}
      {filteredPresets.length === 0 ? (
        <div className="text-center py-12 bg-slate-800/40 rounded-2xl border border-slate-800 text-slate-400 p-6">
          <p className="text-sm font-semibold mb-1">រកមិនឃើញគំរូ Layout ណាដែលត្រូវគ្នានឹង "{searchQuery}" ទេ</p>
          <p className="text-xs text-slate-500 mb-3">សូមព្យាយាមវាយពាក្យគន្លឹះផ្សេង ឬចុចសម្អាតការស្វែងរក</p>
          <button
            onClick={() => { setSearchQuery(''); setSelectedCategory('all'); }}
            className="px-4 py-1.5 bg-sky-600 text-white rounded-xl text-xs font-semibold hover:bg-sky-500 cursor-pointer transition-colors"
          >
            មើលគំរូទាំងអស់ ({LAYOUT_PRESETS.length})
          </button>
        </div>
      ) : (
        <div className={`grid gap-4 ${
          isModal 
            ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' 
            : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
        }`}>
          {filteredPresets.map((preset) => {
            const isCurrentActive = activePresetId === preset.id;
            const isJustApplied = appliedId === preset.id;

            return (
              <div
                key={preset.id}
                className={`group bg-slate-900/90 rounded-2xl border transition-all duration-200 p-4 flex flex-col justify-between hover:shadow-xl hover:border-slate-700 ${
                  isCurrentActive || isJustApplied
                    ? 'border-sky-500 ring-2 ring-sky-500/30 shadow-md bg-slate-900'
                    : 'border-slate-800 hover:bg-slate-900'
                }`}
              >
                <div>
                  {/* Header & Meta */}
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <span className="text-[10px] font-bold font-mono uppercase tracking-wider text-sky-400 bg-sky-950/80 px-2 py-0.5 rounded border border-sky-800/60">
                        {preset.categoryLabel}
                      </span>
                      <h4 className="text-sm font-bold text-white mt-1 group-hover:text-sky-300 transition-colors">
                        {preset.name}
                      </h4>
                      <p className="text-[11px] text-slate-400 truncate">{preset.nameEn}</p>
                    </div>
                    <span className="text-[11px] font-mono font-bold text-slate-300 bg-slate-800 px-2 py-0.5 rounded border border-slate-700 shrink-0">
                      {preset.columns}×{preset.rows}
                    </span>
                  </div>

                  {/* Visual Miniature CSS Grid Diagram */}
                  <div className="bg-slate-950 p-2 rounded-xl border border-slate-800 my-2.5 shadow-inner">
                    <div
                      className="w-full aspect-[16/10] rounded-lg overflow-hidden transition-all duration-200"
                      style={{
                        display: 'grid',
                        gridTemplateColumns: preset.columns === 12 ? 'repeat(12, 1fr)' : preset.colUnits.join(' '),
                        gridTemplateRows: preset.rowUnits.join(' '),
                        gap: preset.columns === 12 ? '2px' : '4px',
                      }}
                    >
                      {preset.items.map((item) => (
                        <div
                          key={item.id}
                          style={{
                            gridColumn: `${item.colStart} / span ${item.colSpan}`,
                            gridRow: `${item.rowStart} / span ${item.rowSpan}`,
                            backgroundColor: item.color,
                          }}
                          className="rounded flex items-center justify-center p-0.5 overflow-hidden transition-transform group-hover:scale-[1.01]"
                          title={`${item.name} (${item.colSpan}×${item.rowSpan})`}
                        >
                          <span className="text-[8px] sm:text-[9px] font-mono font-bold text-white/95 truncate px-0.5 drop-shadow-xs">
                            {item.name}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed mb-3">
                    {preset.description}
                  </p>
                </div>

                {/* Action Button */}
                <button
                  onClick={() => handleApply(preset)}
                  className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    isJustApplied
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : isCurrentActive
                      ? 'bg-sky-600 text-white'
                      : 'bg-slate-800 hover:bg-sky-600 hover:text-white text-slate-200 border border-slate-700 hover:border-sky-500'
                  }`}
                >
                  {isJustApplied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-white" />
                      <span>បានអនុវត្តជោគជ័យ!</span>
                    </>
                  ) : isCurrentActive ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-white" />
                      <span>គំរូកំពុងប្រើប្រាស់</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5 text-amber-400 group-hover:text-white" />
                      <span>យកទៅប្រើប្រាស់ភ្លាមៗ (Apply)</span>
                      <ArrowRight className="w-3.5 h-3.5 ml-0.5 opacity-70 group-hover:translate-x-0.5 transition-transform" />
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
