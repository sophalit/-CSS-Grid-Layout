export interface LessonSection {
  id: string;
  number: string;
  title: string;
  englishTitle: string;
  definition: string;
  purposeAndWhenToUse: string;
  syntax: string;
  htmlExample: string;
  cssExample: string;
  codeExplanation: string[];
  expectedResult: {
    description: string;
    diagramText: string;
  };
  commonMistakes: { mistake: string; solution: string }[];
  quickChallenge: {
    question: string;
    task: string;
    hint: string;
  };
}

export const LESSON_META = {
  courseNumber: "មេរៀនទី១២",
  title: "ការប្រើប្រាស់ CSS Grid Layout",
  englishTitle: "Modern CSS Layout — CSS Grid",
  targetAudience: "និស្សិតឆ្នាំទី២ ដេប៉ាតឺម៉ង់ Computer Science / IT ដែលបានរៀន HTML, CSS Foundation, Box Model និងមូលដ្ឋាន Flexbox",
  prerequisites: [
    "HTML5 Semantic Elements (header, nav, main, section, aside, footer, article)",
    "CSS Box Model (content, padding, border, margin) និង box-sizing: border-box",
    "CSS Selectors, Classes, IDs និង Pseudo-classes",
    "មូលដ្ឋានគ្រឹះ Flexbox (One-Dimensional Layout លើ Main Axis និង Cross Axis)"
  ],
  outcomes: [
    "ពន្យល់ថា CSS Grid ជាអ្វី និងហេតុអ្វីវាជា Two-Dimensional Layout",
    "ប្រៀបធៀប Flexbox និង Grid និងជ្រើសរើសប្រើឱ្យសមស្របតាមតម្រូវការ",
    "ពន្យល់ពី Grid Container និង Grid Items ច្បាស់លាស់",
    "ប្រើ display: grid ដើម្បីបង្កើត Grid Layout ពេញលេញ",
    "យល់ដឹងច្បាស់ពី Rows, Columns, Tracks, Cells និង Grid Lines",
    "ប្រើ grid-template-columns ដើម្បីបែងចែកជួរឈរ",
    "ប្រើ grid-template-rows ដើម្បីបែងចែកជួរដេក",
    "ប្រើ gap, row-gap និង column-gap ដើម្បីគ្រប់គ្រងគម្លាត",
    "ប្រើ grid-column ដើម្បីឱ្យ Item ឆ្លងកាត់ Columns ច្រើន (Spanning)",
    "ប្រើ grid-row ដើម្បីឱ្យ Item ឆ្លងកាត់ Rows ច្រើន",
    "ប្រើមុខងារ repeat() ដើម្បីកាត់បន្ថយកូដស្ទួន",
    "ប្រើប្រាស់ឯកតា fr (Fractional Unit) ដើម្បីចែក Available Space",
    "ប្រើអនុគមន៍ minmax() ដើម្បីកំណត់ទំហំអប្បបរមា និងអតិបរមា",
    "ពន្យល់ភាពខុសគ្នាយ៉ាងច្បាស់រវាង auto-fit និង auto-fill",
    "បង្កើត Campus Gallery ដែលមានលក្ខណៈ Responsive ពេញលេញ",
    "បង្កើត Student Dashboard Layout ដោយប្រើ CSS Grid និង Nested Grids"
  ]
};

export interface GridDivItem {
  id: string;
  name: string;
  colStart: number;
  colSpan: number;
  rowStart: number;
  rowSpan: number;
  color: string;
}

export interface GridTrack {
  id: string;
  value: number;
  unit: 'fr' | 'px' | '%' | 'auto';
}

